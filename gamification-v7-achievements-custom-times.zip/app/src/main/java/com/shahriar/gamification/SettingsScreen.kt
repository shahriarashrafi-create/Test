package com.shahriar.gamification

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SettingsPanel = Color(0xF20A1931)
private val SettingsDeep = Color(0xF2071428)
private val SettingsGold = Color(0xFFFFC857)
private val SettingsCyan = Color(0xFF39D7FF)
private val SettingsWhite = Color(0xFFF8FAFF)
private val SettingsMuted = Color(0xFFAFC0D8)

@Composable
fun SettingsScreen(
    padding: PaddingValues,
    settings: AppSettings,
    onBack: () -> Unit,
    onSettingsChanged: (AppSettings) -> Unit
) {
    var shortText by remember(settings.shortGameMinutes) { mutableStateOf(settings.shortGameMinutes.toString()) }
    var standardText by remember(settings.standardGameMinutes) { mutableStateOf(settings.standardGameMinutes.toString()) }
    var longText by remember(settings.longGameMinutes) { mutableStateOf(settings.longGameMinutes.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(44.dp).clickable(onClick = onBack),
                shape = RoundedCornerShape(14.dp),
                color = SettingsPanel,
                border = BorderStroke(1.dp, SettingsGold.copy(alpha = 0.28f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.ArrowBack, "بازگشت", tint = SettingsGold)
                }
            }
            Text(
                "تنظیمات",
                modifier = Modifier.weight(1f),
                color = SettingsWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.width(44.dp))
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = SettingsPanel,
            border = BorderStroke(1.dp, SettingsCyan.copy(alpha = 0.20f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Schedule, null, tint = SettingsCyan)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("زمان بازی‌ها", color = SettingsWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("هر سه زمان را خودت تعریف کن؛ مثلاً ۱۵، ۴۵ و ۹۰ دقیقه.", color = SettingsMuted, fontSize = 10.sp)
                    }
                }

                GameTimeField(
                    label = "بازی کوتاه",
                    value = shortText,
                    onValueChange = { value ->
                        shortText = value.filter { it.isDigit() }.take(3)
                        shortText.toIntOrNull()?.let { minutes ->
                            if (minutes in 1..240) onSettingsChanged(settings.copy(shortGameMinutes = minutes))
                        }
                    }
                )
                GameTimeField(
                    label = "بازی استاندارد",
                    value = standardText,
                    onValueChange = { value ->
                        standardText = value.filter { it.isDigit() }.take(3)
                        standardText.toIntOrNull()?.let { minutes ->
                            if (minutes in 1..240) onSettingsChanged(settings.copy(standardGameMinutes = minutes))
                        }
                    }
                )
                GameTimeField(
                    label = "بازی بلند",
                    value = longText,
                    onValueChange = { value ->
                        longText = value.filter { it.isDigit() }.take(3)
                        longText.toIntOrNull()?.let { minutes ->
                            if (minutes in 1..240) onSettingsChanged(settings.copy(longGameMinutes = minutes))
                        }
                    }
                )

                Text("زمان پیش‌فرض", color = SettingsWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DefaultTimeButton(Modifier.weight(1f), shortText.ifBlank { "-" }, settings.defaultGameSlot == 0) {
                        onSettingsChanged(settings.copy(defaultGameSlot = 0))
                    }
                    DefaultTimeButton(Modifier.weight(1f), standardText.ifBlank { "-" }, settings.defaultGameSlot == 1) {
                        onSettingsChanged(settings.copy(defaultGameSlot = 1))
                    }
                    DefaultTimeButton(Modifier.weight(1f), longText.ifBlank { "-" }, settings.defaultGameSlot == 2) {
                        onSettingsChanged(settings.copy(defaultGameSlot = 2))
                    }
                }
            }
        }

        SettingToggle(Icons.Rounded.VolumeUp, "صدای بازی", "افکت‌های صوتی Combo و پاداش‌ها", settings.soundEnabled) {
            onSettingsChanged(settings.copy(soundEnabled = it))
        }
        SettingToggle(Icons.Rounded.Vibration, "ویبره", "بازخورد لمسی هنگام انجام کارها", settings.vibrationEnabled) {
            onSettingsChanged(settings.copy(vibrationEnabled = it))
        }
        SettingToggle(Icons.Rounded.AutoAwesome, "افکت‌های انگیزشی", "Double Kill، Legendary و افکت‌های مشابه", settings.motivationalEffectsEnabled) {
            onSettingsChanged(settings.copy(motivationalEffectsEnabled = it))
        }
        SettingToggle(Icons.Rounded.DeleteForever, "تأیید قبل از حذف", "قبل از حذف دائمی کار یا پاداش تأیید بگیرد", settings.confirmDeleteEnabled) {
            onSettingsChanged(settings.copy(confirmDeleteEnabled = it))
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun GameTimeField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        suffix = { Text("دقیقه") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        colors = SettingsTextFieldColors()
    )
}

@Composable
private fun SettingsTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = SettingsWhite,
    unfocusedTextColor = SettingsWhite,
    cursorColor = SettingsGold,
    focusedBorderColor = SettingsCyan,
    unfocusedBorderColor = SettingsMuted.copy(alpha = 0.55f),
    focusedLabelColor = SettingsCyan,
    unfocusedLabelColor = SettingsMuted,
    focusedContainerColor = SettingsDeep,
    unfocusedContainerColor = SettingsDeep,
    focusedSuffixColor = SettingsGold,
    unfocusedSuffixColor = SettingsMuted
)

@Composable
private fun DefaultTimeButton(modifier: Modifier, minutes: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(54.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        color = if (selected) SettingsCyan.copy(alpha = 0.16f) else SettingsDeep,
        border = BorderStroke(1.dp, if (selected) SettingsCyan.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.06f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text("$minutes دقیقه", color = if (selected) SettingsGold else SettingsWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingToggle(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(21.dp),
        color = SettingsPanel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 15.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = RoundedCornerShape(13.dp), color = SettingsCyan.copy(alpha = 0.10f)) {
                Box(modifier = Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                    Icon(icon, null, tint = SettingsCyan)
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = SettingsWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(subtitle, color = SettingsMuted, fontSize = 10.sp, maxLines = 2)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
