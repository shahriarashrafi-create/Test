# آپلود نسخه ۱۲ روی GitHub

1. فایل ZIP را Extract کن.
2. همه فایل‌ها و پوشه‌ها را در ریشه Repository قرار بده.
3. Push کن یا از تب Actions، Workflow ساخت APK را اجرا کن.
4. بعد از موفق شدن Build، از Artifacts فایل `shahriar-million-path-v12-apk` را بگیر.
