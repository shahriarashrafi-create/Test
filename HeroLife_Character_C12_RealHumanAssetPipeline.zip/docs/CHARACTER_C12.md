# C12 — Real Human Asset Pipeline

C12 is the architecture switch from procedural character generation to real authored human assets.

## What changed
- Procedural female GLB removed from the primary production slot.
- It is retained only as a fallback so the app still runs.
- New primary production paths:
  - models/production/real/female/female_real.glb
  - models/production/real/male/male_real.glb
- Runtime now automatically prefers the real authored asset when present.
- HUD, rank, navigation, camera and 360 rotation remain independent from the model.

## Production asset requirements
The final human asset should include:
- sculpted human anatomy
- retopology
- UV0
- skin and face textures
- eye materials
- hair cards/strands
- outfit mesh
- humanoid rig
- skin weights
- Idle animation
- mobile-friendly GLB export

## Important
C12 intentionally does NOT claim the fallback model is photoreal.
The purpose of this stage is to make the app ready for a genuinely authored human asset without another UI rewrite.

No companion.
