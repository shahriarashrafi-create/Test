# آپلود در GitHub

1. فایل ZIP را Extract کنید.
2. تمام فایل‌های داخل پوشه را در ریشه Repository قرار دهید.
3. Commit/Push کنید.
4. وارد تب Actions شوید و Workflow با نام Build Android APK را اجرا کنید.
5. پس از موفق شدن Build، Artifact با نام `shahriar-million-path-v8-apk` را دانلود کنید.
