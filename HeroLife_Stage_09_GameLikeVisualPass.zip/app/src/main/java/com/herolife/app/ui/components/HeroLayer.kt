package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.herolife.app.model.HeroGender
import com.herolife.app.model.HeroSelection
import com.herolife.app.ui.theme.HL

@Composable
fun HeroLayer(
    selection: HeroSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Canvas(
        modifier = modifier.clickable(onClick = onClick)
    ) {
        val cx = size.width * .52f
        val headY = size.height * .16f
        val shoulderY = size.height * .30f
        val waistY = size.height * .51f
        val hipY = size.height * .59f
        val kneeY = size.height * .78f
        val bottom = size.height * .96f

        drawCircle(
            brush = Brush.radialGradient(
                listOf(
                    HL.Gold.copy(alpha = .17f),
                    HL.Crystal.copy(alpha = .04f),
                    Color.Transparent
                )
            ),
            radius = size.width * .42f,
            center = Offset(cx, size.height * .38f)
        )

        if (selection.gender == HeroGender.FEMALE) {
            // Back hair mass
            val hairBack = Path().apply {
                moveTo(cx - size.width * .10f, headY - size.height * .08f)
                cubicTo(
                    cx - size.width * .18f, headY - size.height * .03f,
                    cx - size.width * .22f, shoulderY + size.height * .08f,
                    cx - size.width * .15f, size.height * .62f
                )
                cubicTo(
                    cx - size.width * .10f, size.height * .70f,
                    cx + size.width * .08f, size.height * .68f,
                    cx + size.width * .16f, size.height * .60f
                )
                cubicTo(
                    cx + size.width * .22f, shoulderY + size.height * .08f,
                    cx + size.width * .16f, headY - size.height * .02f,
                    cx + size.width * .09f, headY - size.height * .08f
                )
                close()
            }
            drawPath(
                hairBack,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF5A3328),
                        Color(0xFF2D1A18),
                        Color(0xFF120C0D)
                    )
                )
            )

            // Cape behind body
            val cape = Path().apply {
                moveTo(cx + size.width * .10f, shoulderY + size.height * .01f)
                cubicTo(
                    cx + size.width * .28f, size.height * .48f,
                    cx + size.width * .30f, size.height * .77f,
                    cx + size.width * .22f, bottom
                )
                lineTo(cx + size.width * .02f, bottom)
                lineTo(cx + size.width * .01f, shoulderY)
                close()
            }
            drawPath(
                cape,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF1A1C22),
                        Color(0xFF090A0F)
                    )
                )
            )

            // Neck
            drawRect(
                color = Color(0xFFDDAE96),
                topLeft = Offset(cx - size.width * .028f, headY + size.height * .052f),
                size = Size(size.width * .056f, size.height * .070f)
            )

            // Face
            drawOval(
                color = Color(0xFFE3B29C),
                topLeft = Offset(cx - size.width * .060f, headY - size.height * .046f),
                size = Size(size.width * .120f, size.height * .106f)
            )

            // subtle face shadow
            drawOval(
                color = Color(0xFFB77466).copy(alpha = .16f),
                topLeft = Offset(cx + size.width * .005f, headY - size.height * .010f),
                size = Size(size.width * .046f, size.height * .060f)
            )

            // Brows
            drawLine(
                color = Color(0xFF4B2A27),
                start = Offset(cx - size.width * .040f, headY - size.height * .008f),
                end = Offset(cx - size.width * .010f, headY - size.height * .012f),
                strokeWidth = 2.2f
            )
            drawLine(
                color = Color(0xFF4B2A27),
                start = Offset(cx + size.width * .010f, headY - size.height * .012f),
                end = Offset(cx + size.width * .040f, headY - size.height * .007f),
                strokeWidth = 2.2f
            )

            // Eyes + highlights
            drawCircle(
                color = Color(0xFF2A1E24),
                radius = size.width * .0055f,
                center = Offset(cx - size.width * .024f, headY + size.height * .005f)
            )
            drawCircle(
                color = Color(0xFF2A1E24),
                radius = size.width * .0055f,
                center = Offset(cx + size.width * .024f, headY + size.height * .005f)
            )
            drawCircle(
                color = Color.White.copy(alpha = .85f),
                radius = size.width * .0018f,
                center = Offset(cx - size.width * .022f, headY + size.height * .003f)
            )
            drawCircle(
                color = Color.White.copy(alpha = .85f),
                radius = size.width * .0018f,
                center = Offset(cx + size.width * .026f, headY + size.height * .003f)
            )

            // Nose
            drawLine(
                color = Color(0xFFB97B6C).copy(alpha = .74f),
                start = Offset(cx, headY + size.height * .010f),
                end = Offset(cx - size.width * .004f, headY + size.height * .032f),
                strokeWidth = 1.5f
            )

            // Lips
            drawLine(
                color = Color(0xFF9E4C5A),
                start = Offset(cx - size.width * .018f, headY + size.height * .046f),
                end = Offset(cx + size.width * .019f, headY + size.height * .046f),
                strokeWidth = 2.6f
            )

            // Front hair strands
            drawArc(
                color = Color(0xFF3D231F),
                startAngle = 184f,
                sweepAngle = 152f,
                useCenter = false,
                topLeft = Offset(cx - size.width * .082f, headY - size.height * .070f),
                size = Size(size.width * .164f, size.height * .118f),
                style = Stroke(width = size.width * .018f)
            )

            // Shoulder armor
            drawArc(
                color = HL.Gold,
                startAngle = 190f,
                sweepAngle = 135f,
                useCenter = false,
                topLeft = Offset(cx - size.width * .19f, shoulderY - size.height * .005f),
                size = Size(size.width * .12f, size.height * .11f),
                style = Stroke(width = size.width * .010f)
            )
            drawArc(
                color = HL.Gold,
                startAngle = 215f,
                sweepAngle = 135f,
                useCenter = false,
                topLeft = Offset(cx + size.width * .07f, shoulderY - size.height * .005f),
                size = Size(size.width * .12f, size.height * .11f),
                style = Stroke(width = size.width * .010f)
            )

            // Torso / waist / hips
            val torso = Path().apply {
                moveTo(cx, shoulderY)
                lineTo(cx - size.width * .17f, shoulderY + size.height * .05f)
                lineTo(cx - size.width * .115f, waistY)
                lineTo(cx - size.width * .135f, hipY)
                lineTo(cx + size.width * .135f, hipY)
                lineTo(cx + size.width * .115f, waistY)
                lineTo(cx + size.width * .17f, shoulderY + size.height * .05f)
                close()
            }
            drawPath(
                torso,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF282C34),
                        Color(0xFF151A22),
                        Color(0xFF0A0D12)
                    )
                )
            )

            // Gold chest arcs
            drawArc(
                color = HL.Gold.copy(alpha = .72f),
                startAngle = 195f,
                sweepAngle = 135f,
                useCenter = false,
                topLeft = Offset(
                    cx - size.width * .125f,
                    shoulderY + size.height * .045f
                ),
                size = Size(size.width * .125f, size.height * .105f),
                style = Stroke(width = size.width * .007f)
            )
            drawArc(
                color = HL.Gold.copy(alpha = .72f),
                startAngle = 210f,
                sweepAngle = 135f,
                useCenter = false,
                topLeft = Offset(
                    cx,
                    shoulderY + size.height * .045f
                ),
                size = Size(size.width * .125f, size.height * .105f),
                style = Stroke(width = size.width * .007f)
            )

            // Central armor line
            drawLine(
                color = HL.Gold,
                start = Offset(cx, shoulderY + size.height * .025f),
                end = Offset(cx, waistY + size.height * .035f),
                strokeWidth = size.width * .006f
            )

            repeat(4) { i ->
                val y = shoulderY + size.height * (.09f + i * .055f)
                drawLine(
                    color = HL.Gold.copy(alpha = .55f),
                    start = Offset(cx - size.width * .032f, y),
                    end = Offset(cx + size.width * .032f, y),
                    strokeWidth = size.width * .0035f
                )
            }

            // Belt + crystal
            drawLine(
                color = HL.Gold,
                start = Offset(cx - size.width * .11f, waistY + size.height * .03f),
                end = Offset(cx + size.width * .11f, waistY + size.height * .03f),
                strokeWidth = size.width * .009f
            )
            drawCircle(
                color = HL.Crystal,
                radius = size.width * .011f,
                center = Offset(cx, waistY + size.height * .03f)
            )

            // Arms
            drawLine(
                color = Color(0xFFDCAA90),
                start = Offset(cx - size.width * .155f, shoulderY + size.height * .06f),
                end = Offset(cx - size.width * .195f, size.height * .60f),
                strokeWidth = size.width * .040f
            )
            drawLine(
                color = Color(0xFFDCAA90),
                start = Offset(cx + size.width * .155f, shoulderY + size.height * .06f),
                end = Offset(cx + size.width * .175f, size.height * .58f),
                strokeWidth = size.width * .040f
            )

            // Gloves
            drawLine(
                color = Color(0xFF1E242C),
                start = Offset(cx - size.width * .192f, size.height * .52f),
                end = Offset(cx - size.width * .198f, size.height * .61f),
                strokeWidth = size.width * .048f
            )
            drawLine(
                color = Color(0xFF1E242C),
                start = Offset(cx + size.width * .174f, size.height * .50f),
                end = Offset(cx + size.width * .178f, size.height * .59f),
                strokeWidth = size.width * .048f
            )

            // Skirt / legs shape with better split
            val lower = Path().apply {
                moveTo(cx - size.width * .12f, hipY)
                lineTo(cx - size.width * .15f, bottom)
                lineTo(cx - size.width * .03f, bottom)
                lineTo(cx, kneeY)
                lineTo(cx + size.width * .035f, bottom)
                lineTo(cx + size.width * .15f, bottom)
                lineTo(cx + size.width * .12f, hipY)
                close()
            }
            drawPath(
                lower,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF161A21),
                        Color(0xFF080A0E)
                    )
                )
            )

            // Gold trim
            drawLine(
                color = HL.Gold.copy(alpha = .80f),
                start = Offset(cx + size.width * .10f, hipY + size.height * .02f),
                end = Offset(cx + size.width * .13f, bottom),
                strokeWidth = size.width * .0055f
            )

        } else {
            // Male hero
            val hair = Path().apply {
                moveTo(cx - size.width * .07f, headY - size.height * .044f)
                lineTo(cx - size.width * .025f, headY - size.height * .080f)
                lineTo(cx + size.width * .070f, headY - size.height * .058f)
                lineTo(cx + size.width * .078f, headY - size.height * .010f)
                close()
            }
            drawPath(hair, Color(0xFF161719))

            drawOval(
                color = Color(0xFFD7A78E),
                topLeft = Offset(cx - size.width * .060f, headY - size.height * .044f),
                size = Size(size.width * .120f, size.height * .105f)
            )

            // Eyes
            drawCircle(
                color = Color(0xFF2A2421),
                radius = size.width * .005f,
                center = Offset(cx - size.width * .022f, headY + size.height * .004f)
            )
            drawCircle(
                color = Color(0xFF2A2421),
                radius = size.width * .005f,
                center = Offset(cx + size.width * .022f, headY + size.height * .004f)
            )

            // Coat
            val coat = Path().apply {
                moveTo(cx, shoulderY)
                lineTo(cx - size.width * .19f, shoulderY + size.height * .05f)
                lineTo(cx - size.width * .21f, bottom)
                lineTo(cx + size.width * .19f, bottom)
                lineTo(cx + size.width * .17f, shoulderY + size.height * .05f)
                close()
            }
            drawPath(
                coat,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF262A31),
                        Color(0xFF11161D),
                        Color(0xFF070A0F)
                    )
                )
            )

            // Lapels
            drawLine(
                color = HL.Gold,
                start = Offset(cx - size.width * .05f, shoulderY + size.height * .02f),
                end = Offset(cx + size.width * .01f, waistY),
                strokeWidth = size.width * .007f
            )
            drawLine(
                color = HL.Gold,
                start = Offset(cx + size.width * .05f, shoulderY + size.height * .02f),
                end = Offset(cx + size.width * .01f, waistY),
                strokeWidth = size.width * .007f
            )

            // Belt
            drawLine(
                color = HL.Gold,
                start = Offset(cx - size.width * .105f, waistY + size.height * .02f),
                end = Offset(cx + size.width * .11f, waistY + size.height * .02f),
                strokeWidth = size.width * .008f
            )

            // Arms
            drawLine(
                color = Color(0xFFD0A087),
                start = Offset(cx - size.width * .16f, shoulderY + size.height * .06f),
                end = Offset(cx - size.width * .19f, size.height * .61f),
                strokeWidth = size.width * .041f
            )
            drawLine(
                color = Color(0xFFD0A087),
                start = Offset(cx + size.width * .15f, shoulderY + size.height * .06f),
                end = Offset(cx + size.width * .17f, size.height * .59f),
                strokeWidth = size.width * .041f
            )

            // Lower split
            drawLine(
                color = Color(0xFF1C222B),
                start = Offset(cx, hipY),
                end = Offset(cx, bottom),
                strokeWidth = size.width * .008f
            )

            drawLine(
                color = HL.Gold.copy(alpha = .76f),
                start = Offset(cx + size.width * .095f, hipY),
                end = Offset(cx + size.width * .125f, bottom),
                strokeWidth = size.width * .005f
            )
        }
    }
}
