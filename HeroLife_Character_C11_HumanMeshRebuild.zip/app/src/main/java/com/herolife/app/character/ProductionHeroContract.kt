package com.herolife.app.character

object ProductionHeroContract {
    const val FEMALE_GLB = "models/female_realistic_01.glb"
    const val MALE_GLB = "models/male_realistic_01.glb"

    // The renderer keeps the entire lobby independent from character art.
    // Replacing only these files is enough for a production model swap.
    val requiredPbrChannels = listOf(
        "BaseColor/Albedo",
        "Normal",
        "Metallic",
        "Roughness",
        "Skin",
        "Eyes",
        "Hair",
        "Armor/Cloth"
    )

    val recommendedAnimationClips = listOf(
        "Idle",
        "Breathing",
        "TurnLeft",
        "TurnRight"
    )
}
