package com.herolife.app.character

object HumanoidSkeleton {
    val requiredBones = listOf(
        "Root", "Hips",
        "Spine", "Chest", "UpperChest",
        "Neck", "Head",
        "LeftShoulder", "LeftUpperArm", "LeftLowerArm", "LeftHand",
        "RightShoulder", "RightUpperArm", "RightLowerArm", "RightHand",
        "LeftUpperLeg", "LeftLowerLeg", "LeftFoot",
        "RightUpperLeg", "RightLowerLeg", "RightFoot"
    )

    fun missingFrom(bones: Collection<String>): List<String> =
        requiredBones.filterNot { it in bones }
}
