package com.shahriar.gamification

import android.content.Context

object SettingsStorage {
    private const val PREFS = "app_settings"
    private const val KEY_DEFAULT_GAME = "default_game_minutes"
    private const val KEY_SOUND = "sound_enabled"
    private const val KEY_VIBRATION = "vibration_enabled"
    private const val KEY_EFFECTS = "motivational_effects_enabled"
    private const val KEY_CONFIRM_DELETE = "confirm_delete_enabled"

    fun load(context: Context): AppSettings {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return AppSettings(
            defaultGameMinutes = prefs.getInt(KEY_DEFAULT_GAME, 30),
            soundEnabled = prefs.getBoolean(KEY_SOUND, true),
            vibrationEnabled = prefs.getBoolean(KEY_VIBRATION, true),
            motivationalEffectsEnabled = prefs.getBoolean(KEY_EFFECTS, true),
            confirmDeleteEnabled = prefs.getBoolean(KEY_CONFIRM_DELETE, true)
        )
    }

    fun save(context: Context, settings: AppSettings) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_DEFAULT_GAME, settings.defaultGameMinutes)
            .putBoolean(KEY_SOUND, settings.soundEnabled)
            .putBoolean(KEY_VIBRATION, settings.vibrationEnabled)
            .putBoolean(KEY_EFFECTS, settings.motivationalEffectsEnabled)
            .putBoolean(KEY_CONFIRM_DELETE, settings.confirmDeleteEnabled)
            .apply()
    }
}
