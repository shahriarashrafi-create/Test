# Character C01 — Female Base Mesh Production
Custom female base mesh created from scratch for HeroLife.
- Vertices: 9,060
- Triangles: 17,040
- Y-up, feet near origin, front-facing
- Denser human-oriented body proportions
- Face, nose, eyes and lips prepared as C02 landmarks
- Neutral clay PBR material
- No companion

C01 is a geometry foundation, not a claim of final photorealism.
Next: C02 Face Anatomy & Topology.
