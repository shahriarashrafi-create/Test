package com.herolife.app.character

import android.content.Context
import com.herolife.app.model.HeroGender

data class HeroAssetChoice(
    val id: String,
    val titleFa: String,
    val gender: HeroGender,
    val productionPath: String,
    val fallbackPath: String
)

object ProductionHeroAssets {
    val female = HeroAssetChoice(
        id = "female_photoreal",
        titleFa = "قهرمان زن",
        gender = HeroGender.FEMALE,
        productionPath = "models/production/female_photoreal.glb",
        fallbackPath = "models/production/female_procedural_fallback.glb"
    )

    val male = HeroAssetChoice(
        id = "male_photoreal",
        titleFa = "قهرمان مرد",
        gender = HeroGender.MALE,
        productionPath = "models/production/male_photoreal.glb",
        fallbackPath = "models/male_realistic_01.glb"
    )

    fun forGender(gender: HeroGender): HeroAssetChoice =
        if (gender == HeroGender.FEMALE) female else male

    fun resolvePath(context: Context, gender: HeroGender): String =
        RealHumanAssetResolver.resolve(context, gender)

    fun isProductionInstalled(context: Context, gender: HeroGender): Boolean =
        assetExists(context, forGender(gender).productionPath)


    fun fallbackPath(gender: HeroGender): String =
        forGender(gender).fallbackPath

    private fun assetExists(context: Context, path: String): Boolean =
        try {
            context.assets.open(path).close()
            true
        } catch (_: Throwable) {
            false
        }
}
