package com.herolife.app.character

import android.content.Context
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class GlbMaterial(
    val baseColor: FloatArray = floatArrayOf(.72f,.72f,.72f,1f),
    val metallic: Float = 0f,
    val roughness: Float = .65f,
    val baseColorTexture: Int? = null,
    val normalTexture: Int? = null,
    val metallicRoughnessTexture: Int? = null,
    val emissiveTexture: Int? = null
)

data class GlbPrimitive(
    // 16 floats per vertex:
    // pos3 normal3 uv2 joints4 weights4
    val vertices: FloatArray,
    val indices: IntArray,
    val material: GlbMaterial,
    val skinned: Boolean
)

data class GlbBounds(
    val minX: Float, val minY: Float, val minZ: Float,
    val maxX: Float, val maxY: Float, val maxZ: Float
) {
    val height: Float get() = (maxY - minY).coerceAtLeast(.001f)
    val centerX: Float get() = (minX + maxX) * .5f
    val centerY: Float get() = (minY + maxY) * .5f
    val centerZ: Float get() = (minZ + maxZ) * .5f
}

data class GlbModel(
    val primitives: List<GlbPrimitive>,
    val bounds: GlbBounds,
    val hasSkinning: Boolean
)

class GlbLoader(private val context: Context) {
    fun load(path: String): GlbModel {
        val bytes = context.assets.open(path).use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(bb.int == 0x46546C67) { "Not GLB" }
        require(bb.int == 2) { "Only GLB 2.0 supported" }
        bb.int

        var json: JSONObject? = null
        var bin = ByteArray(0)
        while (bb.remaining() >= 8) {
            val len = bb.int
            val type = bb.int
            val chunk = ByteArray(len)
            bb.get(chunk)
            when(type) {
                0x4E4F534A -> json = JSONObject(String(chunk, Charsets.UTF_8).trim())
                0x004E4942 -> bin = chunk
            }
        }

        val doc = requireNotNull(json)
        val accessors = doc.getJSONArray("accessors")
        val views = doc.getJSONArray("bufferViews")
        val mats = doc.optJSONArray("materials")

        fun components(type:String)=when(type) {
            "SCALAR"->1; "VEC2"->2; "VEC3"->3; "VEC4"->4; "MAT4"->16
            else->error("Unsupported accessor $type")
        }

        fun floats(index:Int):FloatArray {
            val a=accessors.getJSONObject(index)
            val v=views.getJSONObject(a.getInt("bufferView"))
            val c=components(a.getString("type"))
            require(a.getInt("componentType")==5126)
            val count=a.getInt("count")
            val offset=v.optInt("byteOffset",0)+a.optInt("byteOffset",0)
            val stride=v.optInt("byteStride",c*4)
            val b=ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
            return FloatArray(count*c).also { out ->
                for(i in 0 until count) {
                    b.position(offset+i*stride)
                    for(k in 0 until c) out[i*c+k]=b.float
                }
            }
        }

        fun joints(index:Int):FloatArray {
            val a=accessors.getJSONObject(index)
            val v=views.getJSONObject(a.getInt("bufferView"))
            val c=components(a.getString("type"))
            require(c==4)
            val count=a.getInt("count")
            val offset=v.optInt("byteOffset",0)+a.optInt("byteOffset",0)
            val comp=a.getInt("componentType")
            val size=if(comp==5121) 1 else 2
            val stride=v.optInt("byteStride",c*size)
            val b=ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
            return FloatArray(count*4).also { out ->
                for(i in 0 until count) {
                    b.position(offset+i*stride)
                    for(k in 0..3) out[i*4+k]=when(comp) {
                        5121 -> (b.get().toInt() and 255).toFloat()
                        5123 -> (b.short.toInt() and 65535).toFloat()
                        else -> error("Unsupported JOINTS component type")
                    }
                }
            }
        }

        fun indices(index:Int):IntArray {
            val a=accessors.getJSONObject(index)
            val v=views.getJSONObject(a.getInt("bufferView"))
            val b=ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
            b.position(v.optInt("byteOffset",0)+a.optInt("byteOffset",0))
            return IntArray(a.getInt("count")) {
                when(a.getInt("componentType")) {
                    5121 -> b.get().toInt() and 255
                    5123 -> b.short.toInt() and 65535
                    5125 -> b.int
                    else -> error("Unsupported index type")
                }
            }
        }

        fun material(index:Int?):GlbMaterial {
            if(index==null || mats==null) return GlbMaterial()
            val m=mats.getJSONObject(index)
            val pbr=m.optJSONObject("pbrMetallicRoughness")
            val color=floatArrayOf(.72f,.72f,.72f,1f)
            pbr?.optJSONArray("baseColorFactor")?.let { a ->
                if(a.length()>=4) for(i in 0..3) color[i]=a.getDouble(i).toFloat()
            }
            fun tex(parent:JSONObject?,key:String):Int? =
                parent?.optJSONObject(key)?.takeIf { it.has("index") }?.getInt("index")
            return GlbMaterial(
                baseColor=color,
                metallic=pbr?.optDouble("metallicFactor",0.0)?.toFloat() ?: 0f,
                roughness=pbr?.optDouble("roughnessFactor",.65)?.toFloat() ?: .65f,
                baseColorTexture=tex(pbr,"baseColorTexture"),
                normalTexture=tex(m,"normalTexture"),
                metallicRoughnessTexture=tex(pbr,"metallicRoughnessTexture"),
                emissiveTexture=tex(m,"emissiveTexture")
            )
        }

        var minX=Float.POSITIVE_INFINITY; var minY=Float.POSITIVE_INFINITY; var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY; var maxY=Float.NEGATIVE_INFINITY; var maxZ=Float.NEGATIVE_INFINITY
        val result=mutableListOf<GlbPrimitive>()
        var modelSkinned=false

        val meshes=doc.getJSONArray("meshes")
        for(mi in 0 until meshes.length()) {
            val ps=meshes.getJSONObject(mi).getJSONArray("primitives")
            for(i in 0 until ps.length()) {
                val p=ps.getJSONObject(i)
                val attrs=p.getJSONObject("attributes")
                val pos=floats(attrs.getInt("POSITION"))
                val norm=if(attrs.has("NORMAL")) floats(attrs.getInt("NORMAL")) else FloatArray(pos.size)
                val uv=if(attrs.has("TEXCOORD_0")) floats(attrs.getInt("TEXCOORD_0")) else FloatArray((pos.size/3)*2)
                val hasSkin=attrs.has("JOINTS_0") && attrs.has("WEIGHTS_0")
                val joint=if(hasSkin) joints(attrs.getInt("JOINTS_0")) else FloatArray((pos.size/3)*4)
                val weight=if(hasSkin) floats(attrs.getInt("WEIGHTS_0")) else FloatArray((pos.size/3)*4).also {
                    for(v in 0 until pos.size/3) it[v*4]=1f
                }
                modelSkinned = modelSkinned || hasSkin

                val count=pos.size/3
                val inter=FloatArray(count*16)
                for(v in 0 until count) {
                    val x=pos[v*3]; val y=pos[v*3+1]; val z=pos[v*3+2]
                    minX=minOf(minX,x); minY=minOf(minY,y); minZ=minOf(minZ,z)
                    maxX=maxOf(maxX,x); maxY=maxOf(maxY,y); maxZ=maxOf(maxZ,z)
                    val b=v*16
                    inter[b]=x; inter[b+1]=y; inter[b+2]=z
                    inter[b+3]=norm[v*3]; inter[b+4]=norm[v*3+1]; inter[b+5]=norm[v*3+2]
                    inter[b+6]=uv.getOrElse(v*2){0f}; inter[b+7]=uv.getOrElse(v*2+1){0f}
                    for(k in 0..3) inter[b+8+k]=joint[v*4+k]
                    for(k in 0..3) inter[b+12+k]=weight[v*4+k]
                }

                val sourceIndices=indices(p.getInt("indices"))
                val remap=LinkedHashMap<Int,Int>()
                val compact=ArrayList<Float>()
                val localIndices=IntArray(sourceIndices.size)
                sourceIndices.forEachIndexed { ip, sourceVertex ->
                    val local=remap.getOrPut(sourceVertex) {
                        val next=remap.size
                        val b=sourceVertex*16
                        repeat(16) { compact.add(inter[b+it]) }
                        next
                    }
                    localIndices[ip]=local
                }

                result += GlbPrimitive(
                    vertices=FloatArray(compact.size){compact[it]},
                    indices=localIndices,
                    material=material(if(p.has("material")) p.getInt("material") else null),
                    skinned=hasSkin
                )
            }
        }

        if(!minX.isFinite()) {
            minX=-.5f; minY=0f; minZ=-.5f; maxX=.5f; maxY=1f; maxZ=.5f
        }
        return GlbModel(result,GlbBounds(minX,minY,minZ,maxX,maxY,maxZ),modelSkinned)
    }
}
