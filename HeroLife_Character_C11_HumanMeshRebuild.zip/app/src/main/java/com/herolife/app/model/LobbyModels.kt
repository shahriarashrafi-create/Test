package com.herolife.app.model

enum class HeroGender {
    MALE,
    FEMALE
}

enum class LobbyDestination {
    HOME,
    TASKS,
    STATS,
    REWARDS,
    MORE,
    SHOP,
    EVENTS,
    ACHIEVEMENTS,
    START
}

data class HeroSelection(
    val gender: HeroGender = HeroGender.FEMALE,
    val variant: Int = 0
)

data class LobbyState(
    val hero: HeroSelection = HeroSelection(),
    val destination: LobbyDestination = LobbyDestination.HOME
)
