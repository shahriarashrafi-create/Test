package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.herolife.app.model.HeroGender
import com.herolife.app.model.HeroSelection
import com.herolife.app.ui.theme.HL

@Composable
fun HeroLayer(
    selection: HeroSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Canvas(
        modifier = modifier.clickable(onClick = onClick)
    ) {
        val cx = size.width * .52f
        val headY = size.height * .18f
        val bodyTop = size.height * .25f
        val bodyBottom = size.height * .92f

        drawCircle(
            color = HL.Gold.copy(alpha = .09f),
            radius = size.width * .42f,
            center = Offset(cx, size.height * .44f)
        )

        if (selection.gender == HeroGender.FEMALE) {
            drawCircle(
                color = Color(0xFFE3B79F),
                radius = size.width * .075f,
                center = Offset(cx, headY)
            )

            val hair = Path().apply {
                moveTo(cx - size.width * .09f, headY)
                lineTo(cx - size.width * .13f, size.height * .34f)
                lineTo(cx - size.width * .08f, size.height * .48f)
                lineTo(cx + size.width * .10f, size.height * .47f)
                lineTo(cx + size.width * .13f, size.height * .28f)
                close()
            }
            drawPath(hair, Color(0xFF2B1B17))

            val body = Path().apply {
                moveTo(cx, bodyTop)
                lineTo(cx - size.width * .17f, size.height * .39f)
                lineTo(cx - size.width * .15f, bodyBottom)
                lineTo(cx + size.width * .18f, bodyBottom)
                lineTo(cx + size.width * .13f, size.height * .39f)
                close()
            }
            drawPath(body, Color(0xFF11151E))

            drawLine(
                color = HL.Gold,
                start = Offset(cx - size.width * .10f, size.height * .42f),
                end = Offset(cx + size.width * .11f, size.height * .42f),
                strokeWidth = 3f
            )
        } else {
            drawCircle(
                color = Color(0xFFD4AA91),
                radius = size.width * .072f,
                center = Offset(cx, headY)
            )

            val coat = Path().apply {
                moveTo(cx, bodyTop)
                lineTo(cx - size.width * .18f, size.height * .40f)
                lineTo(cx - size.width * .22f, bodyBottom)
                lineTo(cx + size.width * .19f, bodyBottom)
                lineTo(cx + size.width * .15f, size.height * .39f)
                close()
            }
            drawPath(coat, Color(0xFF10151D))
            drawLine(
                color = HL.Gold,
                start = Offset(cx + size.width * .08f, size.height * .36f),
                end = Offset(cx + size.width * .13f, size.height * .78f),
                strokeWidth = 4f
            )
        }
    }
}
