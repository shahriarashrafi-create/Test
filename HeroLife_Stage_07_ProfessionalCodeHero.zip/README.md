# HeroLife Stage 07 — Professional Code Hero

Stage 07 keeps the clean layered architecture and improves only the lobby visuals.

## What changed
- Companion removed completely
- Hero remains 100% code-drawn
- More detailed female/male hero silhouettes
- richer environment depth
- left-side menu restored
- quote panel reduced and positioned independently
- rank card reduced and redesigned
- Start Game button refined
- emoji navigation icons removed
- custom Canvas icons added
- top HUD compacted
- no screenshots, no crops, no bitmap mockup background

## Architecture
Every visual element remains separate:
Environment / Hero / Top HUD / Side Menu / Quote / Rank / Start / Bottom Navigation

The next upgrade can continue improving only the HeroLayer without touching any other UI.
