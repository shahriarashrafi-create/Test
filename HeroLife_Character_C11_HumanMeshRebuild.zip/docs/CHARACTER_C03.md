# C03 — Hair Volume & Silhouette

This stage responds directly to the C02 device screenshot.

Changes:
- rebuilt the upper-body silhouette with narrower shoulders and softer proportions
- added a full dark-brown hair system as independent GLB material geometry
- crown volume, back hair mass, side waves and face-framing locks
- separate eyebrow/eyelash material
- separate eye and lip materials for facial readability
- adjusted renderer key/fill/rim balance so dark hair remains visible
- no companion

Stats:
- 24,400 vertices
- 46,000 triangles
- 56 independent GLB primitives

C03 is still geometry/material-blocking. It is not final photoreal hair.
Next: C04 — Black/Gold Outfit & Armor silhouette.
