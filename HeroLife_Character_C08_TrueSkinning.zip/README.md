# HeroLife Character C08 — True Skinning

Cumulative replacement for C07.

Major upgrade:
- real JOINTS_0 / WEIGHTS_0 embedded in female production GLB
- real 10-bone Skin object
- GPU skinning in the GLES2 vertex shader
- weighted breathing / torso / head / arm idle deformation
- 4 bone influences maximum
- C06.1 runtime-memory fix preserved
- 360° hero rotation preserved
- no companion

Use this ZIP as the only cumulative ZIP in GitHub.
