package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.herolife.app.ui.theme.HL
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun EnvironmentLayer(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF273A54),
                    Color(0xFF172A42),
                    Color(0xFF0B182A),
                    HL.Void
                )
            )
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFFFD99A).copy(alpha = .22f),
                    Color(0xFFFFD99A).copy(alpha = .08f),
                    Color.Transparent
                )
            ),
            radius = size.width * .42f,
            center = Offset(
                size.width * .72f,
                size.height * .18f
            )
        )

        val far = Path().apply {
            moveTo(0f, size.height * .44f)
            lineTo(size.width * .10f, size.height * .28f)
            lineTo(size.width * .22f, size.height * .46f)
            lineTo(size.width * .35f, size.height * .24f)
            lineTo(size.width * .50f, size.height * .47f)
            lineTo(size.width * .65f, size.height * .20f)
            lineTo(size.width * .80f, size.height * .43f)
            lineTo(size.width, size.height * .30f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(far, Color(0xFF203A55))

        val near = Path().apply {
            moveTo(0f, size.height * .61f)
            lineTo(size.width * .16f, size.height * .40f)
            lineTo(size.width * .30f, size.height * .62f)
            lineTo(size.width * .46f, size.height * .36f)
            lineTo(size.width * .60f, size.height * .61f)
            lineTo(size.width * .79f, size.height * .41f)
            lineTo(size.width, size.height * .58f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(near, Color(0xFF10263B))

        repeat(11) { index ->
            val x = size.width * (.55f + index * .037f)
            val towerWidth = size.width * (.022f + (index % 2) * .006f)
            val towerHeight = size.height * (.08f + (index % 5) * .018f)
            val baseY = size.height * .47f

            drawRect(
                color = Color(0xFF304963),
                topLeft = Offset(
                    x,
                    baseY - towerHeight
                ),
                size = Size(
                    towerWidth,
                    towerHeight
                )
            )

            drawLine(
                color = HL.Gold.copy(alpha = .28f),
                start = Offset(
                    x + towerWidth / 2f,
                    baseY - towerHeight
                ),
                end = Offset(
                    x + towerWidth / 2f,
                    baseY - towerHeight - size.height * .025f
                ),
                strokeWidth = 1.6f
            )

            repeat(3) { floor ->
                drawCircle(
                    color = HL.Gold.copy(alpha = .25f),
                    radius = 1.8f,
                    center = Offset(
                        x + towerWidth * .5f,
                        baseY - towerHeight * (.20f + floor * .22f)
                    )
                )
            }
        }

        repeat(20) { index ->
            val x = size.width * ((index * 37 % 100) / 100f)
            val y = size.height * (.09f + ((index * 23 % 44) / 100f))

            drawCircle(
                color = Color.White.copy(alpha = .05f + (index % 4) * .015f),
                radius = 1.3f + (index % 3),
                center = Offset(x, y)
            )
        }

        // subtle birds
        repeat(5) { index ->
            val x = size.width * (.18f + index * .12f)
            val y = size.height * (.18f + .02f * sin(index.toFloat()))
            val span = size.width * .012f
            drawLine(
                color = Color(0xFFB7C5D6).copy(alpha = .42f),
                start = Offset(x - span, y),
                end = Offset(x, y - span * .45f),
                strokeWidth = 1.3f
            )
            drawLine(
                color = Color(0xFFB7C5D6).copy(alpha = .42f),
                start = Offset(x, y - span * .45f),
                end = Offset(x + span, y),
                strokeWidth = 1.3f
            )
        }

        val terraceY = size.height * .69f

        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color(0xFF1C3144),
                    Color(0xFF0C1725)
                )
            ),
            topLeft = Offset(0f, terraceY),
            size = Size(size.width, size.height - terraceY)
        )

        repeat(8) { index ->
            val x = size.width * (.05f + index * .135f)
            val y = terraceY + size.height * .08f

            drawCircle(
                color = HL.Gold.copy(alpha = .14f),
                radius = size.width * .035f,
                center = Offset(x, y)
            )
            drawCircle(
                color = HL.Gold.copy(alpha = .55f),
                radius = size.width * .008f,
                center = Offset(x, y)
            )
        }

        // mist/fog bands
        repeat(4) { band ->
            drawRect(
                color = Color.White.copy(alpha = .018f + band * .008f),
                topLeft = Offset(
                    0f,
                    size.height * (.50f + band * .06f)
                ),
                size = Size(
                    size.width,
                    size.height * .035f
                )
            )
        }

        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color.Transparent,
                    HL.Void.copy(alpha = .12f),
                    HL.Void.copy(alpha = .86f)
                )
            ),
            topLeft = Offset(
                0f,
                size.height * .48f
            ),
            size = Size(
                size.width,
                size.height * .52f
            )
        )
    }
}
