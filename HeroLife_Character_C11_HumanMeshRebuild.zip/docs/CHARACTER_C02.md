# C02 — Female Face Anatomy & Topology
Focused rebuild after C01 screenshot validation.

Changes:
- narrower shoulders and waist, revised pelvis and limb proportions
- separate jaw and chin shaping
- eye globes plus upper eyelid volumes
- nose bridge, tip and alar wings
- separate upper/lower lip volumes
- cheek volumes and ears
- front-facing production GLB retained
- no companion

Stats: 15,208 vertices / 28,648 triangles.

This remains a sculpt/base stage. Hair, skin textures and final PBR realism are intentionally later stages.
