# HeroLife Stage 14 — Renderer Fix + PBR Production Ready

Cumulative ZIP based on Stage 13.

Changes:
- OpenGL hero surface forced transparent and placed over the lobby without an intentional black background.
- Hero camera/framing enlarged and made safer for horizontal rotation.
- Brighter key/fill/rim-style shading so face/body are not swallowed by darkness.
- Character remains an isolated replaceable GLB layer.
- Female/male switching and drag rotation remain.
- Companion remains removed.
- Added a stable production GLB contract for BaseColor, Normal, Metallic/Roughness,
  Hair, Eye, Skin and Armor materials, plus optional skeleton/animation.

Important:
The bundled female/male GLBs are pipeline verification assets, not photoreal final art.
For reference-level realism, replace them with professionally authored/licensed GLBs using
the same filenames. The lobby layout does not need to be redesigned when that happens.
