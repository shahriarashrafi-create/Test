package com.shahriar.gamification

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object TeamStatsStorage {
    private const val PREFS = "team_stats_preferences"
    private const val KEY_MEMBERS = "team_members_json"

    fun load(context: Context): List<TeamMember> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_MEMBERS, null)

        if (raw.isNullOrBlank()) {
            return defaults()
        }

        return runCatching {
            val array = JSONArray(raw)
            val result = mutableListOf<TeamMember>()

            var index = 0
            while (index < array.length()) {
                val obj = array.getJSONObject(index)

                val parentValue = if (
                    obj.has("parentId") &&
                    !obj.isNull("parentId")
                ) {
                    obj.optLong("parentId")
                } else {
                    null
                }

                result.add(
                    TeamMember(
                        id = obj.optLong(
                            "id",
                            System.currentTimeMillis() + index
                        ),
                        name = obj.optString("name", "عضو"),
                        parentId = parentValue,
                        sales = obj.optLong("sales", 0L).coerceAtLeast(0L),
                        targetSales = obj.optLong(
                            "targetSales",
                            0L
                        ).coerceAtLeast(0L),
                        growthPercent = obj.optInt(
                            "growthPercent",
                            0
                        ).coerceIn(-100, 1000),
                        connections = obj.optInt(
                            "connections",
                            0
                        ).coerceAtLeast(0),
                        preConsults = obj.optInt(
                            "preConsults",
                            0
                        ).coerceAtLeast(0),
                        invites = obj.optInt(
                            "invites",
                            0
                        ).coerceAtLeast(0),
                        presentations = obj.optInt(
                            "presentations",
                            0
                        ).coerceAtLeast(0),
                        followUps = obj.optInt(
                            "followUps",
                            0
                        ).coerceAtLeast(0)
                    )
                )

                index++
            }

            result
        }.getOrElse {
            defaults()
        }
    }

    fun save(
        context: Context,
        members: List<TeamMember>
    ) {
        val array = JSONArray()

        var index = 0
        while (index < members.size) {
            val member = members[index]
            val obj = JSONObject()

            obj.put("id", member.id)
            obj.put("name", member.name)

            if (member.parentId == null) {
                obj.put("parentId", JSONObject.NULL)
            } else {
                obj.put("parentId", member.parentId)
            }

            obj.put("sales", member.sales)
            obj.put("targetSales", member.targetSales)
            obj.put("growthPercent", member.growthPercent)
            obj.put("connections", member.connections)
            obj.put("preConsults", member.preConsults)
            obj.put("invites", member.invites)
            obj.put("presentations", member.presentations)
            obj.put("followUps", member.followUps)

            array.put(obj)
            index++
        }

        context.getSharedPreferences(
            PREFS,
            Context.MODE_PRIVATE
        )
            .edit()
            .putString(KEY_MEMBERS, array.toString())
            .apply()
    }

    private fun defaults(): List<TeamMember> {
        return listOf(
            TeamMember(
                id = 5001,
                name = "شهریار",
                parentId = null,
                sales = 0,
                targetSales = 0,
                growthPercent = 20,
                connections = 0,
                preConsults = 0,
                invites = 0,
                presentations = 0,
                followUps = 0
            ),
            TeamMember(
                id = 5002,
                name = "عضو نمونه ۱",
                parentId = 5001,
                sales = 0,
                targetSales = 0,
                growthPercent = 20,
                connections = 0,
                preConsults = 0,
                invites = 0,
                presentations = 0,
                followUps = 0
            ),
            TeamMember(
                id = 5003,
                name = "عضو نمونه ۲",
                parentId = 5001,
                sales = 0,
                targetSales = 0,
                growthPercent = 20,
                connections = 0,
                preConsults = 0,
                invites = 0,
                presentations = 0,
                followUps = 0
            )
        )
    }
}
