package com.shahriar.gamification

enum class RewardCurrency {
    DIAMOND,
    GOLD
}

data class RewardItem(
    val id: Long,
    val title: String,
    val cost: Int,
    val note: String,
    val currency: RewardCurrency
)
