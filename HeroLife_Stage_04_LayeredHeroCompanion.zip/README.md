# HeroLife — Stage 04: Layered Hero & Companion

Full cumulative replacement for Stage 03.

## What this fixes
- removes the Stage 03 stacked-picture composition
- hero and companion are independently selectable
- male/female hero filtering
- attractive cinematic female hero option
- male hero retained
- companion options: lion, white tiger, shadow wolf, night panther
- persistent selections
- swipe/drag preview for hero and companion
- immersive fullscreen remains enabled
- UI remains a real Compose interface rather than a screenshot with click zones

## Important technical note
The drag preview in this stage is a perspective rotation preview of 2D character assets.
A true 360-degree view requires a real 3D mesh/model and renderer. The architecture now
isolates character/companion selection so a 3D renderer can replace only the preview layer
without rebuilding the rest of the app.
