# HeroLife production photoreal GLB contract

The app is now structurally ready for professional photoreal GLB characters.

Keep these filenames:
- female_realistic_01.glb
- male_realistic_01.glb

A final production asset should include:
- realistic adult humanoid topology
- UVs
- BaseColor/Albedo textures
- Normal maps
- Metallic/Roughness maps
- separate Skin material
- separate Eye material
- separate Hair material
- Armor/Cloth materials
- mobile-optimized LOD/polycount
- optional rig + Idle/Breathing/Turn animations

Important:
The GLBs bundled in this ZIP are still verification models. This environment cannot author a
genuinely photoreal textured human GLB from scratch. Replace only these two GLB files with
professionally authored/licensed assets and the lobby layout will remain unchanged.
