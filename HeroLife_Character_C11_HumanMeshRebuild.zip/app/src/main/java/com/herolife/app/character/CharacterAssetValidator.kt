package com.herolife.app.character

import android.content.Context

data class CharacterAssetValidation(
    val valid: Boolean,
    val message: String
)

object CharacterAssetValidator {
    fun validate(context: Context, spec: ProductionCharacterSpec): CharacterAssetValidation {
        return try {
            context.assets.open(spec.assetPath).use { stream ->
                val header = ByteArray(12)
                val read = stream.read(header)
                if (read < 12) return CharacterAssetValidation(false, "GLB header is incomplete")
                val magic = String(header.copyOfRange(0, 4), Charsets.US_ASCII)
                if (magic != "glTF") {
                    CharacterAssetValidation(false, "Asset is not a binary glTF/GLB file")
                } else {
                    CharacterAssetValidation(true, "Production GLB contract passed")
                }
            }
        } catch (t: Throwable) {
            CharacterAssetValidation(false, t.message ?: "Character asset could not be opened")
        }
    }
}
