package com.shahriar.gamification

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TaskPanel = Color(0xF20A1931)
private val TaskDeep = Color(0xF2071428)
private val TaskGold = Color(0xFFFFC857)
private val TaskCyan = Color(0xFF39D7FF)
private val TaskPurple = Color(0xFFBE78FF)
private val TaskRed = Color(0xFFFF8585)
private val TaskWhite = Color(0xFFF8FAFF)
private val TaskMuted = Color(0xFFAFC0D8)

private enum class TaskFilter {
    ALL, ACTIVE, INACTIVE
}

@Composable
fun GameTasksScreen(
    padding: PaddingValues,
    tasks: List<GameTaskItem>,
    onAdd: (GameTaskItem) -> Unit,
    onEdit: (GameTaskItem) -> Unit,
    onDelete: (GameTaskItem) -> Unit,
    onToggleActive: (GameTaskItem, Boolean) -> Unit,
    onMove: (Int, Int) -> Unit
) {
    var filter by remember { mutableStateOf(TaskFilter.ALL) }
    var editing by remember { mutableStateOf<GameTaskItem?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    val filteredTasks = when (filter) {
        TaskFilter.ALL -> tasks
        TaskFilter.ACTIVE -> tasks.filter { it.active }
        TaskFilter.INACTIVE -> tasks.filter { !it.active }
    }

    val activeCount = tasks.count { it.active }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "کارها",
                    color = TaskWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 25.sp
                )
                Text(
                    text = "بانک مأموریت‌های بازی",
                    color = TaskMuted,
                    fontSize = 10.sp
                )
            }

            Surface(
                modifier = Modifier
                    .size(46.dp)
                    .clickable {
                        editing = null
                        showEditor = true
                    },
                shape = RoundedCornerShape(15.dp),
                color = TaskCyan.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, TaskCyan.copy(alpha = 0.42f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "افزودن کار",
                        tint = TaskCyan
                    )
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = TaskPanel,
            border = BorderStroke(1.dp, TaskGold.copy(alpha = 0.24f))
        ) {
            Row(
                modifier = Modifier.padding(13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = TaskGold.copy(alpha = 0.10f)
                ) {
                    Box(
                        modifier = Modifier.size(46.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Sort,
                            contentDescription = null,
                            tint = TaskGold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$activeCount کار فعال از ${tasks.size}",
                        color = TaskWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "دسته‌ی نقطه‌چین را نگه دار و بالا/پایین بکش. فلش‌ها هم برای جابه‌جایی دقیق هستند.",
                        color = TaskMuted,
                        fontSize = 9.sp
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterButton(
                modifier = Modifier.weight(1f),
                title = "همه",
                selected = filter == TaskFilter.ALL,
                onClick = { filter = TaskFilter.ALL }
            )
            FilterButton(
                modifier = Modifier.weight(1f),
                title = "فعال",
                selected = filter == TaskFilter.ACTIVE,
                onClick = { filter = TaskFilter.ACTIVE }
            )
            FilterButton(
                modifier = Modifier.weight(1f),
                title = "غیرفعال",
                selected = filter == TaskFilter.INACTIVE,
                onClick = { filter = TaskFilter.INACTIVE }
            )
        }

        if (filter != TaskFilter.ALL) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(15.dp),
                color = TaskGold.copy(alpha = 0.06f),
                border = BorderStroke(1.dp, TaskGold.copy(alpha = 0.13f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Rounded.FilterList,
                        contentDescription = null,
                        tint = TaskGold,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "تغییر ترتیب فقط در فیلتر «همه» فعال است.",
                        color = TaskMuted,
                        fontSize = 9.sp
                    )
                }
            }
        }

        if (filteredTasks.isEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = TaskPanel,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Rounded.EmojiEvents,
                        contentDescription = null,
                        tint = TaskMuted,
                        modifier = Modifier.size(34.dp)
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(
                        "کاری در این بخش نیست",
                        color = TaskWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 18.dp)
            ) {
                itemsIndexed(
                    items = filteredTasks,
                    key = { _, item -> item.id }
                ) { filteredIndex, item ->
                    val realIndex = tasks.indexOfFirst { it.id == item.id }

                    TaskCard(
                        item = item,
                        reorderEnabled = filter == TaskFilter.ALL,
                        canMoveUp = realIndex > 0,
                        canMoveDown = realIndex >= 0 && realIndex < tasks.lastIndex,
                        tasks = tasks,
                        onMove = onMove,
                        onEdit = {
                            editing = item
                            showEditor = true
                        },
                        onDelete = { onDelete(item) },
                        onToggleActive = { active ->
                            onToggleActive(item, active)
                        }
                    )
                }
            }
        }
    }

    if (showEditor) {
        TaskEditorDialog(
            initial = editing,
            nextOrder = tasks.size + 1,
            onDismiss = { showEditor = false },
            onSave = { item ->
                if (editing == null) {
                    onAdd(item)
                } else {
                    onEdit(item)
                }
                showEditor = false
            }
        )
    }
}

@Composable
private fun TaskCard(
    item: GameTaskItem,
    reorderEnabled: Boolean,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    tasks: List<GameTaskItem>,
    onMove: (Int, Int) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleActive: (Boolean) -> Unit
) {
    val accent = if (item.active) TaskCyan else TaskMuted
    val thresholdPx = with(LocalDensity.current) { 44.dp.toPx() }

    var dragging by remember(item.id) { mutableStateOf(false) }
    var dragAccumulator by remember(item.id) { mutableFloatStateOf(0f) }

    val dragHandleModifier = if (reorderEnabled) {
        Modifier.pointerInput(item.id) {
            detectDragGesturesAfterLongPress(
                onDragStart = {
                    dragging = true
                    dragAccumulator = 0f
                },
                onDragCancel = {
                    dragging = false
                    dragAccumulator = 0f
                },
                onDragEnd = {
                    dragging = false
                    dragAccumulator = 0f
                },
                onDrag = { _, amount ->
                    dragAccumulator += amount.y

                    if (dragAccumulator <= -thresholdPx) {
                        val currentIndex = tasks.indexOfFirst {
                            it.id == item.id
                        }
                        if (currentIndex > 0) {
                            onMove(currentIndex, currentIndex - 1)
                        }
                        dragAccumulator = 0f
                    } else if (dragAccumulator >= thresholdPx) {
                        val currentIndex = tasks.indexOfFirst {
                            it.id == item.id
                        }
                        if (
                            currentIndex >= 0 &&
                            currentIndex < tasks.lastIndex
                        ) {
                            onMove(currentIndex, currentIndex + 1)
                        }
                        dragAccumulator = 0f
                    }
                }
            )
        }
    } else {
        Modifier
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = if (dragging) 1.012f else 1f
                scaleY = if (dragging) 1.012f else 1f
            },
        shape = RoundedCornerShape(20.dp),
        color = if (dragging) Color(0xFF123259) else TaskPanel,
        border = BorderStroke(
            if (dragging) 1.7.dp else 1.dp,
            if (dragging) TaskCyan.copy(alpha = 0.85f)
            else accent.copy(alpha = 0.24f)
        ),
        shadowElevation = if (dragging) 10.dp else 0.dp
    ) {
        Column(
            modifier = Modifier.padding(13.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = TaskGold.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, TaskGold.copy(alpha = 0.18f))
                ) {
                    Box(
                        modifier = Modifier.size(39.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = item.order.toString(),
                            color = TaskGold,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(9.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.title,
                        color = if (item.active) TaskWhite else TaskMuted,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        maxLines = 2
                    )
                    Text(
                        text = item.category,
                        color = accent,
                        fontSize = 9.sp
                    )
                }

                if (reorderEnabled) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowUp,
                            contentDescription = "بالا",
                            tint = if (canMoveUp) TaskGold else TaskMuted.copy(alpha = 0.25f),
                            modifier = Modifier
                                .size(21.dp)
                                .clickable(enabled = canMoveUp) {
                                    val currentIndex = tasks.indexOfFirst {
                                        it.id == item.id
                                    }
                                    if (currentIndex > 0) {
                                        onMove(currentIndex, currentIndex - 1)
                                    }
                                }
                        )

                        Surface(
                            modifier = Modifier
                                .size(34.dp)
                                .then(dragHandleModifier),
                            shape = RoundedCornerShape(10.dp),
                            color = if (dragging) {
                                TaskCyan.copy(alpha = 0.18f)
                            } else {
                                Color.White.copy(alpha = 0.035f)
                            },
                            border = BorderStroke(
                                1.dp,
                                if (dragging) {
                                    TaskCyan.copy(alpha = 0.55f)
                                } else {
                                    Color.White.copy(alpha = 0.06f)
                                }
                            )
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.DragIndicator,
                                    contentDescription = "درگ برای جابه‌جایی",
                                    tint = if (dragging) TaskCyan else TaskMuted,
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowDown,
                            contentDescription = "پایین",
                            tint = if (canMoveDown) TaskGold else TaskMuted.copy(alpha = 0.25f),
                            modifier = Modifier
                                .size(21.dp)
                                .clickable(enabled = canMoveDown) {
                                    val currentIndex = tasks.indexOfFirst {
                                        it.id == item.id
                                    }
                                    if (
                                        currentIndex >= 0 &&
                                        currentIndex < tasks.lastIndex
                                    ) {
                                        onMove(currentIndex, currentIndex + 1)
                                    }
                                }
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))
                }

                Switch(
                    checked = item.active,
                    onCheckedChange = onToggleActive
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                RewardTag(
                    modifier = Modifier.weight(1f),
                    title = "XP",
                    value = item.xpReward,
                    accent = TaskGold
                )
                RewardTag(
                    modifier = Modifier.weight(1f),
                    title = "طلا",
                    value = item.goldReward,
                    accent = TaskPurple
                )
                RewardTag(
                    modifier = Modifier.weight(1f),
                    title = "الماس",
                    value = item.diamondReward,
                    accent = TaskCyan
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onEdit) {
                    Icon(
                        Icons.Rounded.Edit,
                        contentDescription = null,
                        tint = TaskGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "ویرایش",
                        color = TaskGold,
                        fontSize = 10.sp
                    )
                }

                TextButton(onClick = onDelete) {
                    Icon(
                        Icons.Rounded.Delete,
                        contentDescription = null,
                        tint = TaskRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "حذف",
                        color = TaskRed,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun RewardTag(
    modifier: Modifier,
    title: String,
    value: Int,
    accent: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = accent.copy(alpha = 0.07f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.16f))
    ) {
        Box(
            modifier = Modifier.padding(
                horizontal = 7.dp,
                vertical = 6.dp
            ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$title $value",
                color = TaskWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun FilterButton(
    modifier: Modifier,
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(44.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) TaskCyan.copy(alpha = 0.14f)
        else TaskDeep,
        border = BorderStroke(
            1.dp,
            if (selected) TaskCyan.copy(alpha = 0.62f)
            else Color.White.copy(alpha = 0.06f)
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = title,
                color = if (selected) TaskGold else TaskMuted,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun TaskEditorDialog(
    initial: GameTaskItem?,
    nextOrder: Int,
    onDismiss: () -> Unit,
    onSave: (GameTaskItem) -> Unit
) {
    var title by remember(initial) {
        mutableStateOf(initial?.title ?: "")
    }
    var category by remember(initial) {
        mutableStateOf(initial?.category ?: "سایر")
    }
    var xp by remember(initial) {
        mutableStateOf((initial?.xpReward ?: 20).toString())
    }
    var gold by remember(initial) {
        mutableStateOf((initial?.goldReward ?: 10).toString())
    }
    var diamonds by remember(initial) {
        mutableStateOf((initial?.diamondReward ?: 0).toString())
    }
    var active by remember(initial) {
        mutableStateOf(initial?.active ?: true)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TaskPanel,
        title = {
            Text(
                text = if (initial == null) "کار جدید" else "ویرایش کار",
                color = TaskWhite,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                TaskTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = "نام کار"
                )

                TaskTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = "دسته‌بندی"
                )

                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    TaskNumberField(
                        modifier = Modifier.weight(1f),
                        value = xp,
                        onValueChange = { xp = it },
                        label = "XP"
                    )
                    TaskNumberField(
                        modifier = Modifier.weight(1f),
                        value = gold,
                        onValueChange = { gold = it },
                        label = "طلا"
                    )
                    TaskNumberField(
                        modifier = Modifier.weight(1f),
                        value = diamonds,
                        onValueChange = { diamonds = it },
                        label = "الماس"
                    )
                }

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    color = TaskDeep,
                    border = BorderStroke(
                        1.dp,
                        Color.White.copy(alpha = 0.07f)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(
                            horizontal = 12.dp,
                            vertical = 8.dp
                        ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "فعال در بازی",
                                color = TaskWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                "اگر خاموش باشد وارد Session نمی‌شود.",
                                color = TaskMuted,
                                fontSize = 9.sp
                            )
                        }
                        Switch(
                            checked = active,
                            onCheckedChange = { active = it }
                        )
                    }
                }

                Text(
                    text = "ترتیب اجرا از صفحه اصلی کارها تعیین می‌شود.",
                    color = TaskMuted,
                    fontSize = 9.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        GameTaskItem(
                            id = initial?.id ?: System.currentTimeMillis(),
                            title = title.trim().ifBlank { "کار جدید" },
                            category = category.trim().ifBlank { "سایر" },
                            xpReward = xp.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                            goldReward = gold.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                            diamondReward = diamonds.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                            active = active,
                            order = initial?.order ?: nextOrder
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TaskGold,
                    contentColor = TaskDeep
                )
            ) {
                Text(
                    text = "ذخیره",
                    fontWeight = FontWeight.Black
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = "انصراف",
                    color = TaskMuted
                )
            }
        }
    )
}

@Composable
private fun TaskTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        colors = TaskTextFieldColors()
    )
}

@Composable
private fun TaskNumberField(
    modifier: Modifier,
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = {
            onValueChange(
                it.filter { char -> char.isDigit() }.take(6)
            )
        },
        modifier = modifier,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number
        ),
        singleLine = true,
        colors = TaskTextFieldColors()
    )
}

@Composable
private fun TaskTextFieldColors() =
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = TaskWhite,
        unfocusedTextColor = TaskWhite,
        cursorColor = TaskGold,
        focusedBorderColor = TaskCyan,
        unfocusedBorderColor = TaskMuted.copy(alpha = 0.50f),
        focusedLabelColor = TaskCyan,
        unfocusedLabelColor = TaskMuted,
        focusedContainerColor = TaskDeep,
        unfocusedContainerColor = TaskDeep
    )
