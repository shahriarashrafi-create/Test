# HeroLife Character C10 — Anatomy Continuity

Cumulative replacement for C09.

Main target: remove more of the mannequin / segmented look visible on the phone.

- smoother anatomy transitions
- cleaner face
- smaller eyes/nose/lips
- cleaner hair silhouette
- slimmer arms/hands
- longer-looking legs
- tighter black outfit
- subtler gold trim
- true GPU skinning retained
- no companion

Model: 30,352 vertices / 56,728 triangles.

Use this ZIP as the only cumulative ZIP in GitHub.
