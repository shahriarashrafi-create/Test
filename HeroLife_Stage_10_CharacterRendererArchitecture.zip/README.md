# HeroLife Stage 10 — Character Renderer Architecture

This stage does not add gameplay features.

## Main change
The hero is no longer coupled to the lobby layout.

A dedicated `CharacterRenderer` slot now owns character rendering.
Today it uses a more polished code renderer.
Later, this same slot can be replaced by:
- transparent character assets
- a sprite renderer
- a 3D mesh renderer

without rebuilding the HUD, environment, rank, navigation or Start button.

## Visual fixes
- hero made shorter and more proportional
- more breathing room around the character
- menu height reduced so the fourth item is not clipped
- quote made smaller
- rank/start area separated more clearly from the hero
- XP text corrected to `6240 / 8000 XP`
- no companion
- no screenshot/crop/full-screen bitmap mockup

The lobby stays fully layered and editable.
