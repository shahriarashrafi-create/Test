# C10 — Anatomy Continuity

Built from the C09 phone screenshot.

Fixes:
- reduced segmented mannequin look at shoulders, elbows, hips and knees
- smoother torso continuity using overlapping anatomical volumes
- smaller and flatter facial features
- eyes reduced and seated closer to the face
- nose and lips made less bulbous
- hair side strands simplified into a more coherent silhouette
- arms and hands reduced again
- legs lengthened visually and calves narrowed
- black outfit fitted more closely to the body
- gold decoration reduced to thin integrated trim
- idle animation softened further
- true GPU skinning retained
- no companion

Stats:
- 30,352 vertices
- 56,728 triangles
- 10-bone skin
