# HeroLife Character C12 — Real Human Asset Pipeline

Cumulative replacement for C11.

C12 ends the procedural-character path and prepares the app for a real authored human GLB.

Primary real asset paths:
- app/src/main/assets/models/production/real/female/female_real.glb
- app/src/main/assets/models/production/real/male/male_real.glb

The previous custom procedural female is preserved only as:
- app/src/main/assets/models/production/female_procedural_fallback.glb

Runtime behavior:
- if a real human GLB exists, it loads automatically
- otherwise the safe fallback loads
- 360° rotation remains
- GPU skinning remains
- runtime crash fix remains
- no companion

Next milestone: C13 — first authored real-human asset import.
