# نسخه ۱۳

ZIP را Extract و محتویات را در ریشه Repository آپلود کن. سپس Workflow ساخت APK را از Actions اجرا کن. Artifact خروجی: `shahriar-million-path-v13-apk`.
