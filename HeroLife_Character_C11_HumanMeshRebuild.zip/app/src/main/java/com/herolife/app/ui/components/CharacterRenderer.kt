package com.herolife.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.herolife.app.model.HeroSelection

/**
 * Production boundary for the 3D character.
 * Stage 13 now loads real GLB assets from app/src/main/assets/models/.
 */
@Composable
fun CharacterRenderer(
    selection: HeroSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            GlbHero3DView(
                context = context,
                gender = selection.gender,
                onTap = onClick
            )
        },
        update = { it.setGender(selection.gender) }
    )
}
