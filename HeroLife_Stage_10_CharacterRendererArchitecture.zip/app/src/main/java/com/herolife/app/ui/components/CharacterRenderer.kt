package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.herolife.app.model.HeroGender
import com.herolife.app.model.HeroSelection
import com.herolife.app.ui.theme.HL

/**
 * Stable character-rendering boundary.
 *
 * Stage 10 uses a code renderer.
 * A future 3D renderer can replace only this file/API.
 */
@Composable
fun CharacterRenderer(
    selection: HeroSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Canvas(
        modifier = modifier.clickable(onClick = onClick)
    ) {
        drawCharacterBackdrop()
        when (selection.gender) {
            HeroGender.FEMALE -> drawFemaleHero()
            HeroGender.MALE -> drawMaleHero()
        }
    }
}

private fun DrawScope.drawCharacterBackdrop() {
    drawCircle(
        brush = Brush.radialGradient(
            listOf(
                HL.Gold.copy(alpha = .17f),
                HL.Crystal.copy(alpha = .045f),
                Color.Transparent
            )
        ),
        radius = size.width * .47f,
        center = Offset(
            size.width * .52f,
            size.height * .42f
        )
    )

    // floor shadow
    drawOval(
        color = Color.Black.copy(alpha = .26f),
        topLeft = Offset(
            size.width * .22f,
            size.height * .88f
        ),
        size = Size(
            size.width * .58f,
            size.height * .075f
        )
    )
}

private fun DrawScope.drawFemaleHero() {
    val cx = size.width * .52f
    val headY = size.height * .17f
    val shoulderY = size.height * .32f
    val waistY = size.height * .53f
    val hipY = size.height * .61f
    val kneeY = size.height * .79f
    val bottom = size.height * .94f

    // cape
    val cape = Path().apply {
        moveTo(cx + size.width * .08f, shoulderY)
        cubicTo(
            cx + size.width * .27f, size.height * .46f,
            cx + size.width * .26f, size.height * .74f,
            cx + size.width * .20f, bottom
        )
        lineTo(cx + size.width * .02f, bottom)
        lineTo(cx, shoulderY)
        close()
    }
    drawPath(
        cape,
        brush = Brush.verticalGradient(
            listOf(
                Color(0xFF1D2028),
                Color(0xFF090B10)
            )
        )
    )

    // hair mass
    val hair = Path().apply {
        moveTo(cx - size.width * .085f, headY - size.height * .070f)
        cubicTo(
            cx - size.width * .18f, headY - size.height * .015f,
            cx - size.width * .18f, shoulderY + size.height * .06f,
            cx - size.width * .12f, size.height * .57f
        )
        cubicTo(
            cx - size.width * .06f, size.height * .68f,
            cx + size.width * .10f, size.height * .65f,
            cx + size.width * .15f, size.height * .55f
        )
        cubicTo(
            cx + size.width * .18f, shoulderY + size.height * .04f,
            cx + size.width * .14f, headY - size.height * .02f,
            cx + size.width * .075f, headY - size.height * .065f
        )
        close()
    }
    drawPath(
        hair,
        brush = Brush.verticalGradient(
            listOf(
                Color(0xFF5D382C),
                Color(0xFF311D19),
                Color(0xFF120C0E)
            )
        )
    )

    // neck
    drawRect(
        color = Color(0xFFDFAF97),
        topLeft = Offset(
            cx - size.width * .026f,
            headY + size.height * .048f
        ),
        size = Size(
            size.width * .052f,
            size.height * .055f
        )
    )

    // face
    drawOval(
        color = Color(0xFFE7B79F),
        topLeft = Offset(
            cx - size.width * .058f,
            headY - size.height * .045f
        ),
        size = Size(
            size.width * .116f,
            size.height * .100f
        )
    )

    // soft cheek shadow
    drawOval(
        color = Color(0xFFB87968).copy(alpha = .13f),
        topLeft = Offset(
            cx + size.width * .002f,
            headY - size.height * .004f
        ),
        size = Size(
            size.width * .044f,
            size.height * .050f
        )
    )

    // brows
    drawLine(
        color = Color(0xFF4A2926),
        start = Offset(cx - size.width * .038f, headY - size.height * .006f),
        end = Offset(cx - size.width * .010f, headY - size.height * .010f),
        strokeWidth = 2.2f
    )
    drawLine(
        color = Color(0xFF4A2926),
        start = Offset(cx + size.width * .010f, headY - size.height * .010f),
        end = Offset(cx + size.width * .038f, headY - size.height * .005f),
        strokeWidth = 2.2f
    )

    // eyes
    drawCircle(
        color = Color(0xFF2A2023),
        radius = size.width * .005f,
        center = Offset(cx - size.width * .023f, headY + size.height * .004f)
    )
    drawCircle(
        color = Color(0xFF2A2023),
        radius = size.width * .005f,
        center = Offset(cx + size.width * .023f, headY + size.height * .004f)
    )
    drawCircle(
        color = Color.White.copy(alpha = .8f),
        radius = size.width * .0015f,
        center = Offset(cx - size.width * .021f, headY + size.height * .002f)
    )
    drawCircle(
        color = Color.White.copy(alpha = .8f),
        radius = size.width * .0015f,
        center = Offset(cx + size.width * .025f, headY + size.height * .002f)
    )

    // nose
    drawLine(
        color = Color(0xFFB87869).copy(alpha = .72f),
        start = Offset(cx, headY + size.height * .010f),
        end = Offset(cx - size.width * .003f, headY + size.height * .031f),
        strokeWidth = 1.4f
    )

    // lips
    drawLine(
        color = Color(0xFF9F4F5D),
        start = Offset(cx - size.width * .017f, headY + size.height * .043f),
        end = Offset(cx + size.width * .018f, headY + size.height * .043f),
        strokeWidth = 2.4f
    )

    // front hair
    drawArc(
        color = Color(0xFF3E241F),
        startAngle = 185f,
        sweepAngle = 150f,
        useCenter = false,
        topLeft = Offset(
            cx - size.width * .078f,
            headY - size.height * .066f
        ),
        size = Size(
            size.width * .156f,
            size.height * .112f
        ),
        style = Stroke(width = size.width * .017f)
    )

    // torso
    val torso = Path().apply {
        moveTo(cx, shoulderY)
        lineTo(cx - size.width * .155f, shoulderY + size.height * .045f)
        lineTo(cx - size.width * .105f, waistY)
        lineTo(cx - size.width * .125f, hipY)
        lineTo(cx + size.width * .125f, hipY)
        lineTo(cx + size.width * .105f, waistY)
        lineTo(cx + size.width * .155f, shoulderY + size.height * .045f)
        close()
    }
    drawPath(
        torso,
        brush = Brush.verticalGradient(
            listOf(
                Color(0xFF2A2F37),
                Color(0xFF151A21),
                Color(0xFF090C11)
            )
        )
    )

    // shoulders
    drawArc(
        color = HL.Gold,
        startAngle = 190f,
        sweepAngle = 130f,
        useCenter = false,
        topLeft = Offset(
            cx - size.width * .18f,
            shoulderY - size.height * .003f
        ),
        size = Size(
            size.width * .105f,
            size.height * .095f
        ),
        style = Stroke(width = size.width * .008f)
    )
    drawArc(
        color = HL.Gold,
        startAngle = 220f,
        sweepAngle = 130f,
        useCenter = false,
        topLeft = Offset(
            cx + size.width * .075f,
            shoulderY - size.height * .003f
        ),
        size = Size(
            size.width * .105f,
            size.height * .095f
        ),
        style = Stroke(width = size.width * .008f)
    )

    // chest details
    drawLine(
        color = HL.Gold,
        start = Offset(cx, shoulderY + size.height * .020f),
        end = Offset(cx, waistY + size.height * .028f),
        strokeWidth = size.width * .0055f
    )
    repeat(4) { i ->
        val y = shoulderY + size.height * (.080f + i * .050f)
        drawLine(
            color = HL.Gold.copy(alpha = .55f),
            start = Offset(cx - size.width * .030f, y),
            end = Offset(cx + size.width * .030f, y),
            strokeWidth = size.width * .003f
        )
    }

    // belt
    drawLine(
        color = HL.Gold,
        start = Offset(cx - size.width * .10f, waistY + size.height * .026f),
        end = Offset(cx + size.width * .10f, waistY + size.height * .026f),
        strokeWidth = size.width * .008f
    )
    drawCircle(
        color = HL.Crystal,
        radius = size.width * .010f,
        center = Offset(cx, waistY + size.height * .026f)
    )

    // arms
    drawLine(
        color = Color(0xFFDDAA91),
        start = Offset(cx - size.width * .145f, shoulderY + size.height * .055f),
        end = Offset(cx - size.width * .185f, size.height * .60f),
        strokeWidth = size.width * .037f
    )
    drawLine(
        color = Color(0xFFDDAA91),
        start = Offset(cx + size.width * .145f, shoulderY + size.height * .055f),
        end = Offset(cx + size.width * .168f, size.height * .58f),
        strokeWidth = size.width * .037f
    )

    // gloves
    drawLine(
        color = Color(0xFF1F252D),
        start = Offset(cx - size.width * .182f, size.height * .52f),
        end = Offset(cx - size.width * .188f, size.height * .605f),
        strokeWidth = size.width * .044f
    )
    drawLine(
        color = Color(0xFF1F252D),
        start = Offset(cx + size.width * .166f, size.height * .50f),
        end = Offset(cx + size.width * .170f, size.height * .585f),
        strokeWidth = size.width * .044f
    )

    // lower body
    val lower = Path().apply {
        moveTo(cx - size.width * .11f, hipY)
        lineTo(cx - size.width * .135f, bottom)
        lineTo(cx - size.width * .025f, bottom)
        lineTo(cx, kneeY)
        lineTo(cx + size.width * .030f, bottom)
        lineTo(cx + size.width * .135f, bottom)
        lineTo(cx + size.width * .11f, hipY)
        close()
    }
    drawPath(
        lower,
        brush = Brush.verticalGradient(
            listOf(
                Color(0xFF161A20),
                Color(0xFF07090D)
            )
        )
    )

    drawLine(
        color = HL.Gold.copy(alpha = .78f),
        start = Offset(cx + size.width * .092f, hipY + size.height * .015f),
        end = Offset(cx + size.width * .118f, bottom),
        strokeWidth = size.width * .0048f
    )
}

private fun DrawScope.drawMaleHero() {
    val cx = size.width * .52f
    val headY = size.height * .17f
    val shoulderY = size.height * .32f
    val waistY = size.height * .53f
    val hipY = size.height * .61f
    val bottom = size.height * .94f

    val coat = Path().apply {
        moveTo(cx, shoulderY)
        lineTo(cx - size.width * .18f, shoulderY + size.height * .045f)
        lineTo(cx - size.width * .19f, bottom)
        lineTo(cx + size.width * .18f, bottom)
        lineTo(cx + size.width * .16f, shoulderY + size.height * .045f)
        close()
    }
    drawPath(
        coat,
        brush = Brush.verticalGradient(
            listOf(
                Color(0xFF282D35),
                Color(0xFF11161D),
                Color(0xFF070A0E)
            )
        )
    )

    drawOval(
        color = Color(0xFFD7A78E),
        topLeft = Offset(
            cx - size.width * .058f,
            headY - size.height * .043f
        ),
        size = Size(
            size.width * .116f,
            size.height * .100f
        )
    )

    val hair = Path().apply {
        moveTo(cx - size.width * .067f, headY - size.height * .041f)
        lineTo(cx - size.width * .022f, headY - size.height * .078f)
        lineTo(cx + size.width * .067f, headY - size.height * .056f)
        lineTo(cx + size.width * .074f, headY - size.height * .008f)
        close()
    }
    drawPath(hair, Color(0xFF151719))

    drawCircle(
        color = Color(0xFF2A2320),
        radius = size.width * .005f,
        center = Offset(cx - size.width * .021f, headY + size.height * .003f)
    )
    drawCircle(
        color = Color(0xFF2A2320),
        radius = size.width * .005f,
        center = Offset(cx + size.width * .021f, headY + size.height * .003f)
    )

    drawLine(
        color = HL.Gold,
        start = Offset(cx - size.width * .045f, shoulderY + size.height * .020f),
        end = Offset(cx + size.width * .005f, waistY),
        strokeWidth = size.width * .006f
    )
    drawLine(
        color = HL.Gold,
        start = Offset(cx + size.width * .045f, shoulderY + size.height * .020f),
        end = Offset(cx + size.width * .005f, waistY),
        strokeWidth = size.width * .006f
    )

    drawLine(
        color = HL.Gold,
        start = Offset(cx - size.width * .095f, waistY + size.height * .018f),
        end = Offset(cx + size.width * .10f, waistY + size.height * .018f),
        strokeWidth = size.width * .007f
    )

    drawLine(
        color = Color(0xFFD0A087),
        start = Offset(cx - size.width * .15f, shoulderY + size.height * .055f),
        end = Offset(cx - size.width * .18f, size.height * .60f),
        strokeWidth = size.width * .038f
    )
    drawLine(
        color = Color(0xFFD0A087),
        start = Offset(cx + size.width * .14f, shoulderY + size.height * .055f),
        end = Offset(cx + size.width * .16f, size.height * .58f),
        strokeWidth = size.width * .038f
    )

    drawLine(
        color = Color(0xFF1A2027),
        start = Offset(cx, hipY),
        end = Offset(cx, bottom),
        strokeWidth = size.width * .007f
    )

    drawLine(
        color = HL.Gold.copy(alpha = .72f),
        start = Offset(cx + size.width * .088f, hipY),
        end = Offset(cx + size.width * .115f, bottom),
        strokeWidth = size.width * .0048f
    )
}
