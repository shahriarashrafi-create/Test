package com.herolife.app.character

/**
 * Stable production-art contract. Lobby UI never depends on the model implementation.
 * Replace the files at these paths with professionally authored/licensed GLB 2.0 assets.
 */
object ProductionHeroContract {
    const val FEMALE_GLB = "models/female_realistic_01.glb"
    const val MALE_GLB = "models/male_realistic_01.glb"

    val requiredMaterialChannels = listOf(
        "BaseColor / Albedo",
        "Normal",
        "Metallic",
        "Roughness",
        "Skin",
        "Eyes",
        "Hair",
        "Armor / Cloth"
    )

    val optionalRigChannels = listOf(
        "Skeleton",
        "Idle animation",
        "Turn animation",
        "Breathing animation"
    )
}
