# C06.1 — Runtime Crash Hotfix

GitHub CI was green because compilation was valid. The crash happened at runtime on the phone.

Root cause found in the C04+ renderer path:
each GLB material primitive stored a complete copy of the full model vertex buffer.
C04/C05/C06 have roughly 80-90 primitives, so native OpenGL-side memory expanded dramatically
after the screen opened. That matches the observed "opens, then closes after about two seconds".

Fixes:
- compact/remap vertices per GLB primitive
- use GLES2-safe UNSIGNED_SHORT local indices
- halve index-buffer memory
- release old GPU primitive references before model replacement
- production-model load failure now falls back to the verification GLB instead of crashing the lobby
- no companion

This is a runtime hotfix; it preserves the C06 character/pipeline work.
