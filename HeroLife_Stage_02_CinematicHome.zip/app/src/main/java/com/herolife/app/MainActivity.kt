package com.herolife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Night = Color(0xFF06101E)
private val Glass = Color(0xE60A1729)
private val Gold = Color(0xFFFFC84A)
private val GoldSoft = Color(0xFFFFE6A1)
private val Crystal = Color(0xFF8EDBFF)
private val TextSoft = Color(0xFFC5D0E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = Gold,
                        secondary = Crystal,
                        background = Night,
                        surface = Glass,
                        onPrimary = Night,
                        onBackground = Color.White,
                        onSurface = Color.White
                    )
                ) {
                    Stage02App()
                }
            }
        }
    }
}

private enum class Destination {
    HOME, SHOP, EVENTS, REWARDS, ACHIEVEMENTS, TASKS, STATS, MORE, START
}

@Composable
private fun Stage02App() {
    var destination by remember { mutableStateOf(Destination.HOME) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Night)
    ) {
        Image(
            painter = painterResource(R.drawable.stage02_cinematic_home),
            contentDescription = "HeroLife cinematic home",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Invisible native hit-zones preserve the exact art composition while
        // making the reference-quality Stage 02 screen interactive.
        HomeHotspots(
            enabled = destination == Destination.HOME,
            onDestination = { destination = it }
        )

        AnimatedVisibility(
            visible = destination != Destination.HOME,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            DestinationOverlay(
                destination = destination,
                onBack = { destination = Destination.HOME }
            )
        }

        StageBadge(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 4.dp)
        )
    }
}

@Composable
private fun HomeHotspots(
    enabled: Boolean,
    onDestination: (Destination) -> Unit
) {
    if (!enabled) return

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Reference is 709 x 1536. Percent-based hit zones scale to phones.
        Hotspot(.025f, .095f, .155f, .085f) { onDestination(Destination.SHOP) }
        Hotspot(.025f, .180f, .155f, .085f) { onDestination(Destination.EVENTS) }
        Hotspot(.025f, .270f, .155f, .085f) { onDestination(Destination.REWARDS) }
        Hotspot(.025f, .355f, .155f, .090f) { onDestination(Destination.ACHIEVEMENTS) }

        Hotspot(.115f, .695f, .770f, .115f) { onDestination(Destination.START) }

        Hotspot(.000f, .900f, .200f, .100f) { onDestination(Destination.HOME) }
        Hotspot(.200f, .900f, .200f, .100f) { onDestination(Destination.TASKS) }
        Hotspot(.400f, .900f, .200f, .100f) { onDestination(Destination.STATS) }
        Hotspot(.600f, .900f, .200f, .100f) { onDestination(Destination.REWARDS) }
        Hotspot(.800f, .900f, .200f, .100f) { onDestination(Destination.MORE) }
    }
}

@Composable
private fun BoxWithConstraintsScope.Hotspot(
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .offset(
                x = maxWidth * x,
                y = maxHeight * y
            )
            .width(maxWidth * w)
            .height(maxHeight * h)
            .clickable(onClick = onClick)
    )
}

@Composable
private fun DestinationOverlay(
    destination: Destination,
    onBack: () -> Unit
) {
    val title = when (destination) {
        Destination.SHOP -> "فروشگاه"
        Destination.EVENTS -> "رویدادها"
        Destination.REWARDS -> "جوایز"
        Destination.ACHIEVEMENTS -> "دستاوردها"
        Destination.TASKS -> "کارها"
        Destination.STATS -> "آمار"
        Destination.MORE -> "بیشتر"
        Destination.START -> "شروع بازی"
        Destination.HOME -> "خانه"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xD906101E)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .padding(horizontal = 28.dp)
                .fillMaxWidth(),
            color = Glass,
            shape = RoundedCornerShape(26.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                Gold.copy(alpha = .55f)
            )
        ) {
            Column(
                Modifier.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    title,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Black,
                    color = GoldSoft
                )

                Spacer(Modifier.height(12.dp))

                Text(
                    if (destination == Destination.START)
                        "ظاهر لابی نهایی شد. موتور بازی در مرحله بعد روی همین پروژه سوار می‌شود."
                    else
                        "این مسیر از همین حالا واقعی و قابل کلیک است؛ محتوای کامل آن در مرحله‌های بعد روی همین پروژه اضافه می‌شود.",
                    color = TextSoft,
                    fontSize = 15.sp
                )

                Spacer(Modifier.height(22.dp))

                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Gold,
                        contentColor = Night
                    )
                ) {
                    Text("بازگشت به خانه", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StageBadge(modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(2200)
        visible = false
    }

    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Surface(
            color = Color(0xB006101E),
            shape = RoundedCornerShape(100.dp)
        ) {
            Text(
                "STAGE 02 • CINEMATIC HOME",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                color = Crystal,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
