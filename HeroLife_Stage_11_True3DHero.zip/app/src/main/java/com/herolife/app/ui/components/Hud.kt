package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herolife.app.model.LobbyDestination
import com.herolife.app.ui.theme.HL

private enum class GameIcon {
    SHOP, EVENTS, REWARDS, ACHIEVEMENTS, HOME, TASKS, STATS, MORE
}

@Composable
fun TopHud(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = HL.Navy.copy(alpha = .94f)
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = 10.dp,
                vertical = 7.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AvatarBadge()

            Spacer(Modifier.width(7.dp))

            Column(
                modifier = Modifier.width(118.dp)
            ) {
                Text(
                    "شهریار",
                    color = HL.Text,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Lv. 28",
                        color = HL.Gold,
                        fontSize = 10.sp
                    )
                    Spacer(Modifier.width(5.dp))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            "6240 / 8000 XP",
                            color = HL.Muted,
                            fontSize = 8.sp
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { .78f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp),
                    color = HL.Crystal,
                    trackColor = HL.Navy2
                )
            }

            Spacer(Modifier.width(7.dp))

            CurrencyBox(
                symbol = "G",
                value = "2,437",
                accent = HL.Gold
            )

            Spacer(Modifier.width(5.dp))

            CurrencyBox(
                symbol = "D",
                value = "12",
                accent = HL.Crystal
            )
        }
    }
}

@Composable
private fun AvatarBadge() {
    Surface(
        modifier = Modifier.size(50.dp),
        shape = CircleShape,
        color = HL.Navy2,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            HL.Gold.copy(alpha = .42f)
        )
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(7.dp)
        ) {
            drawCircle(
                color = Color(0xFFD6A58C),
                radius = size.width * .18f,
                center = Offset(size.width * .50f, size.height * .34f)
            )

            drawArc(
                color = Color(0xFF171719),
                startAngle = 190f,
                sweepAngle = 155f,
                useCenter = false,
                topLeft = Offset(size.width * .30f, size.height * .11f),
                size = Size(size.width * .40f, size.height * .35f),
                style = Stroke(width = size.width * .11f)
            )

            val shoulders = Path().apply {
                moveTo(size.width * .25f, size.height * .86f)
                lineTo(size.width * .35f, size.height * .56f)
                lineTo(size.width * .65f, size.height * .56f)
                lineTo(size.width * .75f, size.height * .86f)
                close()
            }
            drawPath(shoulders, Color(0xFF171C24))
        }
    }
}

@Composable
private fun CurrencyBox(
    symbol: String,
    value: String,
    accent: Color
) {
    Surface(
        color = HL.Void.copy(alpha = .62f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            accent.copy(alpha = .30f)
        )
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = 7.dp,
                vertical = 5.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .background(
                        accent.copy(alpha = .22f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    symbol,
                    color = accent,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(Modifier.width(4.dp))

            Text(
                value,
                color = HL.Text,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun SideMenu(
    modifier: Modifier = Modifier,
    onNavigate: (LobbyDestination) -> Unit
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        MenuButton(GameIcon.SHOP, "فروشگاه") {
            onNavigate(LobbyDestination.SHOP)
        }
        MenuButton(GameIcon.EVENTS, "رویدادها") {
            onNavigate(LobbyDestination.EVENTS)
        }
        MenuButton(GameIcon.REWARDS, "جوایز") {
            onNavigate(LobbyDestination.REWARDS)
        }
        MenuButton(GameIcon.ACHIEVEMENTS, "دستاوردها") {
            onNavigate(LobbyDestination.ACHIEVEMENTS)
        }
    }
}

@Composable
private fun MenuButton(
    icon: GameIcon,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(62.dp)
            .clickable(onClick = onClick),
        color = HL.Panel,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            HL.Gold.copy(alpha = .42f)
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            HL.Navy3.copy(alpha = .40f),
                            HL.Panel
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                VectorGameIcon(
                    icon = icon,
                    modifier = Modifier.size(24.dp),
                    tint = HL.GoldBright
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    label,
                    color = HL.Text,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun QuotePanel(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = HL.Panel,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            HL.Gold.copy(alpha = .28f)
        )
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "«نسخه بهتر خودت،",
                color = HL.Text,
                fontSize = 9.sp
            )
            Text(
                "در انتظار اقدام امروز توست.»",
                color = HL.Text,
                fontSize = 9.sp
            )
            Spacer(Modifier.height(5.dp))
            DiamondOrnament(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(8.dp)
            )
        }
    }
}

@Composable
fun BottomHud(
    modifier: Modifier = Modifier,
    onNavigate: (LobbyDestination) -> Unit
) {
    Column(modifier = modifier) {
        RankPanel(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 112.dp)
                .height(62.dp)
        )

        Spacer(Modifier.height(5.dp))

        StartGameButton(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 82.dp)
                .height(60.dp)
        ) {
            onNavigate(LobbyDestination.START)
        }

        Spacer(Modifier.height(5.dp))

        NavigationBar(
            modifier = Modifier.height(66.dp),
            containerColor = HL.Navy.copy(alpha = .98f)
        ) {
            NavItem(GameIcon.HOME, "خانه", true) {
                onNavigate(LobbyDestination.HOME)
            }
            NavItem(GameIcon.TASKS, "کارها", false) {
                onNavigate(LobbyDestination.TASKS)
            }
            NavItem(GameIcon.STATS, "آمار", false) {
                onNavigate(LobbyDestination.STATS)
            }
            NavItem(GameIcon.REWARDS, "جوایز", false) {
                onNavigate(LobbyDestination.REWARDS)
            }
            NavItem(GameIcon.MORE, "بیشتر", false) {
                onNavigate(LobbyDestination.MORE)
            }
        }
    }
}

@Composable
private fun RankPanel(
    modifier: Modifier
) {
    Surface(
        modifier = modifier,
        color = HL.Panel,
        shape = RoundedCornerShape(19.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            HL.Crystal.copy(alpha = .30f)
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            HL.Panel,
                            HL.Navy3.copy(alpha = .46f),
                            HL.Panel
                        )
                    )
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RankShield(
                    modifier = Modifier.size(38.dp)
                )
                Spacer(Modifier.width(9.dp))
                Column {
                    Text(
                        "رنک فعلی",
                        color = HL.Muted,
                        fontSize = 9.sp
                    )
                    Text(
                        "حماسی III",
                        color = HL.GoldBright,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LinearProgressIndicator(
                            progress = { .54f },
                            modifier = Modifier
                                .width(122.dp)
                                .height(5.dp),
                            color = HL.Gold,
                            trackColor = HL.Void
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "54/100",
                            color = HL.Text,
                            fontSize = 8.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StartGameButton(
    modifier: Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = Color.Transparent
    ) {
        Box(Modifier.fillMaxSize()) {
            Canvas(Modifier.fillMaxSize()) {
                val outer = Path().apply {
                    moveTo(size.width * .07f, 0f)
                    lineTo(size.width * .93f, 0f)
                    lineTo(size.width, size.height * .50f)
                    lineTo(size.width * .93f, size.height)
                    lineTo(size.width * .07f, size.height)
                    lineTo(0f, size.height * .50f)
                    close()
                }

                val inner = Path().apply {
                    moveTo(size.width * .09f, size.height * .10f)
                    lineTo(size.width * .91f, size.height * .10f)
                    lineTo(size.width * .975f, size.height * .50f)
                    lineTo(size.width * .91f, size.height * .90f)
                    lineTo(size.width * .09f, size.height * .90f)
                    lineTo(size.width * .025f, size.height * .50f)
                    close()
                }

                drawPath(
                    outer,
                    brush = Brush.horizontalGradient(
                        listOf(
                            HL.GoldDark,
                            Color(0xFFF0B838),
                            HL.GoldDark
                        )
                    )
                )
                drawPath(
                    outer,
                    HL.GoldBright,
                    style = Stroke(width = 4f)
                )
                drawPath(
                    inner,
                    Color.White.copy(alpha = .28f),
                    style = Stroke(width = 1.8f)
                )
            }

            Row(
                modifier = Modifier.align(Alignment.Center),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SwordIcon(
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(10.dp))
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "شروع بازی",
                        color = HL.Text,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "۳۰ دقیقه",
                        color = HL.Text.copy(alpha = .86f),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SwordIcon(modifier: Modifier) {
    Canvas(modifier = modifier) {
        fun sword(start: Offset, end: Offset) {
            drawLine(
                color = HL.Text,
                start = start,
                end = end,
                strokeWidth = size.width * .085f
            )

            val dx = end.x - start.x
            val dy = end.y - start.y
            val len = kotlin.math.sqrt(dx * dx + dy * dy)
            val ux = dx / len
            val uy = dy / len

            val guardCenter = Offset(
                start.x + ux * len * .22f,
                start.y + uy * len * .22f
            )

            drawLine(
                color = HL.Text,
                start = Offset(
                    guardCenter.x - uy * size.width * .13f,
                    guardCenter.y + ux * size.width * .13f
                ),
                end = Offset(
                    guardCenter.x + uy * size.width * .13f,
                    guardCenter.y - ux * size.width * .13f
                ),
                strokeWidth = size.width * .055f
            )

            drawCircle(
                color = HL.Text,
                radius = size.width * .045f,
                center = start
            )
        }

        sword(
            Offset(size.width * .20f, size.height * .80f),
            Offset(size.width * .80f, size.height * .20f)
        )
        sword(
            Offset(size.width * .80f, size.height * .80f),
            Offset(size.width * .20f, size.height * .20f)
        )
    }
}

@Composable
private fun RowScope.NavItem(
    icon: GameIcon,
    label: String,
    selected: Boolean,
    action: () -> Unit
) {
    NavigationBarItem(
        selected = selected,
        onClick = action,
        icon = {
            VectorGameIcon(
                icon = icon,
                modifier = Modifier.size(20.dp),
                tint = if (selected) HL.GoldBright else HL.Crystal
            )
        },
        label = {
            Text(
                label,
                color = if (selected) HL.Text else HL.Muted,
                fontSize = 9.sp
            )
        }
    )
}

@Composable
private fun VectorGameIcon(
    icon: GameIcon,
    modifier: Modifier,
    tint: Color
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        when (icon) {
            GameIcon.SHOP -> {
                val p = Path().apply {
                    moveTo(w * .15f, h * .63f)
                    lineTo(w * .22f, h * .31f)
                    lineTo(w * .40f, h * .47f)
                    lineTo(w * .50f, h * .23f)
                    lineTo(w * .60f, h * .47f)
                    lineTo(w * .78f, h * .31f)
                    lineTo(w * .85f, h * .63f)
                    close()
                }
                drawPath(p, tint, style = Stroke(width = w * .075f))
                drawLine(
                    tint,
                    Offset(w * .18f, h * .72f),
                    Offset(w * .82f, h * .72f),
                    strokeWidth = w * .08f
                )
            }

            GameIcon.EVENTS -> {
                drawRect(
                    tint,
                    topLeft = Offset(w * .16f, h * .42f),
                    size = Size(w * .68f, h * .40f),
                    style = Stroke(width = w * .075f)
                )
                drawLine(
                    tint,
                    Offset(w * .50f, h * .18f),
                    Offset(w * .50f, h * .82f),
                    strokeWidth = w * .07f
                )
                drawLine(
                    tint,
                    Offset(w * .18f, h * .42f),
                    Offset(w * .82f, h * .42f),
                    strokeWidth = w * .07f
                )
            }

            GameIcon.REWARDS -> {
                drawRect(
                    tint,
                    topLeft = Offset(w * .18f, h * .38f),
                    size = Size(w * .64f, h * .45f),
                    style = Stroke(width = w * .075f)
                )
                drawLine(
                    tint,
                    Offset(w * .18f, h * .38f),
                    Offset(w * .82f, h * .38f),
                    strokeWidth = w * .075f
                )
                drawCircle(
                    tint,
                    radius = w * .06f,
                    center = Offset(w * .50f, h * .56f)
                )
            }

            GameIcon.ACHIEVEMENTS -> {
                drawArc(
                    tint,
                    startAngle = 20f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(w * .18f, h * .12f),
                    size = Size(w * .64f, h * .50f),
                    style = Stroke(width = w * .075f)
                )
                drawLine(
                    tint,
                    Offset(w * .50f, h * .50f),
                    Offset(w * .50f, h * .80f),
                    strokeWidth = w * .075f
                )
                drawLine(
                    tint,
                    Offset(w * .34f, h * .80f),
                    Offset(w * .66f, h * .80f),
                    strokeWidth = w * .075f
                )
            }

            GameIcon.HOME -> {
                val p = Path().apply {
                    moveTo(w * .16f, h * .47f)
                    lineTo(w * .50f, h * .18f)
                    lineTo(w * .84f, h * .47f)
                    lineTo(w * .75f, h * .47f)
                    lineTo(w * .75f, h * .82f)
                    lineTo(w * .25f, h * .82f)
                    lineTo(w * .25f, h * .47f)
                    close()
                }
                drawPath(p, tint, style = Stroke(width = w * .075f))
            }

            GameIcon.TASKS -> {
                drawRect(
                    tint,
                    topLeft = Offset(w * .22f, h * .17f),
                    size = Size(w * .56f, h * .66f),
                    style = Stroke(width = w * .075f)
                )
                drawLine(
                    tint,
                    Offset(w * .32f, h * .53f),
                    Offset(w * .44f, h * .65f),
                    strokeWidth = w * .075f
                )
                drawLine(
                    tint,
                    Offset(w * .44f, h * .65f),
                    Offset(w * .68f, h * .38f),
                    strokeWidth = w * .075f
                )
            }

            GameIcon.STATS -> {
                drawRect(
                    tint,
                    topLeft = Offset(w * .18f, h * .58f),
                    size = Size(w * .14f, h * .25f)
                )
                drawRect(
                    tint,
                    topLeft = Offset(w * .43f, h * .40f),
                    size = Size(w * .14f, h * .43f)
                )
                drawRect(
                    tint,
                    topLeft = Offset(w * .68f, h * .20f),
                    size = Size(w * .14f, h * .63f)
                )
            }

            GameIcon.MORE -> {
                repeat(3) { index ->
                    drawLine(
                        tint,
                        Offset(w * .20f, h * (.30f + index * .20f)),
                        Offset(w * .80f, h * (.30f + index * .20f)),
                        strokeWidth = w * .075f
                    )
                }
            }
        }
    }
}

@Composable
private fun RankShield(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val outer = Path().apply {
            moveTo(size.width * .50f, 0f)
            lineTo(size.width * .90f, size.height * .18f)
            lineTo(size.width * .82f, size.height * .70f)
            lineTo(size.width * .50f, size.height)
            lineTo(size.width * .18f, size.height * .70f)
            lineTo(size.width * .10f, size.height * .18f)
            close()
        }

        val inner = Path().apply {
            moveTo(size.width * .50f, size.height * .14f)
            lineTo(size.width * .76f, size.height * .26f)
            lineTo(size.width * .70f, size.height * .61f)
            lineTo(size.width * .50f, size.height * .80f)
            lineTo(size.width * .30f, size.height * .61f)
            lineTo(size.width * .24f, size.height * .26f)
            close()
        }

        drawPath(outer, HL.Gold.copy(alpha = .18f))
        drawPath(outer, HL.GoldBright, style = Stroke(width = 3f))
        drawPath(inner, HL.Crystal.copy(alpha = .18f))
        drawPath(inner, HL.Crystal, style = Stroke(width = 2f))
        drawCircle(
            HL.Crystal,
            radius = size.width * .08f,
            center = Offset(size.width * .50f, size.height * .45f)
        )
    }
}

@Composable
private fun DiamondOrnament(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val p = Path().apply {
            moveTo(size.width * .50f, 0f)
            lineTo(size.width, size.height * .50f)
            lineTo(size.width * .50f, size.height)
            lineTo(0f, size.height * .50f)
            close()
        }

        drawPath(p, HL.Gold.copy(alpha = .30f))
        drawPath(p, HL.GoldBright, style = Stroke(width = 1.5f))
    }
}
