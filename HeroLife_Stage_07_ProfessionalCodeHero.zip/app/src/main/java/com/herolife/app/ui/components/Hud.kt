package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herolife.app.model.LobbyDestination
import com.herolife.app.ui.theme.HL

private enum class GameIcon {
    SHOP,
    EVENTS,
    REWARDS,
    ACHIEVEMENTS,
    HOME,
    TASKS,
    STATS,
    MORE
}

@Composable
fun TopHud(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = HL.Navy.copy(alpha = .92f)
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = 14.dp,
                vertical = 9.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(
                        color = HL.Navy2,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ش",
                    color = HL.GoldBright,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(Modifier.width(8.dp))

            Column(
                modifier = Modifier.width(116.dp)
            ) {
                Text(
                    text = "شهریار",
                    color = HL.Text,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )

                Text(
                    text = "Lv. 28",
                    color = HL.Gold,
                    fontSize = 11.sp
                )

                LinearProgressIndicator(
                    progress = { .78f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp),
                    color = HL.Crystal,
                    trackColor = HL.Navy2
                )
            }

            Spacer(Modifier.width(10.dp))

            CurrencyBox(
                symbol = "G",
                value = "2,437",
                accent = HL.Gold
            )

            Spacer(Modifier.width(6.dp))

            CurrencyBox(
                symbol = "D",
                value = "12",
                accent = HL.Crystal
            )
        }
    }
}

@Composable
private fun CurrencyBox(
    symbol: String,
    value: String,
    accent: Color
) {
    Surface(
        color = HL.Void.copy(alpha = .60f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            accent.copy(alpha = .25f)
        )
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = 8.dp,
                vertical = 6.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .background(
                        color = accent.copy(alpha = .20f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = symbol,
                    color = accent,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(Modifier.width(5.dp))

            Text(
                text = value,
                color = HL.Text,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun SideMenu(
    modifier: Modifier = Modifier,
    onNavigate: (LobbyDestination) -> Unit
) {
    Column(
        modifier = modifier.width(88.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MenuButton(
            icon = GameIcon.SHOP,
            label = "فروشگاه"
        ) {
            onNavigate(LobbyDestination.SHOP)
        }

        MenuButton(
            icon = GameIcon.EVENTS,
            label = "رویدادها"
        ) {
            onNavigate(LobbyDestination.EVENTS)
        }

        MenuButton(
            icon = GameIcon.REWARDS,
            label = "جوایز"
        ) {
            onNavigate(LobbyDestination.REWARDS)
        }

        MenuButton(
            icon = GameIcon.ACHIEVEMENTS,
            label = "دستاوردها"
        ) {
            onNavigate(LobbyDestination.ACHIEVEMENTS)
        }
    }
}

@Composable
private fun MenuButton(
    icon: GameIcon,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .clickable(onClick = onClick),
        color = HL.Panel,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            HL.Gold.copy(alpha = .35f)
        )
    ) {
        Column(
            modifier = Modifier.padding(7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            VectorGameIcon(
                icon = icon,
                modifier = Modifier.size(27.dp),
                tint = HL.GoldBright
            )

            Spacer(Modifier.height(5.dp))

            Text(
                text = label,
                color = HL.Text,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun QuotePanel(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = HL.Panel,
        shape = RoundedCornerShape(17.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            HL.Gold.copy(alpha = .24f)
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Text(
                text = "«نسخه بهتر خودت،",
                color = HL.Text,
                fontSize = 11.sp
            )

            Text(
                text = "در انتظار اقدام امروز توست.»",
                color = HL.Text,
                fontSize = 11.sp
            )

            Spacer(Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(8.dp)
                    .background(
                        color = HL.Gold.copy(alpha = .22f),
                        shape = RoundedCornerShape(2.dp)
                    )
            )
        }
    }
}

@Composable
fun BottomHud(
    modifier: Modifier = Modifier,
    onNavigate: (LobbyDestination) -> Unit
) {
    Column(
        modifier = modifier
    ) {
        RankPanel(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 78.dp,
                    end = 52.dp
                )
        )

        Spacer(Modifier.height(9.dp))

        StartGameButton(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 54.dp)
        ) {
            onNavigate(LobbyDestination.START)
        }

        Spacer(Modifier.height(9.dp))

        NavigationBar(
            containerColor = HL.Navy.copy(alpha = .97f)
        ) {
            NavItem(
                icon = GameIcon.HOME,
                label = "خانه",
                selected = true
            ) {
                onNavigate(LobbyDestination.HOME)
            }

            NavItem(
                icon = GameIcon.TASKS,
                label = "کارها",
                selected = false
            ) {
                onNavigate(LobbyDestination.TASKS)
            }

            NavItem(
                icon = GameIcon.STATS,
                label = "آمار",
                selected = false
            ) {
                onNavigate(LobbyDestination.STATS)
            }

            NavItem(
                icon = GameIcon.REWARDS,
                label = "جوایز",
                selected = false
            ) {
                onNavigate(LobbyDestination.REWARDS)
            }

            NavItem(
                icon = GameIcon.MORE,
                label = "بیشتر",
                selected = false
            ) {
                onNavigate(LobbyDestination.MORE)
            }
        }
    }
}

@Composable
private fun RankPanel(
    modifier: Modifier
) {
    Surface(
        modifier = modifier.height(86.dp),
        color = HL.Panel,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            HL.Crystal.copy(alpha = .24f)
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RankShield(
                modifier = Modifier.size(58.dp)
            )

            Spacer(Modifier.width(10.dp))

            Column {
                Text(
                    text = "رنک فعلی",
                    color = HL.Muted,
                    fontSize = 10.sp
                )

                Text(
                    text = "حماسی III",
                    color = HL.GoldBright,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Black
                )

                LinearProgressIndicator(
                    progress = { .54f },
                    modifier = Modifier
                        .width(150.dp)
                        .height(6.dp),
                    color = HL.Gold,
                    trackColor = HL.Void
                )

                Text(
                    text = "54 / 100",
                    color = HL.Text,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun StartGameButton(
    modifier: Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(78.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = HL.Gold,
        border = androidx.compose.foundation.BorderStroke(
            2.dp,
            HL.GoldBright
        )
    ) {
        Box(
            modifier = Modifier.background(
                brush = Brush.horizontalGradient(
                    listOf(
                        Color(0xFFA06B12),
                        Color(0xFFF4BD40),
                        Color(0xFFA06B12)
                    )
                )
            ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                CrossedSwords(
                    modifier = Modifier.size(34.dp)
                )

                Spacer(Modifier.width(14.dp))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "شروع بازی",
                        color = HL.Void,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )

                    Text(
                        text = "۳۰ دقیقه",
                        color = HL.Void,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(
    icon: GameIcon,
    label: String,
    selected: Boolean,
    action: () -> Unit
) {
    NavigationBarItem(
        selected = selected,
        onClick = action,
        icon = {
            VectorGameIcon(
                icon = icon,
                modifier = Modifier.size(22.dp),
                tint = if (selected) {
                    HL.GoldBright
                } else {
                    HL.Crystal
                }
            )
        },
        label = {
            Text(
                text = label,
                color = if (selected) {
                    HL.Text
                } else {
                    HL.Muted
                },
                fontSize = 9.sp
            )
        }
    )
}

@Composable
private fun VectorGameIcon(
    icon: GameIcon,
    modifier: Modifier,
    tint: Color
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        when (icon) {
            GameIcon.SHOP -> {
                drawRect(
                    color = tint,
                    topLeft = Offset(w * .20f, h * .40f),
                    size = androidx.compose.ui.geometry.Size(w * .60f, h * .45f),
                    style = Stroke(width = w * .08f)
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .16f, h * .40f),
                    end = Offset(w * .50f, h * .12f),
                    strokeWidth = w * .08f
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .84f, h * .40f),
                    end = Offset(w * .50f, h * .12f),
                    strokeWidth = w * .08f
                )
            }

            GameIcon.EVENTS,
            GameIcon.REWARDS -> {
                drawRect(
                    color = tint,
                    topLeft = Offset(w * .16f, h * .42f),
                    size = androidx.compose.ui.geometry.Size(w * .68f, h * .40f),
                    style = Stroke(width = w * .08f)
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .50f, h * .18f),
                    end = Offset(w * .50f, h * .82f),
                    strokeWidth = w * .07f
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .18f, h * .42f),
                    end = Offset(w * .82f, h * .42f),
                    strokeWidth = w * .07f
                )
            }

            GameIcon.ACHIEVEMENTS -> {
                drawCircle(
                    color = tint,
                    radius = w * .24f,
                    center = Offset(w * .50f, h * .38f),
                    style = Stroke(width = w * .08f)
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .35f, h * .58f),
                    end = Offset(w * .26f, h * .86f),
                    strokeWidth = w * .08f
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .65f, h * .58f),
                    end = Offset(w * .74f, h * .86f),
                    strokeWidth = w * .08f
                )
            }

            GameIcon.HOME -> {
                val path = Path().apply {
                    moveTo(w * .18f, h * .46f)
                    lineTo(w * .50f, h * .18f)
                    lineTo(w * .82f, h * .46f)
                    lineTo(w * .72f, h * .46f)
                    lineTo(w * .72f, h * .82f)
                    lineTo(w * .28f, h * .82f)
                    lineTo(w * .28f, h * .46f)
                    close()
                }
                drawPath(
                    path = path,
                    color = tint,
                    style = Stroke(width = w * .08f)
                )
            }

            GameIcon.TASKS -> {
                drawRect(
                    color = tint,
                    topLeft = Offset(w * .22f, h * .18f),
                    size = androidx.compose.ui.geometry.Size(w * .56f, h * .66f),
                    style = Stroke(width = w * .08f)
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .31f, h * .52f),
                    end = Offset(w * .43f, h * .64f),
                    strokeWidth = w * .08f
                )
                drawLine(
                    color = tint,
                    start = Offset(w * .43f, h * .64f),
                    end = Offset(w * .67f, h * .38f),
                    strokeWidth = w * .08f
                )
            }

            GameIcon.STATS -> {
                drawRect(
                    color = tint,
                    topLeft = Offset(w * .18f, h * .58f),
                    size = androidx.compose.ui.geometry.Size(w * .14f, h * .25f)
                )
                drawRect(
                    color = tint,
                    topLeft = Offset(w * .43f, h * .40f),
                    size = androidx.compose.ui.geometry.Size(w * .14f, h * .43f)
                )
                drawRect(
                    color = tint,
                    topLeft = Offset(w * .68f, h * .20f),
                    size = androidx.compose.ui.geometry.Size(w * .14f, h * .63f)
                )
            }

            GameIcon.MORE -> {
                repeat(3) { index ->
                    drawLine(
                        color = tint,
                        start = Offset(w * .20f, h * (.30f + index * .20f)),
                        end = Offset(w * .80f, h * (.30f + index * .20f)),
                        strokeWidth = w * .08f
                    )
                }
            }
        }
    }
}

@Composable
private fun RankShield(
    modifier: Modifier
) {
    Canvas(modifier = modifier) {
        val path = Path().apply {
            moveTo(size.width * .50f, 0f)
            lineTo(size.width * .90f, size.height * .18f)
            lineTo(size.width * .82f, size.height * .70f)
            lineTo(size.width * .50f, size.height)
            lineTo(size.width * .18f, size.height * .70f)
            lineTo(size.width * .10f, size.height * .18f)
            close()
        }

        drawPath(
            path = path,
            color = HL.Gold.copy(alpha = .20f)
        )

        drawPath(
            path = path,
            color = HL.GoldBright,
            style = Stroke(width = 3f)
        )

        drawCircle(
            color = HL.Crystal,
            radius = size.width * .10f,
            center = Offset(
                x = size.width * .50f,
                y = size.height * .44f
            )
        )
    }
}

@Composable
private fun CrossedSwords(
    modifier: Modifier
) {
    Canvas(modifier = modifier) {
        drawLine(
            color = HL.Void,
            start = Offset(
                x = size.width * .18f,
                y = size.height * .18f
            ),
            end = Offset(
                x = size.width * .82f,
                y = size.height * .82f
            ),
            strokeWidth = size.width * .09f
        )

        drawLine(
            color = HL.Void,
            start = Offset(
                x = size.width * .82f,
                y = size.height * .18f
            ),
            end = Offset(
                x = size.width * .18f,
                y = size.height * .82f
            ),
            strokeWidth = size.width * .09f
        )

        drawCircle(
            color = HL.Void,
            radius = size.width * .09f,
            center = Offset(
                x = size.width * .50f,
                y = size.height * .50f
            )
        )
    }
}
