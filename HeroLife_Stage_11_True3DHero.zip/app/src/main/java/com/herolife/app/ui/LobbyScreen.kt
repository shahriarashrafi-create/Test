package com.herolife.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.Layout
import com.herolife.app.model.LobbyDestination
import com.herolife.app.model.LobbyState
import com.herolife.app.ui.components.BottomHud
import com.herolife.app.ui.components.CharacterRenderer
import com.herolife.app.ui.components.EnvironmentLayer
import com.herolife.app.ui.components.QuotePanel
import com.herolife.app.ui.components.SideMenu
import com.herolife.app.ui.components.TopHud
import com.herolife.app.ui.theme.HL

@Composable
fun LobbyScreen(
    state: LobbyState,
    onHeroClick: () -> Unit,
    onNavigate: (LobbyDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HL.Void)
    ) {
        EnvironmentLayer(Modifier.fillMaxSize())

        // True 3D viewport. Deliberately independent from every HUD layer.
        PhysicalLayer(.16f, .105f, .68f, .585f) {
            CharacterRenderer(
                selection = state.hero,
                modifier = Modifier.fillMaxSize(),
                onClick = onHeroClick
            )
        }

        PhysicalLayer(0f, 0f, 1f, .095f) {
            TopHud(Modifier.fillMaxSize())
        }

        // Four buttons now have enough vertical room; no clipping.
        PhysicalLayer(.018f, .18f, .145f, .405f) {
            SideMenu(
                modifier = Modifier.fillMaxSize(),
                onNavigate = onNavigate
            )
        }

        PhysicalLayer(.755f, .345f, .215f, .082f) {
            QuotePanel(Modifier.fillMaxSize())
        }

        // Rank / CTA / nav own the bottom region and never overlap hero.
        PhysicalLayer(0f, .705f, 1f, .295f) {
            BottomHud(
                modifier = Modifier.fillMaxSize(),
                onNavigate = onNavigate
            )
        }
    }
}

@Composable
private fun PhysicalLayer(
    xFraction: Float,
    yFraction: Float,
    widthFraction: Float,
    heightFraction: Float,
    content: @Composable () -> Unit
) {
    Layout(
        content = content,
        modifier = Modifier.fillMaxSize()
    ) { measurables, constraints ->
        val width = (constraints.maxWidth * widthFraction).toInt().coerceAtLeast(1)
        val height = (constraints.maxHeight * heightFraction).toInt().coerceAtLeast(1)
        val placeable = measurables.first().measure(
            constraints.copy(
                minWidth = width,
                maxWidth = width,
                minHeight = height,
                maxHeight = height
            )
        )
        layout(constraints.maxWidth, constraints.maxHeight) {
            placeable.place(
                x = (constraints.maxWidth * xFraction).toInt(),
                y = (constraints.maxHeight * yFraction).toInt()
            )
        }
    }
}
