package com.herolife.app.ui.components

import androidx.compose.ui.unit.dp

object HeroStageLayout {
    val HeaderHeight = 146.dp
    val BottomNavigationHeight = 112.dp
    val RankZoneHeight = 132.dp
    val StartZoneHeight = 128.dp
    val SideActionWidth = 106.dp
    val SideSafeInset = 18.dp
    val HeroHorizontalInset = 116.dp
    val HeroBottomClearance = 278.dp
}
