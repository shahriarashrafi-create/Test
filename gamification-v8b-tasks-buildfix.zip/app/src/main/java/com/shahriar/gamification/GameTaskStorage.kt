package com.shahriar.gamification

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object GameTaskStorage {
    private const val PREFS = "game_task_preferences"
    private const val KEY_TASKS = "game_tasks_json"

    fun load(context: Context): List<GameTaskItem> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_TASKS, null)
        if (raw.isNullOrBlank()) return defaults()

        return runCatching {
            val array = JSONArray(raw)
            val result = mutableListOf<GameTaskItem>()

            var index = 0
            while (index < array.length()) {
                val obj = array.getJSONObject(index)
                result.add(
                    GameTaskItem(
                        id = obj.optLong("id", System.currentTimeMillis() + index),
                        title = obj.optString("title", "کار"),
                        category = obj.optString("category", "سایر"),
                        xpReward = obj.optInt("xpReward", 20).coerceAtLeast(0),
                        goldReward = obj.optInt("goldReward", 10).coerceAtLeast(0),
                        diamondReward = obj.optInt("diamondReward", 0).coerceAtLeast(0),
                        active = obj.optBoolean("active", true),
                        order = obj.optInt("order", index + 1).coerceAtLeast(1)
                    )
                )
                index++
            }

            result.sortedBy { it.order }
                .mapIndexed { itemIndex, item ->
                    item.copy(order = itemIndex + 1)
                }
        }.getOrElse {
            defaults()
        }
    }

    fun save(context: Context, tasks: List<GameTaskItem>) {
        val normalized = tasks.mapIndexed { index, item ->
            item.copy(order = index + 1)
        }

        val array = JSONArray()
        var index = 0

        while (index < normalized.size) {
            val item = normalized[index]
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("title", item.title)
            obj.put("category", item.category)
            obj.put("xpReward", item.xpReward)
            obj.put("goldReward", item.goldReward)
            obj.put("diamondReward", item.diamondReward)
            obj.put("active", item.active)
            obj.put("order", item.order)
            array.put(obj)
            index++
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TASKS, array.toString())
            .apply()
    }

    private fun defaults(): List<GameTaskItem> {
        return listOf(
            GameTaskItem(
                id = 1001,
                title = "ارتباط‌سازی با ۳ نفر",
                category = "شبکه‌سازی",
                xpReward = 30,
                goldReward = 20,
                diamondReward = 0,
                active = true,
                order = 1
            ),
            GameTaskItem(
                id = 1002,
                title = "پیش‌مشاوره",
                category = "شبکه‌سازی",
                xpReward = 35,
                goldReward = 25,
                diamondReward = 0,
                active = true,
                order = 2
            ),
            GameTaskItem(
                id = 1003,
                title = "دعوت",
                category = "شبکه‌سازی",
                xpReward = 35,
                goldReward = 25,
                diamondReward = 0,
                active = true,
                order = 3
            ),
            GameTaskItem(
                id = 1004,
                title = "معرفی کار",
                category = "شبکه‌سازی",
                xpReward = 45,
                goldReward = 35,
                diamondReward = 1,
                active = true,
                order = 4
            ),
            GameTaskItem(
                id = 1005,
                title = "فالوآپ",
                category = "شبکه‌سازی",
                xpReward = 30,
                goldReward = 20,
                diamondReward = 0,
                active = true,
                order = 5
            ),
            GameTaskItem(
                id = 1006,
                title = "پیگیری سازمان",
                category = "سازمان",
                xpReward = 40,
                goldReward = 30,
                diamondReward = 0,
                active = true,
                order = 6
            ),
            GameTaskItem(
                id = 1007,
                title = "مطالعه",
                category = "آموزش",
                xpReward = 25,
                goldReward = 15,
                diamondReward = 0,
                active = true,
                order = 7
            ),
            GameTaskItem(
                id = 1008,
                title = "برنامه‌ریزی فردا",
                category = "شخصی",
                xpReward = 20,
                goldReward = 15,
                diamondReward = 0,
                active = true,
                order = 8
            )
        )
    }
}
