# Production character assets

Place real production GLB files here.

Recommended:
- `female_realistic_01.glb`
- `male_realistic_01.glb`

For a photoreal result, the GLB should contain:
- optimized humanoid mesh
- UVs
- PBR base-color texture
- normal map
- metallic/roughness map
- optional emissive details
- skeleton/rig if idle animation is required

Do not use random downloaded models without a license.
The Stage 12 lobby and HUD are already isolated from the renderer, so replacing the procedural
character with a GLB will not move the menus, quote, rank, Start button, or navigation.
