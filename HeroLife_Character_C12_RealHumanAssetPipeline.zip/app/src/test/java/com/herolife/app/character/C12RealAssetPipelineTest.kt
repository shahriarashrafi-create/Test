package com.herolife.app.character

import org.junit.Assert.assertTrue
import org.junit.Test

class C12RealAssetPipelineTest {
    @Test fun realAssetPathsAreGlb() {
        assertTrue("models/production/real/female/female_real.glb".endsWith(".glb"))
        assertTrue("models/production/real/male/male_real.glb".endsWith(".glb"))
    }
}
