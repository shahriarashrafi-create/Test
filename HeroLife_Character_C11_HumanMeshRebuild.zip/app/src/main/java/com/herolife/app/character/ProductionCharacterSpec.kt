package com.herolife.app.character

enum class HeroGender { FEMALE, MALE }

data class PbrMaterialContract(
    val requiresBaseColor: Boolean = true,
    val supportsNormalMap: Boolean = true,
    val supportsMetallicRoughness: Boolean = true,
    val supportsOcclusion: Boolean = true,
    val supportsEmissive: Boolean = true
)

data class ProductionCharacterSpec(
    val id: String,
    val gender: HeroGender,
    val assetPath: String,
    val preferredAnimation: String = "Idle",
    val fallbackAnimation: String? = null,
    val defaultYaw: Float = 0f,
    val minZoom: Float = 0.82f,
    val maxZoom: Float = 1.35f,
    val cameraTargetHeightRatio: Float = 0.52f,
    val pbr: PbrMaterialContract = PbrMaterialContract()
)

object ProductionCharacterCatalog {
    val female = ProductionCharacterSpec(
        id = "female_realistic_01",
        gender = HeroGender.FEMALE,
        assetPath = "models/female_realistic_01.glb",
        preferredAnimation = "Idle"
    )

    val male = ProductionCharacterSpec(
        id = "male_realistic_01",
        gender = HeroGender.MALE,
        assetPath = "models/male_realistic_01.glb",
        preferredAnimation = "Idle"
    )

    fun all(): List<ProductionCharacterSpec> = listOf(female, male)
}
