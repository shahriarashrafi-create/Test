package com.herolife.app.character

import android.content.Context

/**
 * Stable handoff point for a production GLB character.
 *
 * Stage 12 intentionally does NOT fake a photoreal human.
 * Put a licensed/original .glb file in app/src/main/assets/models/
 * and replace this placeholder with a GLB parser/renderer implementation.
 *
 * The rest of the app never needs to know how the mesh/materials are loaded.
 */
class GlbModelSlot(
    private val context: Context
) {
    fun exists(asset: CharacterAsset): Boolean {
        val path = asset.assetPath ?: return false
        return try {
            context.assets.open(path).close()
            true
        } catch (_: Throwable) {
            false
        }
    }
}
