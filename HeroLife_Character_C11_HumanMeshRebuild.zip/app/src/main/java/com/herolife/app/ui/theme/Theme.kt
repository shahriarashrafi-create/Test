package com.herolife.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object HL {
    val Void = Color(0xFF040914)
    val Navy = Color(0xFF071326)
    val Navy2 = Color(0xFF0C2039)
    val Navy3 = Color(0xFF122A45)
    val Panel = Color(0xEE08182B)
    val PanelSoft = Color(0xD90B1D33)
    val Gold = Color(0xFFFFC64A)
    val GoldDark = Color(0xFF9D6510)
    val GoldBright = Color(0xFFFFE9A6)
    val Crystal = Color(0xFF75D9FF)
    val CrystalDark = Color(0xFF1B6F98)
    val Text = Color(0xFFF7F8FC)
    val Muted = Color(0xFFA8B6C9)
    val Success = Color(0xFF6DE4A4)
    val Danger = Color(0xFFFF6A6A)
}

@Composable
fun HeroLifeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = HL.Gold,
            secondary = HL.Crystal,
            background = HL.Void,
            surface = HL.Navy,
            onPrimary = HL.Void,
            onBackground = HL.Text,
            onSurface = HL.Text
        ),
        content = content
    )
}
