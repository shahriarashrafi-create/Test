# HeroLife Stage 17 — Photoreal Character Pipeline

Cumulative upload ZIP based on Stage 16.

### Added
- Production GLB asset contract for female/male heroes.
- PBR material requirements for skin, eyes, hair, cloth, leather and metal.
- Independent HeroViewerState for selection, 360-degree rotation and bounded zoom.
- GLB header validation.
- Fixed Hero-stage layout constants so future professional assets cannot push Rank/CTA/navigation.
- Photoreal asset manifest and integration documentation.
- Existing transparent renderer and bundled GLB verification models retained.

### Important
The reference artwork is used as visual direction only. It is not screenshot-cropped into the UI.
The bundled GLBs are build-safe verification assets, not final photoreal humans. Stage 17's purpose
is to make a professionally authored/licensed PBR GLB a clean drop-in replacement.
