# HeroLife — Stage 03: Immersive + Custom Hero/Companion

This is a cumulative replacement ZIP based on Stage 02.

## Added in Stage 03
- Android immersive fullscreen
- status bar hidden
- navigation bar hidden
- transient system bars only on swipe
- system bars are hidden again when app regains focus
- edge-to-edge rendering
- Hero and Companion are independent render layers
- tap Hero to open Hero Picker
- tap Companion to open Companion Picker
- two Hero variants included
- two Companion variants included
- selection persists using SharedPreferences
- the architecture now supports adding more hero/companion assets without rebuilding the background

## Next
Stage 04 can begin the real interactive game screen while preserving this fullscreen lobby.
