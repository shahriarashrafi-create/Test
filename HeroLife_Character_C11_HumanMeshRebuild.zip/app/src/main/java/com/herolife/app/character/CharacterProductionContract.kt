package com.herolife.app.character

data class TextureChannelSet(
    val baseColor: Boolean = true,
    val normal: Boolean = true,
    val roughness: Boolean = true,
    val metallic: Boolean = false,
    val occlusion: Boolean = true,
    val alphaMask: Boolean = false
)

data class MaterialTextureContract(
    val name: String,
    val targetResolution: Int,
    val channels: TextureChannelSet
)

data class HumanoidRigContract(
    val root: String = "Root",
    val hips: String = "Hips",
    val maxInfluencesPerVertex: Int = 4,
    val idleAnimation: String = "Idle"
)

object C06ProductionContract {
    val materials = listOf(
        MaterialTextureContract("Skin", 2048, TextureChannelSet()),
        MaterialTextureContract("Face", 2048, TextureChannelSet()),
        MaterialTextureContract("Eyes", 1024, TextureChannelSet(occlusion = false)),
        MaterialTextureContract("Hair", 2048, TextureChannelSet(occlusion = false, alphaMask = true)),
        MaterialTextureContract("Leather", 2048, TextureChannelSet(metallic = true)),
        MaterialTextureContract("Cloth", 2048, TextureChannelSet()),
        MaterialTextureContract("Gold", 2048, TextureChannelSet(metallic = true))
    )

    val rig = HumanoidRigContract()
}
