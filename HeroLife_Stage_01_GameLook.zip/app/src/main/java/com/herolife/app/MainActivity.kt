package com.herolife.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

private val Night = Color(0xFF07101E)
private val Navy = Color(0xFF0C1B31)
private val Panel = Color(0xD9142742)
private val Panel2 = Color(0xFF10243D)
private val Gold = Color(0xFFFFC84A)
private val Gold2 = Color(0xFFFFE08A)
private val Crystal = Color(0xFF62D7FF)
private val Muted = Color(0xFFA9B5C9)
private val White = Color(0xFFF6F8FF)
private val Success = Color(0xFF6BE3A2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = Gold,
                        secondary = Crystal,
                        background = Night,
                        surface = Navy,
                        onPrimary = Night,
                        onBackground = White,
                        onSurface = White
                    )
                ) {
                    StageOneApp()
                }
            }
        }
    }
}

private enum class Nav { HOME, TASKS, STATS, REWARDS, MORE }

@Composable
private fun StageOneApp() {
    var selected by remember { mutableStateOf(Nav.HOME) }
    var showToast by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(Night)) {
        FantasyBackdrop()

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            bottomBar = {
                GameBottomBar(
                    selected = selected,
                    onSelect = {
                        selected = it
                        showToast = when (it) {
                            Nav.HOME -> ""
                            Nav.TASKS -> "مرحله ۲: کارها"
                            Nav.STATS -> "مرحله ۲: آمار"
                            Nav.REWARDS -> "مرحله ۲: جوایز"
                            Nav.MORE -> "مرحله ۲: بیشتر"
                        }
                    }
                )
            }
        ) { padding ->
            if (selected == Nav.HOME) {
                HomeScreen(
                    modifier = Modifier.padding(padding),
                    onAction = { showToast = it }
                )
            } else {
                ComingSoon(
                    modifier = Modifier.padding(padding),
                    title = showToast,
                    onHome = { selected = Nav.HOME }
                )
            }
        }
    }
}

@Composable
private fun FantasyBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color(0xFF172C48),
                    Color(0xFF0B1930),
                    Color(0xFF07101E)
                )
            )
        )

        drawCircle(
            color = Color(0xFFFFD37A).copy(alpha = .16f),
            radius = size.width * .32f,
            center = Offset(size.width * .72f, size.height * .20f)
        )

        repeat(8) { i ->
            val x = size.width * (i / 7f)
            val h = size.height * (.16f + .07f * sin(i.toFloat() * 1.7f))
            drawRect(
                color = Color(0xFF13253C),
                topLeft = Offset(x - 35f, size.height * .56f - h),
                size = Size(100f, h + size.height * .44f)
            )
        }

        val castle = Path().apply {
            moveTo(size.width * .58f, size.height * .33f)
            lineTo(size.width * .64f, size.height * .24f)
            lineTo(size.width * .70f, size.height * .33f)
            lineTo(size.width * .76f, size.height * .20f)
            lineTo(size.width * .82f, size.height * .34f)
            lineTo(size.width * .89f, size.height * .27f)
            lineTo(size.width * .95f, size.height * .37f)
            lineTo(size.width, size.height * .40f)
            lineTo(size.width, size.height * .73f)
            lineTo(size.width * .58f, size.height * .73f)
            close()
        }
        drawPath(castle, Color(0xFF203952).copy(alpha = .72f))

        repeat(18) { i ->
            val x = size.width * ((i * 37 % 100) / 100f)
            val y = size.height * (.16f + ((i * 19 % 40) / 100f))
            drawCircle(
                color = Color.White.copy(alpha = .10f),
                radius = 1.6f + (i % 3),
                center = Offset(x, y)
            )
        }

        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Transparent, Night.copy(alpha = .45f), Night)
            ),
            topLeft = Offset(0f, size.height * .45f),
            size = Size(size.width, size.height * .55f)
        )
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onAction: (String) -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        PlayerHeader()
        Spacer(Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(500.dp)
        ) {
            SideMenu(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 2.dp),
                onAction = onAction
            )

            HeroScene(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxHeight()
                    .fillMaxWidth(.72f)
            )

            QuoteCard(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(top = 70.dp)
            )
        }

        RankPanel()

        Spacer(Modifier.height(14.dp))

        StartButton(
            onClick = { onAction("شروع بازی در مرحله بعد فعال می‌شود") }
        )

        Spacer(Modifier.height(12.dp))

        Text(
            "پیشرفت، از کارهای کوچک مداوم ساخته می‌شود.",
            modifier = Modifier.fillMaxWidth(),
            color = Muted,
            fontSize = 14.sp
        )

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PlayerHeader() {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier
                .size(60.dp)
                .border(2.dp, Gold, CircleShape)
                .background(Color(0xFF263B55), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("ش", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Gold2)
        }

        Column(Modifier.width(120.dp)) {
            Text("شهریار", fontSize = 22.sp, fontWeight = FontWeight.Black, color = White)
            Text("Lv. 1", color = Gold, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(
                progress = { .25f },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = Crystal,
                trackColor = Color(0xFF20364F)
            )
            Text("25 / 100 XP", fontSize = 10.sp, color = Muted)
        }

        Spacer(Modifier.width(2.dp))

        CurrencyChip("🪙", "120")
        CurrencyChip("💎", "1")
        CurrencyChip("⚡", "8/10")
    }
}

@Composable
private fun CurrencyChip(icon: String, value: String) {
    Surface(
        color = Color(0xB20A1627),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x335CCFFF))
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, fontSize = 16.sp)
            Spacer(Modifier.width(4.dp))
            Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun SideMenu(
    modifier: Modifier = Modifier,
    onAction: (String) -> Unit
) {
    Column(
        modifier = modifier.width(88.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SideButton("♛", "فروشگاه") { onAction("فروشگاه در مرحله بعد") }
        SideButton("🎁", "رویدادها") { onAction("رویدادها در مرحله بعد") }
        SideButton("▣", "جوایز") { onAction("جوایز در مرحله بعد") }
        SideButton("🏆", "دستاوردها") { onAction("دستاوردها در مرحله بعد") }
    }
}

@Composable
private fun SideButton(icon: String, label: String, action: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(90.dp)
            .clickable(onClick = action),
        color = Color(0xE60B1728),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .28f))
    ) {
        Column(
            Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 26.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 13.sp, color = White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun HeroScene(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cx = size.width * .53f
        val bottom = size.height * .95f

        drawCircle(
            color = Gold.copy(alpha = .08f),
            radius = size.width * .38f,
            center = Offset(cx, size.height * .40f)
        )

        val coat = Path().apply {
            moveTo(cx, size.height * .23f)
            lineTo(cx - size.width * .16f, size.height * .39f)
            lineTo(cx - size.width * .23f, bottom)
            lineTo(cx + size.width * .18f, bottom)
            lineTo(cx + size.width * .13f, size.height * .42f)
            close()
        }
        drawPath(coat, Color(0xFF111722))

        drawCircle(
            color = Color(0xFFC5A38D),
            radius = size.width * .065f,
            center = Offset(cx, size.height * .20f)
        )

        drawPath(
            Path().apply {
                moveTo(cx - size.width * .07f, size.height * .19f)
                lineTo(cx - size.width * .05f, size.height * .12f)
                lineTo(cx + size.width * .065f, size.height * .13f)
                lineTo(cx + size.width * .08f, size.height * .19f)
                close()
            },
            Color(0xFF17171A)
        )

        drawLine(
            color = Gold,
            start = Offset(cx + size.width * .08f, size.height * .35f),
            end = Offset(cx + size.width * .12f, size.height * .78f),
            strokeWidth = 3.dp.toPx()
        )

        drawRect(
            color = Gold.copy(alpha = .55f),
            topLeft = Offset(cx - size.width * .07f, size.height * .42f),
            size = Size(size.width * .15f, 4.dp.toPx())
        )

        val lionX = size.width * .24f
        val lionY = size.height * .76f
        drawCircle(
            color = Color(0xFF6C5543),
            radius = size.width * .14f,
            center = Offset(lionX, lionY)
        )
        drawCircle(
            color = Color(0xFFB68B60),
            radius = size.width * .085f,
            center = Offset(lionX, lionY - size.width * .015f)
        )
        drawCircle(Color(0xFF191510), 4.dp.toPx(), Offset(lionX - 12.dp.toPx(), lionY - 8.dp.toPx()))
        drawCircle(Color(0xFF191510), 4.dp.toPx(), Offset(lionX + 12.dp.toPx(), lionY - 8.dp.toPx()))
        drawPath(
            Path().apply {
                moveTo(lionX - 8.dp.toPx(), lionY + 8.dp.toPx())
                lineTo(lionX, lionY + 14.dp.toPx())
                lineTo(lionX + 8.dp.toPx(), lionY + 8.dp.toPx())
                close()
            },
            Color(0xFF221812)
        )
    }
}

@Composable
private fun QuoteCard(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.width(155.dp),
        color = Panel,
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .28f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("«نسخه بهتر خودت،", color = White, fontSize = 13.sp)
            Text("در انتظار اقدام امروز توست.»", color = White, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text("◇", color = Gold, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun RankPanel() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(108.dp),
        color = Panel,
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Crystal.copy(alpha = .22f))
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(76.dp)
                    .background(
                        Brush.radialGradient(listOf(Gold.copy(alpha=.65f), Color(0xFF1D3552))),
                        CircleShape
                    )
                    .border(2.dp, Gold.copy(alpha=.55f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("♜", fontSize = 34.sp, color = Gold2)
            }

            Spacer(Modifier.width(14.dp))

            Column {
                Text("رنک فعلی", color = Muted, fontSize = 13.sp)
                Text("حماسی III", color = Gold2, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("✦ 54 / 100", color = White, fontSize = 15.sp)
                LinearProgressIndicator(
                    progress = { .54f },
                    modifier = Modifier.fillMaxWidth().height(7.dp),
                    color = Gold,
                    trackColor = Color(0xFF091523)
                )
            }
        }
    }
}

@Composable
private fun StartButton(onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(88.dp)
            .clickable(onClick = onClick),
        color = Color(0xFFB87912),
        shape = RoundedCornerShape(26.dp),
        border = androidx.compose.foundation.BorderStroke(2.dp, Gold2)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF8B5A0E), Color(0xFFE5A72C), Color(0xFF8B5A0E))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("⚔", fontSize = 34.sp, color = White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("شروع بازی", fontSize = 30.sp, fontWeight = FontWeight.Black, color = White)
                    Text("۳۰ دقیقه", fontSize = 15.sp, color = White.copy(alpha=.9f))
                }
                Text("‹", fontSize = 38.sp, color = White)
            }
        }
    }
}

@Composable
private fun GameBottomBar(
    selected: Nav,
    onSelect: (Nav) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xF2071324),
        tonalElevation = 0.dp
    ) {
        BottomItem(Nav.HOME, "⌂", "خانه", selected, onSelect)
        BottomItem(Nav.TASKS, "✓", "کارها", selected, onSelect)
        BottomItem(Nav.STATS, "▥", "آمار", selected, onSelect)
        BottomItem(Nav.REWARDS, "🎁", "جوایز", selected, onSelect)
        BottomItem(Nav.MORE, "☰", "بیشتر", selected, onSelect)
    }
}

@Composable
private fun RowScope.BottomItem(
    nav: Nav,
    icon: String,
    label: String,
    selected: Nav,
    onSelect: (Nav) -> Unit
) {
    NavigationBarItem(
        selected = nav == selected,
        onClick = { onSelect(nav) },
        icon = {
            Text(
                icon,
                fontSize = 22.sp,
                color = if (nav == selected) Gold2 else Color(0xFF9CC9E8)
            )
        },
        label = {
            Text(
                label,
                color = if (nav == selected) White else Muted,
                fontSize = 11.sp
            )
        }
    )
}

@Composable
private fun ComingSoon(
    modifier: Modifier = Modifier,
    title: String,
    onHome: () -> Unit
) {
    Box(
        modifier
            .fillMaxSize()
            .background(Night.copy(alpha=.92f)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = Panel2,
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha=.35f))
        ) {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(title, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                Text("ظاهر مرحله اول آماده است.", color = Muted)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onHome) { Text("بازگشت به خانه") }
            }
        }
    }
}
