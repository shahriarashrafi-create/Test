package com.herolife.app

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay

private val Night = Color(0xFF06101E)
private val Glass = Color(0xE80A1729)
private val Gold = Color(0xFFFFC84A)
private val GoldSoft = Color(0xFFFFE6A1)
private val Crystal = Color(0xFF8EDBFF)
private val TextSoft = Color(0xFFC5D0E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        immersive()
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = Gold,
                        secondary = Crystal,
                        background = Night,
                        surface = Glass,
                        onPrimary = Night,
                        onBackground = Color.White,
                        onSurface = Color.White
                    )
                ) { HeroLifeStage04() }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    private fun immersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(
            WindowInsetsCompat.Type.statusBars() or
                WindowInsetsCompat.Type.navigationBars()
        )
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
}

private enum class Screen {
    HOME, HEROES, COMPANIONS, SHOP, EVENTS, REWARDS, ACHIEVEMENTS, TASKS, STATS, MORE, START
}

private enum class Gender { MALE, FEMALE }

private data class HeroChoice(
    val id: Int,
    val name: String,
    val gender: Gender,
    val drawable: Int
)

private data class CompanionChoice(
    val id: Int,
    val name: String,
    val drawable: Int
)

@Composable
private fun HeroLifeStage04() {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("herolife_stage04", android.content.Context.MODE_PRIVATE)
    }

    val heroes = remember {
        listOf(
            HeroChoice(1, "شهریار", Gender.MALE, R.drawable.hero_01),
            HeroChoice(2, "شهریار — شب", Gender.MALE, R.drawable.hero_02),
            HeroChoice(3, "آریانا", Gender.FEMALE, R.drawable.hero_female_01),
            HeroChoice(4, "آریانا — شب", Gender.FEMALE, R.drawable.hero_female_02)
        )
    }

    val companions = remember {
        listOf(
            CompanionChoice(1, "شیر سلطنتی", R.drawable.companion_lion_01),
            CompanionChoice(2, "ببر سفید", R.drawable.companion_tiger_01),
            CompanionChoice(3, "گرگ سایه", R.drawable.companion_wolf_01),
            CompanionChoice(4, "پلنگ شب", R.drawable.companion_panther_01)
        )
    }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var heroId by remember { mutableIntStateOf(prefs.getInt("hero", 1)) }
    var companionId by remember { mutableIntStateOf(prefs.getInt("companion", 1)) }

    val hero = heroes.firstOrNull { it.id == heroId } ?: heroes.first()
    val companion = companions.firstOrNull { it.id == companionId } ?: companions.first()

    Box(Modifier.fillMaxSize().background(Night)) {
        Image(
            painter = painterResource(R.drawable.stage03_environment),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent, Night.copy(alpha = .60f))
                    )
                )
        )

        if (screen == Screen.HOME) {
            HomeLobby(
                hero = hero,
                companion = companion,
                onHero = { screen = Screen.HEROES },
                onCompanion = { screen = Screen.COMPANIONS },
                onScreen = { screen = it }
            )
        }

        AnimatedVisibility(
            visible = screen != Screen.HOME,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            when (screen) {
                Screen.HEROES -> HeroPicker(
                    heroes = heroes,
                    selectedId = heroId,
                    onSelect = {
                        heroId = it
                        prefs.edit().putInt("hero", it).apply()
                    },
                    onBack = { screen = Screen.HOME }
                )
                Screen.COMPANIONS -> CompanionPicker(
                    companions = companions,
                    selectedId = companionId,
                    onSelect = {
                        companionId = it
                        prefs.edit().putInt("companion", it).apply()
                    },
                    onBack = { screen = Screen.HOME }
                )
                else -> SimpleDestination(
                    screen = screen,
                    onBack = { screen = Screen.HOME }
                )
            }
        }
    }
}

@Composable
private fun HomeLobby(
    hero: HeroChoice,
    companion: CompanionChoice,
    onHero: () -> Unit,
    onCompanion: () -> Unit,
    onScreen: (Screen) -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        CompactHeader(
            modifier = Modifier.align(Alignment.TopCenter)
        )

        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 12.dp)
                .width(94.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            LobbyButton("♛", "فروشگاه") { onScreen(Screen.SHOP) }
            LobbyButton("🎁", "رویدادها") { onScreen(Screen.EVENTS) }
            LobbyButton("▣", "جوایز") { onScreen(Screen.REWARDS) }
            LobbyButton("🏆", "دستاوردها") { onScreen(Screen.ACHIEVEMENTS) }
        }

        // Character is ONE layer, not a stack of cropped pictures.
        Image(
            painter = painterResource(hero.drawable),
            contentDescription = hero.name,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(bottom = 205.dp, start = 70.dp)
                .width(330.dp)
                .height(590.dp)
                .clip(RoundedCornerShape(26.dp))
                .clickable(onClick = onHero),
            contentScale = ContentScale.Crop
        )

        Image(
            painter = painterResource(companion.drawable),
            contentDescription = companion.name,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 70.dp, top = 310.dp)
                .size(205.dp)
                .clip(RoundedCornerShape(26.dp))
                .clickable(onClick = onCompanion),
            contentScale = ContentScale.Crop
        )

        RankCard(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 215.dp, start = 100.dp, end = 30.dp)
        )

        StartButton(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 112.dp, start = 60.dp, end = 60.dp),
            onClick = { onScreen(Screen.START) }
        )

        BottomBar(
            modifier = Modifier.align(Alignment.BottomCenter),
            onScreen = onScreen
        )
    }
}

@Composable
private fun CompactHeader(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xC9071324)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(52.dp)
                    .background(Color(0xFF263B55), CircleShape)
                    .border(2.dp, Gold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("ش", color = GoldSoft, fontSize = 24.sp, fontWeight = FontWeight.Black)
            }

            Spacer(Modifier.width(8.dp))

            Column(Modifier.width(118.dp)) {
                Text("شهریار", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
                Text("Lv. 28", color = Gold, fontSize = 12.sp)
                LinearProgressIndicator(
                    progress = { .78f },
                    modifier = Modifier.fillMaxWidth().height(5.dp),
                    color = Crystal,
                    trackColor = Color(0xFF152B43)
                )
            }

            Spacer(Modifier.width(10.dp))
            ResourceText("🪙", "2,437")
            Spacer(Modifier.width(8.dp))
            ResourceText("💎", "12")
            Spacer(Modifier.width(8.dp))
            ResourceText("⚡", "8/10")
        }
    }
}

@Composable
private fun ResourceText(icon: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 15.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun LobbyButton(icon: String, label: String, action: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            .clickable(onClick = action),
        color = Glass,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .38f))
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 22.sp)
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RankCard(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth().height(92.dp),
        color = Color(0xEE0C2038),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Crystal.copy(alpha = .25f))
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("♜", color = GoldSoft, fontSize = 38.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("رنک فعلی", color = TextSoft, fontSize = 12.sp)
                Text("حماسی III", color = GoldSoft, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("✦ 54 / 100", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun StartButton(
    modifier: Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(88.dp)
            .clickable(onClick = onClick),
        color = Color(0xFFC58B1D),
        shape = RoundedCornerShape(25.dp),
        border = androidx.compose.foundation.BorderStroke(2.dp, GoldSoft)
    ) {
        Box(
            Modifier.background(
                Brush.horizontalGradient(
                    listOf(Color(0xFF8C5C0D), Color(0xFFE0A52A), Color(0xFF8C5C0D))
                )
            ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("⚔ شروع بازی", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("۳۰ دقیقه", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun BottomBar(
    modifier: Modifier,
    onScreen: (Screen) -> Unit
) {
    NavigationBar(
        modifier = modifier,
        containerColor = Color(0xF2071324)
    ) {
        NavItem("⌂", "خانه") { onScreen(Screen.HOME) }
        NavItem("✓", "کارها") { onScreen(Screen.TASKS) }
        NavItem("▥", "آمار") { onScreen(Screen.STATS) }
        NavItem("🎁", "جوایز") { onScreen(Screen.REWARDS) }
        NavItem("☰", "بیشتر") { onScreen(Screen.MORE) }
    }
}

@Composable
private fun RowScope.NavItem(icon: String, label: String, action: () -> Unit) {
    NavigationBarItem(
        selected = label == "خانه",
        onClick = action,
        icon = { Text(icon, color = if (label == "خانه") GoldSoft else Crystal, fontSize = 20.sp) },
        label = { Text(label, color = if (label == "خانه") Color.White else TextSoft, fontSize = 10.sp) }
    )
}

@Composable
private fun HeroPicker(
    heroes: List<HeroChoice>,
    selectedId: Int,
    onSelect: (Int) -> Unit,
    onBack: () -> Unit
) {
    var gender by remember {
        mutableStateOf(
            heroes.firstOrNull { it.id == selectedId }?.gender ?: Gender.MALE
        )
    }
    val visible = heroes.filter { it.gender == gender }
    var previewId by remember { mutableIntStateOf(selectedId) }
    val preview = heroes.firstOrNull { it.id == previewId && it.gender == gender }
        ?: visible.first()

    var rotationY by remember { mutableFloatStateOf(0f) }

    FullScreenPanel(title = "انتخاب قهرمان", onBack = onBack) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            FilterButton("مرد", gender == Gender.MALE) {
                gender = Gender.MALE
                previewId = heroes.first { it.gender == Gender.MALE }.id
                rotationY = 0f
            }
            Spacer(Modifier.width(10.dp))
            FilterButton("زن", gender == Gender.FEMALE) {
                gender = Gender.FEMALE
                previewId = heroes.first { it.gender == Gender.FEMALE }.id
                rotationY = 0f
            }
        }

        Spacer(Modifier.height(12.dp))

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(500.dp),
            color = Color(0xB5071324),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Crystal.copy(alpha = .25f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Image(
                    painter = painterResource(preview.drawable),
                    contentDescription = preview.name,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .graphicsLayer {
                            // Stage 04 rotation-preview simulation.
                            // Real 3D mesh rendering will replace this in the game-engine stage.
                            rotationY = rotationY
                            cameraDistance = 18f * density
                        }
                        .pointerInput(preview.id) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                rotationY = (rotationY + dragAmount.x * .28f)
                                    .coerceIn(-42f, 42f)
                            }
                        },
                    contentScale = ContentScale.Crop
                )

                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(18.dp),
                    color = Glass,
                    shape = RoundedCornerShape(100.dp)
                ) {
                    Text(
                        "↔ برای مشاهده زاویه، بکش",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                        color = GoldSoft,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            visible.forEach { item ->
                Image(
                    painter = painterResource(item.drawable),
                    contentDescription = item.name,
                    modifier = Modifier
                        .padding(5.dp)
                        .size(72.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            2.dp,
                            if (item.id == preview.id) Gold else Color.Transparent,
                            RoundedCornerShape(14.dp)
                        )
                        .clickable {
                            previewId = item.id
                            rotationY = 0f
                        },
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                onSelect(preview.id)
                onBack()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Night)
        ) {
            Text("انتخاب این قهرمان", fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun CompanionPicker(
    companions: List<CompanionChoice>,
    selectedId: Int,
    onSelect: (Int) -> Unit,
    onBack: () -> Unit
) {
    var previewId by remember { mutableIntStateOf(selectedId) }
    val preview = companions.firstOrNull { it.id == previewId } ?: companions.first()
    var rotationY by remember { mutableFloatStateOf(0f) }

    FullScreenPanel(title = "انتخاب همراه", onBack = onBack) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(470.dp),
            color = Color(0xB5071324),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Crystal.copy(alpha = .25f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Image(
                    painter = painterResource(preview.drawable),
                    contentDescription = preview.name,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .graphicsLayer {
                            rotationY = rotationY
                            cameraDistance = 18f * density
                        }
                        .pointerInput(preview.id) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                rotationY = (rotationY + dragAmount.x * .28f)
                                    .coerceIn(-42f, 42f)
                            }
                        },
                    contentScale = ContentScale.Crop
                )

                Text(
                    preview.name,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(18.dp),
                    color = GoldSoft,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            companions.forEach { item ->
                Image(
                    painter = painterResource(item.drawable),
                    contentDescription = item.name,
                    modifier = Modifier
                        .padding(4.dp)
                        .size(62.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .border(
                            2.dp,
                            if (item.id == preview.id) Gold else Color.Transparent,
                            RoundedCornerShape(13.dp)
                        )
                        .clickable {
                            previewId = item.id
                            rotationY = 0f
                        },
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        Button(
            onClick = {
                onSelect(preview.id)
                onBack()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Night)
        ) {
            Text("انتخاب این همراه", fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun FilterButton(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .width(120.dp)
            .height(42.dp)
            .clickable(onClick = onClick),
        color = if (selected) Gold else Color(0xFF10243A),
        shape = RoundedCornerShape(100.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                title,
                color = if (selected) Night else Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun FullScreenPanel(
    title: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Night.copy(alpha = .97f))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "‹",
                    modifier = Modifier
                        .size(46.dp)
                        .clickable(onClick = onBack),
                    color = GoldSoft,
                    fontSize = 36.sp
                )
                Text(
                    title,
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black
                )
            }
            content()
        }
    }
}

@Composable
private fun SimpleDestination(
    screen: Screen,
    onBack: () -> Unit
) {
    val title = when (screen) {
        Screen.SHOP -> "فروشگاه"
        Screen.EVENTS -> "رویدادها"
        Screen.REWARDS -> "جوایز"
        Screen.ACHIEVEMENTS -> "دستاوردها"
        Screen.TASKS -> "کارها"
        Screen.STATS -> "آمار"
        Screen.MORE -> "بیشتر"
        Screen.START -> "شروع بازی"
        else -> "HeroLife"
    }

    FullScreenPanel(title = title, onBack = onBack) {
        Spacer(Modifier.height(100.dp))
        Text(
            if (screen == Screen.START)
                "مرحله بعد: موتور بازی واقعی ۳۰ دقیقه‌ای"
            else
                "این بخش در مرحله‌های بعد روی همین پروژه کامل می‌شود.",
            color = TextSoft,
            fontSize = 16.sp
        )
    }
}
