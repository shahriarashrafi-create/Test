# آپلود و ساخت APK

1. محتوای این ZIP را در ریشه Repository گیت‌هاب قرار بده.
2. وارد تب **Actions** شو.
3. Workflow با نام **Build Android APK** را اجرا کن یا روی branch اصلی Push انجام بده.
4. بعد از سبز شدن Build، از بخش **Artifacts** فایل **shahriar-million-path-v11-apk** را دانلود کن.
5. داخل Artifact فایل `app-debug.apk` قرار دارد.
