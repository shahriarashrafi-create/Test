# Female Production Texture Slots — C06

Final texture files should be placed here when authored:

Skin_BaseColor
Skin_Normal
Skin_Roughness
Skin_AO

Face_BaseColor
Face_Normal
Face_Roughness
Face_AO

Eyes_BaseColor
Eyes_Normal
Eyes_Roughness

Hair_BaseColor
Hair_Normal
Hair_Roughness
Hair_Alpha

Leather_BaseColor
Leather_Normal
Leather_MetallicRoughness
Leather_AO

Cloth_BaseColor
Cloth_Normal
Cloth_Roughness
Cloth_AO

Gold_BaseColor
Gold_Normal
Gold_MetallicRoughness
Gold_AO

C06 deliberately does not insert fake photographic textures.
