# C07 — Skeleton / Idle Integration

C07 keeps the C06.1 runtime-crash fix and adds the first animation layer.

Implemented:
- Character animation state
- Humanoid idle-pose evaluator
- breathing cycle
- slow cinematic body sway
- head/neck/arm rig-pose contract
- runtime-safe animation timing in the OpenGL renderer
- production skeleton naming contract retained
- no companion

Important:
The current custom procedural GLB still does not contain real `JOINTS_0` / `WEIGHTS_0`.
Creating fake skin-weight data would make the asset less reliable and could reintroduce crashes.

So C07 uses a safe visible idle motion now, while the authored humanoid skeleton contract is ready
for a real skinned GLB in the next character stage.

This means:
- the model should no longer stand completely frozen
- 360-degree drag remains active
- existing memory/crash fix remains active
