package com.herolife.app.character

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HeroViewerStateTest {
    @Test fun femaleMaleSelectionIsIndependentFromUi() {
        val male = HeroViewerState().select(HeroGender.MALE)
        assertEquals(HeroGender.MALE, male.selected.gender)
        assertTrue(male.selected.assetPath.endsWith(".glb"))
    }

    @Test fun zoomIsBoundedByCharacterContract() {
        val state = HeroViewerState().zoomBy(100f)
        assertEquals(state.selected.maxZoom, state.zoom, 0.001f)
    }

    @Test fun resetReturnsFrontView() {
        val state = HeroViewerState().rotateBy(130f).resetView()
        assertEquals(0f, state.yawDegrees, 0.001f)
    }
}
