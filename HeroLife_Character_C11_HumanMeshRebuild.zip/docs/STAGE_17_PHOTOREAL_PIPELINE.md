# Stage 17 — Photoreal Character Pipeline

Stage 17 freezes the lobby layout and makes the character asset replaceable.

## Target visual
The reference image is treated only as art direction. It is not cropped into the app.

## Separation
The production screen must remain independent layers:
1. Lobby environment/background
2. Character 3D viewport
3. Left action rail
4. Quote card
5. Rank card
6. Start-game CTA
7. Bottom navigation

A new female/male GLB can therefore be swapped without repositioning the HUD.

## Professional GLB contract
Final production characters should contain:
- physically based BaseColor
- Normal maps
- Metallic/Roughness maps where appropriate
- skin, eye and hair materials
- separate cloth/leather/metal materials
- humanoid skeleton when animation is required
- Idle animation
- centered feet/origin
- front-facing yaw = 0

## Mobile rules
Use sensible texture budgets. Prefer 2K maps for most materials and only use 4K when the
visual gain is visible on a phone. LOD and texture compression can be added during release
optimization.

## Current bundled assets
The bundled female/male GLBs remain local verification assets so the repository builds
without downloading third-party models. They are not claimed to be final photoreal assets.
Replace only those two GLBs later; the UI architecture remains intact.
