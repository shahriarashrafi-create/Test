package com.herolife.app.model

enum class HeroGender { MALE, FEMALE }
enum class CompanionType { LION, TIGER, WOLF, PANTHER }
enum class LobbyDestination { HOME, TASKS, STATS, REWARDS, MORE, SHOP, EVENTS, ACHIEVEMENTS, START }

data class HeroSelection(
    val gender: HeroGender = HeroGender.FEMALE,
    val variant: Int = 0
)

data class CompanionSelection(
    val type: CompanionType = CompanionType.TIGER,
    val variant: Int = 0
)

data class LobbyState(
    val hero: HeroSelection = HeroSelection(),
    val companion: CompanionSelection = CompanionSelection(),
    val destination: LobbyDestination = LobbyDestination.HOME
)
