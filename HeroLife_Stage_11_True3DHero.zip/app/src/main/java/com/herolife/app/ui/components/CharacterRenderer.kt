package com.herolife.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.herolife.app.model.HeroSelection

/**
 * True 3D hero boundary.
 *
 * The lobby knows nothing about OpenGL. It only owns this slot.
 * Drag horizontally to rotate the model. Tap to switch male/female.
 */
@Composable
fun CharacterRenderer(
    selection: HeroSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    AndroidView(
        modifier = modifier,
        factory = { context ->
            Hero3DView(
                context = context,
                gender = selection.gender,
                onTap = onClick
            )
        },
        update = { view ->
            view.setGender(selection.gender)
        }
    )
}
