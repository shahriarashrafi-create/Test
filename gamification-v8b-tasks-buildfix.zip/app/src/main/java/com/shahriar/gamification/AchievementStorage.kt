package com.shahriar.gamification

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AchievementStorage {
    private const val PREFS = "achievement_preferences"
    private const val KEY_ITEMS = "achievement_items_json"

    fun load(context: Context): List<AchievementItem> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_ITEMS, null)
        if (raw.isNullOrBlank()) return defaults()

        return runCatching {
            val array = JSONArray(raw)
            val result = mutableListOf<AchievementItem>()
            var index = 0
            while (index < array.length()) {
                val obj = array.getJSONObject(index)
                result.add(
                    AchievementItem(
                        id = obj.optLong("id", System.currentTimeMillis() + index),
                        title = obj.optString("title", "دستاورد"),
                        description = obj.optString("description", ""),
                        category = runCatching {
                            AchievementCategory.valueOf(obj.optString("category", AchievementCategory.DAILY.name))
                        }.getOrDefault(AchievementCategory.DAILY),
                        progress = obj.optInt("progress", 0).coerceAtLeast(0),
                        target = obj.optInt("target", 1).coerceAtLeast(1),
                        rewardXp = obj.optInt("rewardXp", 0).coerceAtLeast(0),
                        rewardGold = obj.optInt("rewardGold", 0).coerceAtLeast(0),
                        rewardDiamonds = obj.optInt("rewardDiamonds", 0).coerceAtLeast(0)
                    )
                )
                index++
            }
            result
        }.getOrElse { defaults() }
    }

    fun save(context: Context, items: List<AchievementItem>) {
        val array = JSONArray()
        var index = 0
        while (index < items.size) {
            val item = items[index]
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("title", item.title)
            obj.put("description", item.description)
            obj.put("category", item.category.name)
            obj.put("progress", item.progress)
            obj.put("target", item.target)
            obj.put("rewardXp", item.rewardXp)
            obj.put("rewardGold", item.rewardGold)
            obj.put("rewardDiamonds", item.rewardDiamonds)
            array.put(obj)
            index++
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ITEMS, array.toString())
            .apply()
    }

    private fun defaults(): List<AchievementItem> {
        return listOf(
            AchievementItem(101, "اولین بازی امروز", "یک Session را کامل کن", AchievementCategory.DAILY, 0, 1, 40, 15, 0),
            AchievementItem(102, "سه کار پشت سرهم", "بدون بعداً یا رد کردن، ۳ کار کامل کن", AchievementCategory.DAILY, 1, 3, 60, 25, 0),
            AchievementItem(201, "پنج روز فعال", "در ۵ روز مختلف این هفته بازی کن", AchievementCategory.WEEKLY, 2, 5, 180, 80, 1),
            AchievementItem(202, "ده بازی هفتگی", "در این هفته ۱۰ Session کامل کن", AchievementCategory.WEEKLY, 4, 10, 250, 120, 1),
            AchievementItem(301, "پنجاه بازی ماهانه", "در طول ماه ۵۰ بازی کامل کن", AchievementCategory.MONTHLY, 18, 50, 700, 300, 3),
            AchievementItem(302, "بیست روز فعال", "۲۰ روز در ماه فعالیت ثبت کن", AchievementCategory.MONTHLY, 7, 20, 500, 220, 2),
            AchievementItem(401, "صد بازی", "اولین نقطه عطف بزرگ", AchievementCategory.LONG_TERM, 37, 100, 1500, 700, 8),
            AchievementItem(402, "پانصد بازی", "ثبات بلندمدت در اجرا", AchievementCategory.LONG_TERM, 37, 500, 5000, 2500, 25),
            AchievementItem(403, "هزار بازی", "دستاورد افسانه‌ای", AchievementCategory.LONG_TERM, 37, 1000, 12000, 6000, 60)
        )
    }
}
