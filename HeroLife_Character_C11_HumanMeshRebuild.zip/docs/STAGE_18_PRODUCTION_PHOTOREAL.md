# Stage 18 — Production Photoreal Integration

Requested scope:
- Real female GLB slot
- Real male GLB slot
- Hero selection screen
- No companion

## Runtime behavior
The app checks these first:
`models/production/female_photoreal.glb`
`models/production/male_photoreal.glb`

If present, they are loaded automatically.
If not present, the existing verification models are used so CI/build stays green.

## Why this matters
The model no longer needs another lobby redesign. Professional art is now a drop-in asset.
The user can open Hero selection, preview female/male in the same 3D viewer, rotate 360°, then confirm.

## Honesty about photorealism
This ZIP does not fabricate a fake "photoreal" human. A genuinely photoreal final character
still requires an authored/licensed GLB asset. Stage 18 completes the production integration path.
