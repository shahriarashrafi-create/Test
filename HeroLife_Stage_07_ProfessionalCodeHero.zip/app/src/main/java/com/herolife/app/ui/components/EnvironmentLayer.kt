package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.herolife.app.ui.theme.HL
import kotlin.math.sin

@Composable
fun EnvironmentLayer(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF20344D),
                    Color(0xFF13263D),
                    Color(0xFF091627),
                    HL.Void
                )
            )
        )

        drawCircle(
            color = Color(0xFFFFD796).copy(alpha = .15f),
            radius = size.width * .38f,
            center = Offset(
                x = size.width * .73f,
                y = size.height * .19f
            )
        )

        val distantMountains = Path().apply {
            moveTo(0f, size.height * .46f)
            lineTo(size.width * .12f, size.height * .31f)
            lineTo(size.width * .24f, size.height * .46f)
            lineTo(size.width * .37f, size.height * .26f)
            lineTo(size.width * .51f, size.height * .47f)
            lineTo(size.width * .66f, size.height * .22f)
            lineTo(size.width * .82f, size.height * .43f)
            lineTo(size.width, size.height * .30f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(
            path = distantMountains,
            color = Color(0xFF1C334D)
        )

        val nearMountains = Path().apply {
            moveTo(0f, size.height * .58f)
            lineTo(size.width * .17f, size.height * .40f)
            lineTo(size.width * .31f, size.height * .60f)
            lineTo(size.width * .48f, size.height * .38f)
            lineTo(size.width * .62f, size.height * .60f)
            lineTo(size.width * .79f, size.height * .42f)
            lineTo(size.width, size.height * .57f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(
            path = nearMountains,
            color = Color(0xFF10253A)
        )

        repeat(9) { index ->
            val baseX = size.width * (.58f + index * .045f)
            val towerHeight =
                size.height * (.09f + (index % 4) * .025f)
            val towerWidth =
                size.width * (.025f + (index % 2) * .008f)

            drawRect(
                color = Color(0xFF29435E),
                topLeft = Offset(
                    x = baseX,
                    y = size.height * .48f - towerHeight
                ),
                size = Size(
                    width = towerWidth,
                    height = towerHeight
                )
            )

            drawLine(
                color = Color(0xFFFFD278).copy(alpha = .45f),
                start = Offset(
                    x = baseX + towerWidth / 2f,
                    y = size.height * .48f - towerHeight
                ),
                end = Offset(
                    x = baseX + towerWidth / 2f,
                    y = size.height * .48f - towerHeight - size.height * .035f
                ),
                strokeWidth = 2f
            )
        }

        repeat(14) { index ->
            val x =
                size.width * ((index * 17 % 100) / 100f)
            val y =
                size.height * (.12f + ((index * 29 % 38) / 100f))

            drawCircle(
                color = Color.White.copy(
                    alpha = .08f + (index % 3) * .02f
                ),
                radius = 1.4f + (index % 3),
                center = Offset(x, y)
            )
        }

        val terraceY = size.height * .70f

        drawRect(
            color = Color(0xFF15283A),
            topLeft = Offset(
                x = 0f,
                y = terraceY
            ),
            size = Size(
                width = size.width,
                height = size.height - terraceY
            )
        )

        repeat(8) { index ->
            val x = size.width * (index / 7f)
            val lampY = terraceY + size.height * .07f
            drawCircle(
                color = HL.Gold.copy(
                    alpha = .35f + .05f * sin(index.toFloat())
                ),
                radius = size.width * .015f,
                center = Offset(
                    x = x,
                    y = lampY
                )
            )
        }

        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color.Transparent,
                    HL.Void.copy(alpha = .22f),
                    HL.Void.copy(alpha = .82f)
                )
            ),
            topLeft = Offset(
                x = 0f,
                y = size.height * .52f
            ),
            size = Size(
                width = size.width,
                height = size.height * .48f
            )
        )
    }
}
