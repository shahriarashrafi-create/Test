package com.shahriar.gamification

data class GameTaskItem(
    val id: Long,
    val title: String,
    val category: String,
    val xpReward: Int,
    val goldReward: Int,
    val diamondReward: Int,
    val active: Boolean,
    val order: Int
)
