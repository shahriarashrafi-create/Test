package com.shahriar.gamification

data class AppSettings(
    val defaultGameMinutes: Int = 30,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val motivationalEffectsEnabled: Boolean = true,
    val confirmDeleteEnabled: Boolean = true
)
