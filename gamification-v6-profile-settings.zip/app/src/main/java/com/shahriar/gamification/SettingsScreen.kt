package com.shahriar.gamification

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SettingsPanel = Color(0xF20A1931)
private val SettingsDeep = Color(0xF2071428)
private val SettingsGold = Color(0xFFFFC857)
private val SettingsCyan = Color(0xFF39D7FF)
private val SettingsWhite = Color(0xFFF8FAFF)
private val SettingsMuted = Color(0xFFAFC0D8)

@Composable
fun SettingsScreen(
    padding: PaddingValues,
    settings: AppSettings,
    onBack: () -> Unit,
    onSettingsChanged: (AppSettings) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier
                    .size(44.dp)
                    .clickable(onClick = onBack),
                shape = RoundedCornerShape(14.dp),
                color = SettingsPanel,
                border = BorderStroke(1.dp, SettingsGold.copy(alpha = 0.28f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowBack,
                        contentDescription = "بازگشت",
                        tint = SettingsGold
                    )
                }
            }

            Text(
                text = "تنظیمات",
                modifier = Modifier.weight(1f),
                color = SettingsWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.width(44.dp))
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = SettingsPanel,
            border = BorderStroke(1.dp, SettingsCyan.copy(alpha = 0.20f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Schedule, null, tint = SettingsCyan)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            "زمان پیش‌فرض بازی",
                            color = SettingsWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            "وقتی اپ باز می‌شود این گزینه انتخاب باشد.",
                            color = SettingsMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DurationButton(
                        modifier = Modifier.weight(1f),
                        minutes = 10,
                        selected = settings.defaultGameMinutes == 10,
                        onClick = {
                            onSettingsChanged(
                                settings.copy(defaultGameMinutes = 10)
                            )
                        }
                    )
                    DurationButton(
                        modifier = Modifier.weight(1f),
                        minutes = 30,
                        selected = settings.defaultGameMinutes == 30,
                        onClick = {
                            onSettingsChanged(
                                settings.copy(defaultGameMinutes = 30)
                            )
                        }
                    )
                    DurationButton(
                        modifier = Modifier.weight(1f),
                        minutes = 60,
                        selected = settings.defaultGameMinutes == 60,
                        onClick = {
                            onSettingsChanged(
                                settings.copy(defaultGameMinutes = 60)
                            )
                        }
                    )
                }
            }
        }

        SettingToggle(
            icon = Icons.Rounded.VolumeUp,
            title = "صدای بازی",
            subtitle = "افکت‌های صوتی Combo و پاداش‌ها",
            checked = settings.soundEnabled,
            onCheckedChange = {
                onSettingsChanged(settings.copy(soundEnabled = it))
            }
        )

        SettingToggle(
            icon = Icons.Rounded.Vibration,
            title = "ویبره",
            subtitle = "بازخورد لمسی هنگام انجام کارها",
            checked = settings.vibrationEnabled,
            onCheckedChange = {
                onSettingsChanged(settings.copy(vibrationEnabled = it))
            }
        )

        SettingToggle(
            icon = Icons.Rounded.AutoAwesome,
            title = "افکت‌های انگیزشی",
            subtitle = "نمایش Double Kill، Legendary و افکت‌های مشابه",
            checked = settings.motivationalEffectsEnabled,
            onCheckedChange = {
                onSettingsChanged(
                    settings.copy(motivationalEffectsEnabled = it)
                )
            }
        )

        SettingToggle(
            icon = Icons.Rounded.DeleteForever,
            title = "تأیید قبل از حذف",
            subtitle = "قبل از حذف دائمی کار یا پاداش تأیید بگیرد",
            checked = settings.confirmDeleteEnabled,
            onCheckedChange = {
                onSettingsChanged(settings.copy(confirmDeleteEnabled = it))
            }
        )
    }
}

@Composable
private fun DurationButton(
    modifier: Modifier,
    minutes: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(54.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        color = if (selected) SettingsCyan.copy(alpha = 0.16f) else SettingsDeep,
        border = BorderStroke(
            1.dp,
            if (selected) SettingsCyan.copy(alpha = 0.65f)
            else Color.White.copy(alpha = 0.06f)
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = "$minutes دقیقه",
                color = if (selected) SettingsGold else SettingsWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun SettingToggle(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(21.dp),
        color = SettingsPanel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 15.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(13.dp),
                color = SettingsCyan.copy(alpha = 0.10f)
            ) {
                Box(
                    modifier = Modifier.size(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = SettingsCyan)
                }
            }

            Spacer(Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    title,
                    color = SettingsWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    subtitle,
                    color = SettingsMuted,
                    fontSize = 10.sp,
                    maxLines = 2
                )
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
        }
    }
}
