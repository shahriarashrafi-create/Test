package com.shahriar.gamification

data class UserProfile(
    val name: String = "شهریار",
    val title: String = "جنگجوی رشد",
    val photoUri: String = ""
)
