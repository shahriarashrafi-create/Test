package com.herolife.app.character

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class C06ProductionContractTest {
    @Test fun materialBudgetContainsCoreHumanMaterials() {
        val names = C06ProductionContract.materials.map { it.name }
        assertTrue("Skin" in names)
        assertTrue("Face" in names)
        assertTrue("Hair" in names)
        assertTrue("Eyes" in names)
    }

    @Test fun humanoidRigUsesFourInfluencesForMobile() {
        assertEquals(4, C06ProductionContract.rig.maxInfluencesPerVertex)
    }

    @Test fun skeletonContractContainsHeadAndHands() {
        assertTrue("Head" in HumanoidSkeleton.requiredBones)
        assertTrue("LeftHand" in HumanoidSkeleton.requiredBones)
        assertTrue("RightHand" in HumanoidSkeleton.requiredBones)
    }
}
