# HeroLife Stage 08 — Cinematic Code Lobby

A focused visual overhaul. No new product features.

## Changes
- menu is physically locked to LEFT regardless of RTL
- quote is physically locked to RIGHT regardless of RTL
- hero enlarged and re-proportioned
- hero remains 100% code-drawn
- improved face, hair, armor, cloak, hands/arms and lower body detailing
- male/female code hero remains switchable by tapping Hero
- no Companion
- deeper multi-layer fantasy environment
- castle lights, fog, birds and terrace lighting
- compact top HUD with coded avatar and XP text
- unique code-drawn icons for Shop / Events / Rewards / Achievements
- smaller, richer Rank panel
- shield emblem upgraded
- Start Game is now a fantasy hexagonal Path instead of a normal rounded button
- real code-drawn crossed swords instead of an X
- tighter bottom navigation

No screenshots, crops, generated bitmap mockups or hidden full-screen images are used.
