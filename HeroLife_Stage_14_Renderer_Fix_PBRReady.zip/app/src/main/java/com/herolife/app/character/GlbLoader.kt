package com.herolife.app.character

import android.content.Context
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class GlbPrimitive(
    val vertices: FloatArray,
    val indices: IntArray,
    val color: FloatArray
)

data class GlbModel(
    val primitives: List<GlbPrimitive>
)

class GlbLoader(private val context: Context) {

    fun load(assetPath: String): GlbModel {
        val bytes = context.assets.open(assetPath).use { it.readBytes() }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        require(bb.int == 0x46546C67) { "Not a GLB file" }
        require(bb.int == 2) { "Only GLB 2.0 is supported" }
        bb.int // total length

        var json: JSONObject? = null
        var bin = ByteArray(0)

        while (bb.remaining() >= 8) {
            val len = bb.int
            val type = bb.int
            val chunk = ByteArray(len)
            bb.get(chunk)
            when (type) {
                0x4E4F534A -> json = JSONObject(String(chunk, Charsets.UTF_8).trim())
                0x004E4942 -> bin = chunk
            }
        }

        val doc = requireNotNull(json)
        val accessors = doc.getJSONArray("accessors")
        val views = doc.getJSONArray("bufferViews")
        val materials = doc.optJSONArray("materials")
        val mesh = doc.getJSONArray("meshes").getJSONObject(0)
        val prims = mesh.getJSONArray("primitives")

        fun accessorFloats(index: Int): FloatArray {
            val a = accessors.getJSONObject(index)
            val view = views.getJSONObject(a.getInt("bufferView"))
            val count = a.getInt("count")
            val comps = when (a.getString("type")) {
                "SCALAR" -> 1
                "VEC2" -> 2
                "VEC3" -> 3
                "VEC4" -> 4
                else -> error("Unsupported accessor type")
            }
            require(a.getInt("componentType") == 5126)
            val offset = view.optInt("byteOffset", 0) + a.optInt("byteOffset", 0)
            val stride = view.optInt("byteStride", comps * 4)
            val out = FloatArray(count * comps)
            val b = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until count) {
                b.position(offset + i * stride)
                for (c in 0 until comps) out[i * comps + c] = b.float
            }
            return out
        }

        fun accessorIndices(index: Int): IntArray {
            val a = accessors.getJSONObject(index)
            val view = views.getJSONObject(a.getInt("bufferView"))
            val count = a.getInt("count")
            val type = a.getInt("componentType")
            val offset = view.optInt("byteOffset", 0) + a.optInt("byteOffset", 0)
            val b = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
            b.position(offset)
            return IntArray(count) {
                when (type) {
                    5121 -> b.get().toInt() and 0xFF
                    5123 -> b.short.toInt() and 0xFFFF
                    5125 -> b.int
                    else -> error("Unsupported index type")
                }
            }
        }

        val result = mutableListOf<GlbPrimitive>()
        for (i in 0 until prims.length()) {
            val p = prims.getJSONObject(i)
            val attrs = p.getJSONObject("attributes")
            val pos = accessorFloats(attrs.getInt("POSITION"))
            val norm = if (attrs.has("NORMAL")) accessorFloats(attrs.getInt("NORMAL"))
                       else FloatArray(pos.size)
            val vertices = FloatArray((pos.size / 3) * 6)
            for (v in 0 until pos.size / 3) {
                vertices[v*6] = pos[v*3]
                vertices[v*6+1] = pos[v*3+1]
                vertices[v*6+2] = pos[v*3+2]
                vertices[v*6+3] = norm[v*3]
                vertices[v*6+4] = norm[v*3+1]
                vertices[v*6+5] = norm[v*3+2]
            }

            val indices = accessorIndices(p.getInt("indices"))
            val color = floatArrayOf(.7f,.7f,.7f,1f)
            if (materials != null && p.has("material")) {
                val m = materials.getJSONObject(p.getInt("material"))
                val pbr = m.optJSONObject("pbrMetallicRoughness")
                val arr = pbr?.optJSONArray("baseColorFactor")
                if (arr != null && arr.length() >= 4) {
                    for (c in 0..3) color[c] = arr.getDouble(c).toFloat()
                }
            }
            result += GlbPrimitive(vertices, indices, color)
        }
        return GlbModel(result)
    }
}
