package com.herolife.app.ui.components

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import com.herolife.app.character.*
import com.herolife.app.model.HeroGender
import java.nio.*
import kotlin.math.sin

class GlbHero3DView(
    context: Context,
    gender: HeroGender,
    private val onTap: () -> Unit
) : GLSurfaceView(context) {
    private val renderer3d=HeroRenderer(context,gender)
    private var lastX=0f; private var downX=0f; private var downY=0f; private var dragged=false

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8,8,8,8,24,0)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        setZOrderOnTop(true)
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        setRenderer(renderer3d)
        renderMode=RENDERMODE_CONTINUOUSLY
        preserveEGLContextOnPause=true
    }

    fun setGender(g:HeroGender)=renderer3d.setGender(g)

    override fun onTouchEvent(e:MotionEvent):Boolean {
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN->{lastX=e.x;downX=e.x;downY=e.y;dragged=false;return true}
            MotionEvent.ACTION_MOVE->{
                if(kotlin.math.abs(e.x-downX)>8 || kotlin.math.abs(e.y-downY)>8) dragged=true
                renderer3d.targetYaw+=(e.x-lastX)*.29f
                lastX=e.x
                return true
            }
            MotionEvent.ACTION_UP->{if(!dragged) onTap();return true}
        }
        return true
    }
}

private class HeroRenderer(
    private val context:Context,
    initial:HeroGender
):GLSurfaceView.Renderer {
    @Volatile var targetYaw=0f
    private var yaw=0f
    private var gender=initial
    @Volatile private var pending:HeroGender?=initial
    private var program=0
    private var gpu:List<GpuPrimitive> = emptyList()
    private var bounds=GlbBounds(-.5f,0f,-.5f,.5f,3f,.5f)
    private var hasSkinning=false

    private val projection=FloatArray(16)
    private val view=FloatArray(16)
    private val model=FloatArray(16)
    private val mv=FloatArray(16)
    private val mvp=FloatArray(16)

    private var animTime=0f
    private var lastFrameNanos=0L
    private val boneMatrices=FloatArray(10*16)

    fun setGender(g:HeroGender){if(g!=gender)pending=g}

    override fun onSurfaceCreated(gl:javax.microedition.khronos.opengles.GL10?,cfg:javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(0f,0f,0f,0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        program=makeProgram(VS,FS)
        load(gender)
    }

    override fun onSurfaceChanged(gl:javax.microedition.khronos.opengles.GL10?,w:Int,h:Int) {
        GLES20.glViewport(0,0,w,h)
        Matrix.perspectiveM(projection,0,29f,w.toFloat()/h.coerceAtLeast(1),.05f,100f)
    }

    override fun onDrawFrame(gl:javax.microedition.khronos.opengles.GL10?) {
        pending?.let{gender=it;load(it);pending=null}

        val now=System.nanoTime()
        if(lastFrameNanos!=0L) {
            val dt=((now-lastFrameNanos)/1_000_000_000.0).toFloat().coerceIn(0f,.05f)
            animTime += dt
        }
        lastFrameNanos=now

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)

        yaw+=(targetYaw-yaw)*.10f
        val asset=CharacterAssetRegistry.forGender(gender)
        val h=bounds.height
        val normalizedScale=(2.95f/h)*asset.scale

        Matrix.setLookAtM(view,0,0f,1.52f,7.8f,0f,1.48f,0f,0f,1f,0f)
        Matrix.setIdentityM(model,0)
        Matrix.translateM(
            model,0,
            -bounds.centerX*normalizedScale,
            1.48f-(bounds.centerY*normalizedScale)+asset.verticalOffset,
            -bounds.centerZ*normalizedScale
        )
        Matrix.rotateM(model,0,yaw,0f,1f,0f)
        Matrix.scaleM(model,0,normalizedScale,normalizedScale,normalizedScale)

        Matrix.multiplyMM(mv,0,view,0,model,0)
        Matrix.multiplyMM(mvp,0,projection,0,mv,0)

        updateBones(animTime, hasSkinning)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uMvp"),1,false,mvp,0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uModel"),1,false,model,0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uBones"),10,false,boneMatrices,0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uUseSkin"),if(hasSkinning)1f else 0f)

        gpu.forEach{it.draw(program)}
    }

    private fun updateBones(t:Float, enabled:Boolean) {
        for(i in 0 until 10) Matrix.setIdentityM(boneMatrices,i*16)
        if(!enabled) return

        val breath=sin(t*1.65f)
        val sway=sin(t*.72f)

        // Bone 1 Hips
        setPivotRotation(1,0f,.88f,0f,0f,0f,sway*.55f)
        // Bone 2 Spine
        setPivotRotation(2,0f,1.03f,0f,breath*.28f,0f,sway*.22f)
        // Bone 3 Chest
        setPivotRotation(3,0f,1.20f,0f,breath*.42f,0f,-sway*.18f)
        // Bone 4 Neck
        setPivotRotation(4,0f,1.38f,0f,0f,sway*.32f,0f)
        // Bone 5 Head
        setPivotRotation(5,0f,1.51f,0f,0f,sway*.55f,sway*.12f)
        // Arms
        setPivotRotation(6,-.215f,1.235f,0f,0f,0f,2.2f+breath*.20f)
        setPivotRotation(7,.215f,1.235f,0f,0f,0f,-2.2f-breath*.20f)
        // Legs remain stable in lobby idle.
    }

    private fun setPivotRotation(index:Int,px:Float,py:Float,pz:Float,rx:Float,ry:Float,rz:Float) {
        val o=index*16
        Matrix.setIdentityM(boneMatrices,o)
        Matrix.translateM(boneMatrices,o,px,py,pz)
        if(rx!=0f) Matrix.rotateM(boneMatrices,o,rx,1f,0f,0f)
        if(ry!=0f) Matrix.rotateM(boneMatrices,o,ry,0f,1f,0f)
        if(rz!=0f) Matrix.rotateM(boneMatrices,o,rz,0f,0f,1f)
        Matrix.translateM(boneMatrices,o,-px,-py,-pz)
    }

    private fun load(g:HeroGender) {
        val loader=GlbLoader(context)
        val primary=ProductionHeroAssets.resolvePath(context,g)
        val loaded=try { loader.load(primary) } catch(_:Throwable) {
            loader.load(ProductionHeroAssets.fallbackPath(g))
        }
        gpu=emptyList()
        bounds=loaded.bounds
        hasSkinning=loaded.hasSkinning
        gpu=loaded.primitives.map(::GpuPrimitive)
        targetYaw=0f; yaw=0f; animTime=0f; lastFrameNanos=0L
    }

    private fun shader(type:Int,src:String)=GLES20.glCreateShader(type).also{
        GLES20.glShaderSource(it,src); GLES20.glCompileShader(it)
    }
    private fun makeProgram(v:String,f:String)=GLES20.glCreateProgram().also{
        GLES20.glAttachShader(it,shader(GLES20.GL_VERTEX_SHADER,v))
        GLES20.glAttachShader(it,shader(GLES20.GL_FRAGMENT_SHADER,f))
        GLES20.glLinkProgram(it)
    }

    companion object {
        const val VS="""
            uniform mat4 uMvp;
            uniform mat4 uModel;
            uniform mat4 uBones[10];
            uniform float uUseSkin;

            attribute vec3 aPosition;
            attribute vec3 aNormal;
            attribute vec2 aUv;
            attribute vec4 aJoints;
            attribute vec4 aWeights;

            varying vec3 vNormal;
            varying vec2 vUv;

            mat4 skinMatrix() {
                if (uUseSkin < 0.5) return mat4(1.0);
                mat4 s = mat4(0.0);
                s += uBones[int(aJoints.x)] * aWeights.x;
                s += uBones[int(aJoints.y)] * aWeights.y;
                s += uBones[int(aJoints.z)] * aWeights.z;
                s += uBones[int(aJoints.w)] * aWeights.w;
                return s;
            }

            void main(){
                mat4 skin=skinMatrix();
                vec4 p=skin*vec4(aPosition,1.0);
                vec3 n=mat3(skin)*aNormal;
                vNormal=normalize(mat3(uModel)*n);
                vUv=aUv;
                gl_Position=uMvp*p;
            }
        """
        const val FS="""
            precision mediump float;
            uniform vec4 uBase;
            uniform float uMetallic;
            uniform float uRoughness;
            varying vec3 vNormal;
            varying vec2 vUv;
            void main(){
                vec3 N=normalize(vNormal);
                vec3 key=normalize(vec3(-.42,.88,-.35));
                vec3 fill=normalize(vec3(.62,.36,-.22));
                float kd=max(dot(N,key),0.0);
                float fd=max(dot(N,fill),0.0);
                float front=max(dot(N,vec3(0.,0.,-1.)),0.0);
                float rim=pow(1.0-front,2.6);
                float metal=max(uMetallic,0.0);
                float rough=clamp(uRoughness,0.04,1.0);
                float spec=(1.0-rough)*(.08+.25*metal)*pow(max(kd,0.0),4.0);
                vec3 color=uBase.rgb*(.50+kd*.64+fd*.20);
                color+=vec3(1.0,.70,.30)*(kd*.10+spec);
                color+=vec3(.18,.55,1.0)*rim*.14;
                gl_FragColor=vec4(color,uBase.a);
            }
        """
    }
}

private class GpuPrimitive(private val primitive:GlbPrimitive) {
    private val vb=ByteBuffer.allocateDirect(primitive.vertices.size*4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(primitive.vertices);position(0)}
    private val ib=ByteBuffer.allocateDirect(primitive.indices.size*2)
        .order(ByteOrder.nativeOrder()).asShortBuffer().apply {
            primitive.indices.forEach { put(it.toShort()) }
            position(0)
        }

    fun draw(program:Int) {
        val stride=64
        fun attr(name:String,size:Int,offsetFloats:Int) {
            val loc=GLES20.glGetAttribLocation(program,name)
            if(loc<0) return
            vb.position(offsetFloats)
            GLES20.glEnableVertexAttribArray(loc)
            GLES20.glVertexAttribPointer(loc,size,GLES20.GL_FLOAT,false,stride,vb)
        }

        GLES20.glUniform4fv(GLES20.glGetUniformLocation(program,"uBase"),1,primitive.material.baseColor,0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uMetallic"),primitive.material.metallic)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uRoughness"),primitive.material.roughness)

        attr("aPosition",3,0)
        attr("aNormal",3,3)
        attr("aUv",2,6)
        attr("aJoints",4,8)
        attr("aWeights",4,12)

        ib.position(0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,primitive.indices.size,GLES20.GL_UNSIGNED_SHORT,ib)

        listOf("aPosition","aNormal","aUv","aJoints","aWeights").forEach {
            val loc=GLES20.glGetAttribLocation(program,it)
            if(loc>=0) GLES20.glDisableVertexAttribArray(loc)
        }
    }
}
