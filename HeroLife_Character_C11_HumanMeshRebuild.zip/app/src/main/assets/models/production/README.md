# Production Photoreal GLB Drop-in

Put professionally authored/licensed models here:

- `female_photoreal.glb`
- `male_photoreal.glb`

The app automatically prefers these files.
If one is absent, it falls back to the verification GLB so the build still works.

Recommended final asset:
- realistic adult human mesh
- 2K/4K BaseColor
- Normal
- Metallic/Roughness
- Occlusion
- separate Skin / Eye / Hair / Cloth / Leather / Metal materials
- humanoid skeleton
- Idle animation
- front-facing at yaw 0
- feet centered near origin
- mobile-optimized polygon count

No companion/pet asset is used in Stage 18.
