package com.herolife.app.character

import android.content.Context
import com.herolife.app.model.HeroGender

object RealHumanAssetResolver {
    private const val FEMALE_REAL = "models/production/real/female/female_real.glb"
    private const val MALE_REAL = "models/production/real/male/male_real.glb"
    private const val FEMALE_FALLBACK = "models/production/female_procedural_fallback.glb"
    private const val MALE_FALLBACK = "models/male_realistic_01.glb"

    fun resolve(context: Context, gender: HeroGender): String {
        val primary = when (gender) {
            HeroGender.FEMALE -> FEMALE_REAL
            HeroGender.MALE -> MALE_REAL
        }
        if (exists(context, primary)) return primary

        return when (gender) {
            HeroGender.FEMALE -> FEMALE_FALLBACK
            HeroGender.MALE -> MALE_FALLBACK
        }
    }

    fun realAssetInstalled(context: Context, gender: HeroGender): Boolean {
        val path = when (gender) {
            HeroGender.FEMALE -> FEMALE_REAL
            HeroGender.MALE -> MALE_REAL
        }
        return exists(context, path)
    }

    private fun exists(context: Context, path: String): Boolean =
        try {
            context.assets.open(path).close()
            true
        } catch (_: Throwable) {
            false
        }
}
