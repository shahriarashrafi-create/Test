# HeroLife Character C02 — Face Anatomy
Cumulative project. Replaces C01 female production GLB.

15,208 vertices • 28,648 triangles

Main goal: move the face/body away from the mannequin look before hair, clothing and textures.
No companion.

Next: C03 — Hair Volume & Silhouette.
