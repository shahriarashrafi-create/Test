# آپلود در GitHub

1. محتوای ZIP را Extract کنید.
2. همه فایل‌ها و پوشه‌ها را داخل ریشه Repository قرار دهید.
3. Commit/Push کنید.
4. در GitHub وارد Actions > Build Android APK شوید.
5. بعد از سبز شدن Build، از Artifacts فایل `shahriar-million-path-v5-apk` را دانلود کنید.
