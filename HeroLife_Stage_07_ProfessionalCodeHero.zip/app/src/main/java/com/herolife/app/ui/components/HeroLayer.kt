package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.herolife.app.model.HeroGender
import com.herolife.app.model.HeroSelection
import com.herolife.app.ui.theme.HL

@Composable
fun HeroLayer(
    selection: HeroSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Canvas(
        modifier = modifier
            .clickable(onClick = onClick)
    ) {
        val cx = size.width * .52f
        val top = size.height * .06f
        val shoulderY = size.height * .26f
        val waistY = size.height * .50f
        val bottom = size.height * .96f

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    HL.Gold.copy(alpha = .16f),
                    HL.Crystal.copy(alpha = .05f),
                    Color.Transparent
                )
            ),
            radius = size.width * .48f,
            center = Offset(
                x = cx,
                y = size.height * .40f
            )
        )

        if (selection.gender == HeroGender.FEMALE) {
            val hairBack = Path().apply {
                moveTo(cx - size.width * .13f, top + size.height * .04f)
                cubicTo(
                    cx - size.width * .25f,
                    shoulderY,
                    cx - size.width * .20f,
                    size.height * .60f,
                    cx - size.width * .10f,
                    size.height * .76f
                )
                lineTo(cx + size.width * .12f, size.height * .73f)
                cubicTo(
                    cx + size.width * .24f,
                    size.height * .56f,
                    cx + size.width * .20f,
                    shoulderY,
                    cx + size.width * .12f,
                    top + size.height * .05f
                )
                close()
            }

            drawPath(
                path = hairBack,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF2B1716),
                        Color(0xFF120D0F)
                    )
                )
            )

            drawCircle(
                color = Color(0xFFE2B49B),
                radius = size.width * .085f,
                center = Offset(
                    x = cx,
                    y = top + size.height * .08f
                )
            )

            drawArc(
                color = Color(0xFF2A1515),
                startAngle = 195f,
                sweepAngle = 150f,
                useCenter = false,
                topLeft = Offset(
                    x = cx - size.width * .09f,
                    y = top
                ),
                size = androidx.compose.ui.geometry.Size(
                    width = size.width * .18f,
                    height = size.width * .15f
                ),
                style = Stroke(width = size.width * .028f)
            )

            val torso = Path().apply {
                moveTo(cx, shoulderY)
                lineTo(cx - size.width * .18f, shoulderY + size.height * .06f)
                lineTo(cx - size.width * .13f, waistY)
                lineTo(cx - size.width * .16f, bottom)
                lineTo(cx + size.width * .15f, bottom)
                lineTo(cx + size.width * .12f, waistY)
                lineTo(cx + size.width * .18f, shoulderY + size.height * .06f)
                close()
            }

            drawPath(
                path = torso,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF171B23),
                        Color(0xFF0D1118)
                    )
                )
            )

            drawLine(
                color = HL.Gold,
                start = Offset(
                    x = cx - size.width * .12f,
                    y = shoulderY + size.height * .10f
                ),
                end = Offset(
                    x = cx + size.width * .11f,
                    y = shoulderY + size.height * .10f
                ),
                strokeWidth = size.width * .010f
            )

            drawLine(
                color = HL.Gold.copy(alpha = .80f),
                start = Offset(
                    x = cx,
                    y = shoulderY + size.height * .03f
                ),
                end = Offset(
                    x = cx,
                    y = waistY
                ),
                strokeWidth = size.width * .006f
            )

            drawCircle(
                color = HL.GoldBright,
                radius = size.width * .015f,
                center = Offset(
                    x = cx,
                    y = waistY + size.height * .02f
                )
            )

            drawLine(
                color = Color(0xFFDBAE90),
                start = Offset(
                    x = cx - size.width * .16f,
                    y = shoulderY + size.height * .07f
                ),
                end = Offset(
                    x = cx - size.width * .22f,
                    y = size.height * .62f
                ),
                strokeWidth = size.width * .045f
            )

            drawLine(
                color = Color(0xFFDBAE90),
                start = Offset(
                    x = cx + size.width * .16f,
                    y = shoulderY + size.height * .07f
                ),
                end = Offset(
                    x = cx + size.width * .20f,
                    y = size.height * .59f
                ),
                strokeWidth = size.width * .045f
            )

            drawLine(
                color = HL.Gold.copy(alpha = .70f),
                start = Offset(
                    x = cx - size.width * .21f,
                    y = size.height * .61f
                ),
                end = Offset(
                    x = cx - size.width * .17f,
                    y = size.height * .66f
                ),
                strokeWidth = size.width * .014f
            )
        } else {
            drawCircle(
                color = Color(0xFFD2A68C),
                radius = size.width * .080f,
                center = Offset(
                    x = cx,
                    y = top + size.height * .08f
                )
            )

            val hair = Path().apply {
                moveTo(cx - size.width * .08f, top + size.height * .05f)
                lineTo(cx - size.width * .04f, top)
                lineTo(cx + size.width * .09f, top + size.height * .02f)
                lineTo(cx + size.width * .10f, top + size.height * .08f)
                close()
            }
            drawPath(
                path = hair,
                color = Color(0xFF17171A)
            )

            val coat = Path().apply {
                moveTo(cx, shoulderY)
                lineTo(cx - size.width * .20f, shoulderY + size.height * .06f)
                lineTo(cx - size.width * .23f, bottom)
                lineTo(cx + size.width * .20f, bottom)
                lineTo(cx + size.width * .18f, shoulderY + size.height * .06f)
                close()
            }

            drawPath(
                path = coat,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF151A22),
                        Color(0xFF0C1016)
                    )
                )
            )

            drawLine(
                color = HL.Gold,
                start = Offset(
                    x = cx + size.width * .07f,
                    y = shoulderY + size.height * .05f
                ),
                end = Offset(
                    x = cx + size.width * .13f,
                    y = size.height * .77f
                ),
                strokeWidth = size.width * .010f
            )

            drawLine(
                color = HL.Gold.copy(alpha = .70f),
                start = Offset(
                    x = cx - size.width * .11f,
                    y = waistY
                ),
                end = Offset(
                    x = cx + size.width * .12f,
                    y = waistY
                ),
                strokeWidth = size.width * .009f
            )
        }
    }
}
