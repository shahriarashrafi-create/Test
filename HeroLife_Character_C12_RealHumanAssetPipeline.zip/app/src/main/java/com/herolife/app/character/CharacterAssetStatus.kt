package com.herolife.app.character

import android.content.Context
import com.herolife.app.model.HeroGender

data class CharacterAssetStatus(
    val gender: HeroGender,
    val usingRealAsset: Boolean,
    val resolvedPath: String
)

object CharacterAssetStatusReader {
    fun read(context: Context, gender: HeroGender): CharacterAssetStatus =
        CharacterAssetStatus(
            gender = gender,
            usingRealAsset = RealHumanAssetResolver.realAssetInstalled(context, gender),
            resolvedPath = RealHumanAssetResolver.resolve(context, gender)
        )
}
