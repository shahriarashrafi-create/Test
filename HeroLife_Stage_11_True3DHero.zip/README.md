# HeroLife Stage 11 — True 3D Hero

Stage 11 replaces the Canvas character with a genuine OpenGL ES 3D character renderer.

## What is real 3D here?
The hero is built from 3D meshes rendered through:
- perspective projection
- depth buffer
- surface normals
- directional/rim lighting
- real Y-axis rotation
- a transparent OpenGL viewport embedded in Compose

Drag horizontally over the hero to rotate it.
Tap the hero to switch female/male.

This is a **procedural 3D model**, not a screenshot and not a cropped image.
It deliberately uses no external GLB/FBX asset yet, so the project remains self-contained.

## Architecture
The 3D renderer is isolated behind `CharacterRenderer`.
A future production GLB/FBX character can replace only the renderer/model layer.
HUD, menus, quote, rank, Start button and navigation do not need to move.

## Layout fixes
- left menu clipping fixed
- quote clipping fixed
- hero viewport separated from rank/CTA
- rank card reduced
- Start button reduced and separated
- decorative lower dots removed
- XP uses forced LTR order: 6240 / 8000 XP
- immersive system bars retained
- companion remains removed

## Important
A photoreal production-quality human requires a dedicated authored 3D asset
(GLB/FBX with materials/textures). Stage 11 establishes the real-time 3D pipeline
and interaction without pretending a procedural mesh is a photoreal scanned human.
