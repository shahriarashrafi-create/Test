package com.shahriar.gamification

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChecklistRtl
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App()
                }
            }
        }
    }
}

private val BgTop = Color(0xFF040B16)
private val BgMid = Color(0xFF08162D)
private val BgBottom = Color(0xFF030814)
private val Panel = Color(0xE6182A48)
private val PanelSoft = Color(0xD313233E)
private val White = Color(0xFFF8FBFF)
private val Muted = Color(0xFFB5C4DA)
private val Gold = Color(0xFFF7C95A)
private val Cyan = Color(0xFF48CFFF)
private val CyanBright = Color(0xFF82EBFF)
private val Purple = Color(0xFFC278FF)
private val Green = Color(0xFF6FE1A8)
private val Pink = Color(0xFFFF7ABB)

private enum class MainTab(val title: String) {
    HOME("خانه"), TASKS("کارها"), STATS("آمار"), TIMESHEET("تایم شیت"), NETWORK("شبکه سازی")
}

private enum class GameMode(val title: String, val subtitle: String) {
    TEN("۱۰ دقیقه", "یک کار"),
    THIRTY("۳۰ دقیقه", "استاندارد"),
    SIXTY("۶۰ دقیقه", "تمرکز عمیق")
}

@Composable
private fun App() {
    var tab by remember { mutableStateOf(MainTab.HOME) }
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = { BottomBar(tab = tab, onSelect = { tab = it }) }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize()) {
            GameBackground()
            when (tab) {
                MainTab.HOME -> HomeScreen(padding)
                MainTab.TASKS -> PlaceholderScreen(padding, "کارها", "ترتیب کارها، اولویت‌بندی و بانک مأموریت‌ها")
                MainTab.STATS -> PlaceholderScreen(padding, "آمار", "آمار تیم، فروش، شبکه‌سازی و رشد")
                MainTab.TIMESHEET -> PlaceholderScreen(padding, "تایم شیت", "برنامه زمانی روزانه و هفتگی")
                MainTab.NETWORK -> PlaceholderScreen(padding, "شبکه سازی", "پراسپکت، معرف، مشاور معرف و اقدامات بعدی")
            }
        }
    }
}

@Composable
private fun GameBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgMid, BgBottom)))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Cyan.copy(alpha = 0.10f),
                radius = size.minDimension * 0.38f,
                center = Offset(size.width * 0.82f, size.height * 0.18f)
            )
            drawCircle(
                color = Gold.copy(alpha = 0.05f),
                radius = size.minDimension * 0.30f,
                center = Offset(size.width * 0.15f, size.height * 0.75f)
            )
            repeat(22) { i ->
                val x = size.width * (((i * 41) % 100) / 100f)
                val y = size.height * (((i * 63) % 100) / 100f)
                drawCircle(Color.White.copy(alpha = 0.08f), radius = 2f, center = Offset(x, y))
            }
        }
    }
}

@Composable
private fun HomeScreen(innerPadding: PaddingValues) {
    var mode by remember { mutableStateOf(GameMode.THIRTY) }
    val compact = LocalConfiguration.current.screenHeightDp < 760
    val p = if (compact) 8.dp else 10.dp
    val gap = if (compact) 7.dp else 9.dp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = p, vertical = gap),
        verticalArrangement = Arrangement.spacedBy(gap)
    ) {
        TopUtilityBar(compact = compact, modifier = Modifier.weight(0.26f))
        ProfileHeroCard(compact = compact, modifier = Modifier.weight(1.42f))
        FeatureGrid(compact = compact, modifier = Modifier.weight(1.34f))
        RankProgressCard(compact = compact, modifier = Modifier.weight(0.54f))
        ModeSelector(compact = compact, selected = mode, onSelect = { mode = it }, modifier = Modifier.weight(0.60f))
        StartGameCard(compact = compact, mode = mode, modifier = Modifier.weight(0.78f))
        TodayStrip(compact = compact, modifier = Modifier.weight(0.52f))
    }
}

@Composable
private fun TopUtilityBar(compact: Boolean, modifier: Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(modifier = Modifier.weight(1f))
        Surface(
            modifier = Modifier.size(if (compact) 40.dp else 46.dp),
            shape = RoundedCornerShape(14.dp),
            color = PanelSoft,
            border = BorderStroke(1.dp, Cyan.copy(alpha = 0.20f))
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.clickable { }) {
                Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات", tint = White, modifier = Modifier.size(if (compact) 22.dp else 24.dp))
            }
        }
    }
}

@Composable
private fun ProfileHeroCard(compact: Boolean, modifier: Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(if (compact) 20.dp else 24.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color(0x66B38B2E))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 10.dp else 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(if (compact) 62.dp else 68.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFFE8F59A), Color(0xFF85E4FF))))
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(Color(0x18000000)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("ش", color = Color(0xFF07111F), fontWeight = FontWeight.Black, fontSize = if (compact) 28.sp else 32.sp)
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("شهریار", color = White, fontWeight = FontWeight.Black, fontSize = if (compact) 21.sp else 24.sp)
                    Text("جنگجوی رشد | LV.28", color = Muted, fontSize = if (compact) 10.sp else 11.sp)
                }
                Text("♕", color = Gold, fontSize = if (compact) 28.sp else 32.sp)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("۶۲۴۰ / ۸۰۰۰ XP", color = Gold, fontWeight = FontWeight.Bold, fontSize = if (compact) 10.sp else 11.sp)
                Text("پیشرفت سطح", color = Muted, fontSize = if (compact) 9.sp else 10.sp)
            }
            GlowProgress(0.78f, compact)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                StatChip(modifier = Modifier.weight(1f), label = "رنک", value = "حماسی III", icon = Icons.Rounded.EmojiEvents, accent = Pink, compact = compact)
                StatChip(modifier = Modifier.weight(1f), label = "الماس", value = "۱۲", icon = Icons.Rounded.AutoAwesome, accent = Cyan, compact = compact)
                StatChip(modifier = Modifier.weight(1f), label = "طلا", value = "۲۵۳۷", icon = Icons.Rounded.ShoppingBag, accent = Gold, compact = compact)
            }
        }
    }
}

@Composable
private fun StatChip(modifier: Modifier, label: String, value: String, icon: ImageVector, accent: Color, compact: Boolean) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = Color(0x120FFFFFF),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = if (compact) 7.dp else 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(if (compact) 17.dp else 19.dp))
            Column {
                Text(label, color = Muted, fontSize = if (compact) 7.sp else 8.sp)
                Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = if (compact) 11.sp else 12.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun FeatureGrid(compact: Boolean, modifier: Modifier) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FeatureCard(Modifier.weight(1f), "فروشگاه", "پاداش واقعی", "🪙", Gold, compact)
            FeatureCard(Modifier.weight(1f), "رویدادها", "ایونت‌ها و اعضا", "📅", Cyan, compact)
        }
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FeatureCard(Modifier.weight(1f), "آینده بینی", "سال‌ها و نتایج", "🔮", Purple, compact)
            FeatureCard(Modifier.weight(1f), "دستاوردها", "روزانه تا بلندمدت", "🏆", Green, compact)
        }
    }
}

@Composable
private fun FeatureCard(modifier: Modifier, title: String, subtitle: String, emoji: String, accent: Color, compact: Boolean) {
    Surface(
        modifier = modifier.fillMaxSize(),
        shape = RoundedCornerShape(if (compact) 18.dp else 20.dp),
        color = Panel,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.24f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(if (compact) 42.dp else 48.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = if (compact) 24.sp else 27.sp)
            }
            Spacer(modifier = Modifier.width(7.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = if (compact) 14.sp else 15.sp)
                Text(subtitle, color = Muted, fontSize = if (compact) 7.sp else 8.sp, maxLines = 1)
            }
            Text("‹", color = White, fontSize = 24.sp)
        }
    }
}

@Composable
private fun RankProgressCard(compact: Boolean, modifier: Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color(0x66B38B2E))
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🛡️", fontSize = if (compact) 23.sp else 26.sp)
                Spacer(modifier = Modifier.width(7.dp))
                Text("حماسی III", color = White, fontWeight = FontWeight.Black, fontSize = if (compact) 15.sp else 17.sp)
                Spacer(modifier = Modifier.weight(1f))
                Text("۵۴ / ۱۰۰", color = Gold, fontWeight = FontWeight.Bold, fontSize = if (compact) 11.sp else 12.sp)
            }
            GlowProgress(0.54f, compact)
        }
    }
}

@Composable
private fun ModeSelector(compact: Boolean, selected: GameMode, onSelect: (GameMode) -> Unit, modifier: Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = PanelSoft,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Row(modifier = Modifier.fillMaxSize().padding(5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            ModeButton(Modifier.weight(1f), GameMode.SIXTY, selected == GameMode.SIXTY, compact) { onSelect(GameMode.SIXTY) }
            ModeButton(Modifier.weight(1f), GameMode.THIRTY, selected == GameMode.THIRTY, compact) { onSelect(GameMode.THIRTY) }
            ModeButton(Modifier.weight(1f), GameMode.TEN, selected == GameMode.TEN, compact) { onSelect(GameMode.TEN) }
        }
    }
}

@Composable
private fun ModeButton(modifier: Modifier, mode: GameMode, selected: Boolean, compact: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = modifier.fillMaxSize().clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) Color(0xFF12355F) else Color(0x100FFFFFF),
        border = BorderStroke(1.dp, if (selected) Cyan.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.06f))
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(mode.title, color = if (selected) Gold else White, fontWeight = FontWeight.Bold, fontSize = if (compact) 11.sp else 12.sp)
            Text(mode.subtitle, color = Muted, fontSize = if (compact) 7.sp else 8.sp)
        }
    }
}

@Composable
private fun StartGameCard(compact: Boolean, mode: GameMode, modifier: Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth().clickable { },
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
        border = BorderStroke(1.5.dp, Cyan.copy(alpha = 0.75f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF07255A), Color(0xFF0E67D1), Color(0xFF07255A))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("⚔️", fontSize = if (compact) 30.sp else 34.sp)
                Text("شروع بازی", color = White, fontWeight = FontWeight.Black, fontSize = if (compact) 23.sp else 26.sp)
                Text(mode.title, color = Gold, fontWeight = FontWeight.Bold, fontSize = if (compact) 11.sp else 12.sp)
            }
        }
    }
}

@Composable
private fun TodayStrip(compact: Boolean, modifier: Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("امروز", color = White, fontWeight = FontWeight.Black, fontSize = if (compact) 12.sp else 14.sp)
            TodayItem(Modifier.weight(1f), "۲", "بازی", Cyan, compact)
            TodayItem(Modifier.weight(1f), "۸", "کار", Gold, compact)
            TodayItem(Modifier.weight(1f), "۵", "شبکه سازی", Green, compact)
        }
    }
}

@Composable
private fun TodayItem(modifier: Modifier, value: String, label: String, accent: Color, compact: Boolean) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Text(value, color = accent, fontWeight = FontWeight.Black, fontSize = if (compact) 12.sp else 13.sp)
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, color = Muted, fontSize = if (compact) 7.sp else 8.sp, maxLines = 1)
    }
}

@Composable
private fun GlowProgress(value: Float, compact: Boolean) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (compact) 7.dp else 8.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(Color.White.copy(alpha = 0.08f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(value)
                .fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Cyan, CyanBright, Gold)))
        )
    }
}

@Composable
private fun BottomBar(tab: MainTab, onSelect: (MainTab) -> Unit) {
    Surface(color = Color(0xFF07101F), shadowElevation = 0.dp, tonalElevation = 0.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(74.dp)
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomTab(Modifier.weight(1f), tab == MainTab.NETWORK, "شبکه سازی", Icons.Rounded.Groups) { onSelect(MainTab.NETWORK) }
            BottomTab(Modifier.weight(1f), tab == MainTab.TIMESHEET, "تایم شیت", Icons.Rounded.Schedule) { onSelect(MainTab.TIMESHEET) }
            BottomTab(Modifier.weight(1f), tab == MainTab.STATS, "آمار", Icons.Rounded.Insights) { onSelect(MainTab.STATS) }
            BottomTab(Modifier.weight(1f), tab == MainTab.TASKS, "کارها", Icons.Rounded.ChecklistRtl) { onSelect(MainTab.TASKS) }
            BottomTab(Modifier.weight(1f), tab == MainTab.HOME, "خانه", Icons.Rounded.Home) { onSelect(MainTab.HOME) }
        }
    }
}

@Composable
private fun BottomTab(modifier: Modifier, selected: Boolean, label: String, icon: ImageVector, onClick: () -> Unit) {
    Surface(
        modifier = modifier.fillMaxHeight().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = if (selected) Color(0x22F7C95A) else Color.Transparent,
        border = if (selected) BorderStroke(1.dp, Gold.copy(alpha = 0.20f)) else null
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, tint = if (selected) Gold else Muted, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(3.dp))
            Text(label, color = if (selected) Gold else Muted, fontSize = 8.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
        }
    }
}

@Composable
private fun PlaceholderScreen(padding: PaddingValues, title: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Panel,
            border = BorderStroke(1.dp, Cyan.copy(alpha = 0.18f))
        ) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, color = White, fontWeight = FontWeight.Black, fontSize = 26.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(subtitle, color = Muted, textAlign = TextAlign.Center, fontSize = 12.sp)
            }
        }
    }
}
