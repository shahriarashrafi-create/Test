# C04 — Black/Gold Outfit & Armor
Cumulative character stage.

Added:
- black structured bodice and corset silhouette
- black hip armor and long skirt/coat-tail panels
- long black gloves/bracers
- thigh-high black boots
- metallic gold belt, neckline, shoulder, glove and boot accents
- separate leather / cloth / metallic-gold PBR materials
- pendant and front ornamental accents
- no companion

Stats: 26,930 vertices / 50,232 triangles / 80 primitives.

This stage establishes the target black/gold fantasy identity.
Next: C05 — PBR Skin, Eyes, Hair & Material Detail.
