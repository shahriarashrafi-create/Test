package com.shahriar.gamification

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val ProfilePanel = Color(0xF20A1931)
private val ProfileGold = Color(0xFFFFC857)
private val ProfileCyan = Color(0xFF39D7FF)
private val ProfileWhite = Color(0xFFF8FAFF)
private val ProfileMuted = Color(0xFFAFC0D8)
private val ProfileNight = Color(0xFF030916)

@Composable
fun ProfileEditScreen(
    padding: PaddingValues,
    profile: UserProfile,
    onBack: () -> Unit,
    onSave: (UserProfile) -> Unit
) {
    val context = LocalContext.current
    var name by remember(profile) { mutableStateOf(profile.name) }
    var title by remember(profile) { mutableStateOf(profile.title) }
    var photoUri by remember(profile) { mutableStateOf(profile.photoUri) }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            photoUri = uri.toString()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier
                    .size(44.dp)
                    .clickable(onClick = onBack),
                shape = RoundedCornerShape(14.dp),
                color = ProfilePanel,
                border = BorderStroke(1.dp, ProfileGold.copy(alpha = 0.28f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowBack,
                        contentDescription = "بازگشت",
                        tint = ProfileGold
                    )
                }
            }

            Text(
                text = "ویرایش پروفایل",
                modifier = Modifier.weight(1f),
                color = ProfileWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.width(44.dp))
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(26.dp),
            color = ProfilePanel,
            border = BorderStroke(1.2.dp, ProfileGold.copy(alpha = 0.32f))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(118.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(ProfileGold, ProfileCyan)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (photoUri.isNotBlank()) {
                        AsyncImage(
                            model = photoUri,
                            contentDescription = "عکس پروفایل",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(
                            text = name.trim().take(1).ifBlank { "ش" },
                            color = ProfileNight,
                            fontWeight = FontWeight.Black,
                            fontSize = 46.sp
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { photoLauncher.launch(arrayOf("image/*")) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ProfileCyan.copy(alpha = 0.18f),
                            contentColor = ProfileCyan
                        )
                    ) {
                        Icon(Icons.Rounded.PhotoCamera, null)
                        Spacer(Modifier.width(6.dp))
                        Text("انتخاب عکس")
                    }

                    if (photoUri.isNotBlank()) {
                        Button(
                            onClick = { photoUri = "" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0x33FF6B6B),
                                contentColor = Color(0xFFFF8E8E)
                            )
                        ) {
                            Icon(Icons.Rounded.Delete, null)
                            Spacer(Modifier.width(6.dp))
                            Text("حذف عکس")
                        }
                    }
                }

                Text(
                    text = "عکس انتخابی روی صفحه خانه ذخیره می‌شود.",
                    color = ProfileMuted,
                    fontSize = 11.sp
                )
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = ProfilePanel,
            border = BorderStroke(1.dp, ProfileCyan.copy(alpha = 0.20f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نام") },
                    singleLine = true
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("عنوان پروفایل") },
                    placeholder = { Text("مثلاً جنگجوی رشد") },
                    singleLine = true
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp),
            onClick = {
                onSave(
                    UserProfile(
                        name = name.trim().ifBlank { "شهریار" },
                        title = title.trim().ifBlank { "جنگجوی رشد" },
                        photoUri = photoUri
                    )
                )
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = ProfileGold,
                contentColor = ProfileNight
            ),
            shape = RoundedCornerShape(18.dp)
        ) {
            Icon(Icons.Rounded.Save, null)
            Spacer(Modifier.width(8.dp))
            Text(
                "ذخیره پروفایل",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp
            )
        }
    }
}
