# HeroLife — Stage 01

Stage 01 is a fresh cumulative Android project focused on the game-like Home appearance.

## Included
- Persian RTL
- dark navy / gold / crystal visual language
- player header with XP and currencies
- fantasy background rendered in Compose
- central hero silhouette + lion companion placeholder art
- side game menu
- current rank panel
- large 30-minute Start Game CTA
- five-item bottom navigation
- working taps that open Stage-2 placeholders

This ZIP is a complete project. Future stages should replace this ZIP with a new cumulative ZIP.
