package com.shahriar.gamification

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChecklistRtl
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.VideogameAsset
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    GamificationApp()
                }
            }
        }
    }
}

private val BgTop = Color(0xFF07101D)
private val BgBottom = Color(0xFF0A1730)
private val Panel = Color(0xE3172846)
private val PanelSoft = Color(0xD5132240)
private val Gold = Color(0xFFFFC857)
private val Cyan = Color(0xFF53D5FF)
private val Green = Color(0xFF65F29A)
private val Pink = Color(0xFFFF77B6)
private val WhiteMain = Color(0xFFF5F8FF)
private val WhiteSoft = Color(0xFFB7C4DA)

enum class MainTab(val title: String) {
    HOME("خانه"), TASKS("کارها"), STATS("آمار"), TIMESHEET("تایم شیت"), NETWORK("شبکه سازی")
}

enum class SessionMode(val title: String, val subtitle: String) {
    TEN("۱۰ دقیقه", "یک کار"),
    THIRTY("۳۰ دقیقه", "استاندارد"),
    SIXTY("۶۰ دقیقه", "تمرکز عمیق")
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}

@Composable
fun GamificationApp() {
    var selectedTab by remember { mutableStateOf(MainTab.HOME) }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            BottomNavigationBar(selectedTab) { selectedTab = it }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            BackgroundLayer()
            when (selectedTab) {
                MainTab.HOME -> CompactHomeScreen(innerPadding)
                MainTab.TASKS -> PlaceholderScreen(innerPadding, "کارها", "بانک کارها و ترتیب زمانی در نسخه بعدی کامل می‌شود.")
                MainTab.STATS -> PlaceholderScreen(innerPadding, "آمار", "آمار تیم، درختواره، فروش و GPV در نسخه بعدی اضافه می‌شود.")
                MainTab.TIMESHEET -> PlaceholderScreen(innerPadding, "تایم شیت", "برنامه زمانی هفتگی در نسخه بعدی اضافه می‌شود.")
                MainTab.NETWORK -> PlaceholderScreen(innerPadding, "شبکه سازی", "ثبت پراسپکت، معرف و اقدامات بعدی در نسخه بعدی تکمیل می‌شود.")
            }
        }
    }
}

@Composable
fun BackgroundLayer() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(color = Cyan.copy(alpha = 0.08f), radius = size.minDimension * 0.34f, center = Offset(size.width * 0.85f, size.height * 0.18f))
            drawCircle(color = Gold.copy(alpha = 0.06f), radius = size.minDimension * 0.28f, center = Offset(size.width * 0.16f, size.height * 0.75f))
            drawCircle(color = Color.White.copy(alpha = 0.035f), radius = size.minDimension * 0.52f, center = Offset(size.width * 0.52f, size.height * 0.50f), style = Stroke(width = 2f))
            repeat(16) { i ->
                val x = size.width * (((i * 39) % 100) / 100f)
                val y = size.height * (((i * 63) % 100) / 100f)
                drawCircle(color = Color.White.copy(alpha = 0.06f), radius = 2.2f, center = Offset(x, y))
            }
        }
    }
}

@Composable
fun CompactHomeScreen(padding: PaddingValues) {
    var selectedMode by remember { mutableStateOf(SessionMode.THIRTY) }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        val gap = 10.dp
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(gap)
        ) {
            HeaderSection(modifier = Modifier.weight(1.55f))
            QuickGridSection(modifier = Modifier.weight(1.45f))
            RankCompactSection(modifier = Modifier.weight(0.62f))
            ModeCompactSection(modifier = Modifier.weight(0.74f), selectedMode = selectedMode, onSelect = { selectedMode = it })
            StartGameCompactSection(modifier = Modifier.weight(0.78f), selectedMode = selectedMode)
            TodayCompactSection(modifier = Modifier.weight(0.70f))
        }
    }
}

@Composable
fun HeaderSection(modifier: Modifier = Modifier) {
    PanelCard(modifier) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(40.dp),
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.08f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Settings, contentDescription = null, tint = WhiteMain, modifier = Modifier.size(22.dp))
                    }
                }
                Spacer(modifier = Modifier.weight(1f))
                Text("گیمیفیکیشن", color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 22.sp)
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Gold, Cyan))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ش", color = BgTop, fontWeight = FontWeight.Black, fontSize = 26.sp)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("شهریار", color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 28.sp)
                    Text("جنگجوی رشد | LV.28", color = WhiteSoft, fontSize = 16.sp)
                }
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.Transparent,
                    border = BorderStroke(1.dp, Gold.copy(alpha = 0.35f))
                ) {
                    Box(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.EmojiEvents, contentDescription = null, tint = Gold, modifier = Modifier.size(24.dp))
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("XP ۸۰۰۰ / ۶۲۴۰", color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("پیشرفت سطح", color = WhiteSoft, fontSize = 13.sp)
                }
                ProgressBar(0.78f)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallStatCard(modifier = Modifier.weight(1f), title = "رنک", value = "حماسی III", icon = Icons.Rounded.EmojiEvents, tint = Pink)
                SmallStatCard(modifier = Modifier.weight(1f), title = "الماس", value = "۱۲", icon = Icons.Rounded.AutoAwesome, tint = Cyan)
                SmallStatCard(modifier = Modifier.weight(1f), title = "طلا", value = "۲۴۳۷", icon = Icons.Rounded.ShoppingBag, tint = Gold)
            }
        }
    }
}

@Composable
fun QuickGridSection(modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FeatureCard(Modifier.weight(1f), "فروشگاه", "پاداش واقعی با الماس", Icons.Rounded.ShoppingBag, Gold)
            FeatureCard(Modifier.weight(1f), "رویدادها", "ایونت‌ها و اعضا", Icons.Rounded.Event, Cyan)
        }
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FeatureCard(Modifier.weight(1f), "آینده بینی", "سال‌ها، دارایی‌ها و نتایج", Icons.Rounded.Timeline, Pink)
            FeatureCard(Modifier.weight(1f), "دستاوردها", "روزانه تا بلندمدت", Icons.Rounded.EmojiEvents, Green)
        }
    }
}

@Composable
fun RankCompactSection(modifier: Modifier = Modifier) {
    PanelCard(modifier) {
        Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(
                modifier = Modifier.size(54.dp),
                shape = RoundedCornerShape(18.dp),
                color = Color.White.copy(alpha = 0.05f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Star, contentDescription = null, tint = WhiteMain, modifier = Modifier.size(28.dp))
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("۵۴ / ۱۰۰", color = WhiteMain, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("حماسی III", color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                ProgressBar(0.54f)
            }
        }
    }
}

@Composable
fun ModeCompactSection(modifier: Modifier = Modifier, selectedMode: SessionMode, onSelect: (SessionMode) -> Unit) {
    PanelCard(modifier) {
        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            SessionMode.values().forEach { mode ->
                val selected = mode == selectedMode
                Surface(
                    modifier = Modifier.weight(1f).clickable { onSelect(mode) },
                    shape = RoundedCornerShape(18.dp),
                    color = if (selected) Color(0xFF273A60) else Color.White.copy(alpha = 0.03f),
                    border = BorderStroke(1.dp, if (selected) Cyan.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.07f))
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(mode.title, color = if (selected) Gold else WhiteMain, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        Text(mode.subtitle, color = WhiteSoft, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun StartGameCompactSection(modifier: Modifier = Modifier, selectedMode: SessionMode) {
    PanelCard(modifier) {
        Surface(
            modifier = Modifier.fillMaxSize().clickable { },
            shape = RoundedCornerShape(22.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Cyan.copy(alpha = 0.75f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.horizontalGradient(listOf(Color(0xFF0E2C58), Color(0xFF144C89), Color(0xFF0E2C58)))),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Rounded.VideogameAsset, contentDescription = null, tint = Cyan, modifier = Modifier.size(28.dp))
                        Text("شروع بازی", color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 28.sp)
                    }
                    Text(selectedMode.title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
        }
    }
}

@Composable
fun TodayCompactSection(modifier: Modifier = Modifier) {
    PanelCard(modifier) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("امروز", color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 22.sp)
                Text("خلاصه سریع", color = WhiteSoft, fontSize = 12.sp)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricChip(Modifier.weight(1f), "بازی", "۲", Icons.Rounded.VideogameAsset, Cyan)
                MetricChip(Modifier.weight(1f), "کار", "۸", Icons.Rounded.ChecklistRtl, Gold)
                MetricChip(Modifier.weight(1f), "شبکه سازی", "۵", Icons.Rounded.Groups, Green)
            }
        }
    }
}

@Composable
fun SmallStatCard(modifier: Modifier, title: String, value: String, icon: ImageVector, tint: Color) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.03f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.20f))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
            Text(title, color = WhiteSoft, fontSize = 12.sp)
            Text(value, color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 15.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun FeatureCard(modifier: Modifier, title: String, subtitle: String, icon: ImageVector, tint: Color) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        color = PanelSoft,
        border = BorderStroke(1.dp, tint.copy(alpha = 0.18f))
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = RoundedCornerShape(14.dp),
                color = tint.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text(subtitle, color = WhiteSoft, fontSize = 11.sp, lineHeight = 15.sp)
            }
        }
    }
}

@Composable
fun MetricChip(modifier: Modifier, title: String, value: String, icon: ImageVector, tint: Color) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.03f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.20f))
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(value, color = tint, fontWeight = FontWeight.Black, fontSize = 22.sp)
                Text(title, color = WhiteSoft, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun PanelCard(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(14.dp), content = content)
    }
}

@Composable
fun ProgressBar(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(11.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(Color.White.copy(alpha = 0.09f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress)
                .background(Brush.horizontalGradient(listOf(Cyan, Gold)))
        )
    }
}

@Composable
fun BottomNavigationBar(selectedTab: MainTab, onSelect: (MainTab) -> Unit) {
    val items = listOf(
        Triple(MainTab.NETWORK, Icons.Rounded.Groups, "شبکه سازی"),
        Triple(MainTab.TIMESHEET, Icons.Rounded.Schedule, "تایم شیت"),
        Triple(MainTab.STATS, Icons.Rounded.Insights, "آمار"),
        Triple(MainTab.TASKS, Icons.Rounded.ChecklistRtl, "کارها"),
        Triple(MainTab.HOME, Icons.Rounded.Home, "خانه")
    )

    NavigationBar(containerColor = Color(0xFF0B1323), tonalElevation = 0.dp) {
        items.forEach { (tab, icon, label) ->
            NavigationBarItem(
                selected = selectedTab == tab,
                onClick = { onSelect(tab) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 9.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Gold,
                    selectedTextColor = Gold,
                    indicatorColor = Gold.copy(alpha = 0.12f),
                    unselectedIconColor = WhiteSoft,
                    unselectedTextColor = WhiteSoft
                )
            )
        }
    }
}

@Composable
fun PlaceholderScreen(padding: PaddingValues, title: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        PanelCard(Modifier.fillMaxWidth().height(220.dp)) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(title, color = WhiteMain, fontWeight = FontWeight.Black, fontSize = 30.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(subtitle, color = WhiteSoft, textAlign = TextAlign.Center, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
    }
}
