package com.herolife.app.character

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class C08SkinningContractTest {
    @Test fun humanoidContractStillUsesFourInfluences() {
        assertEquals(4, C06ProductionContract.rig.maxInfluencesPerVertex)
    }

    @Test fun requiredRigContainsCoreBodyBones() {
        val b=HumanoidSkeleton.requiredBones
        assertTrue("Hips" in b)
        assertTrue("Spine" in b)
        assertTrue("Head" in b)
    }
}
