# آپلود به GitHub

اگر Repository خالی است، فایل ZIP را روی گوشی/کامپیوتر Extract کنید و **تمام فایل‌ها و پوشه‌های داخل آن** را در ریشه Repository آپلود کنید.

ساختار درست باید این شکلی دیده شود:
- `.github/workflows/build-apk.yml`
- `app/`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`

بعد به تب Actions بروید و `Build Android APK` را Run کنید.

نکته: GitHub خودش فایل ZIP آپلودشده در Repository را Extract نمی‌کند، مگر اینکه از قبل Workflow مخصوص Unzip در Repository داشته باشید.
