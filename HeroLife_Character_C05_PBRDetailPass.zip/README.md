# HeroLife Character C05 — PBR Detail Pass
Cumulative replacement for C04.

- improved skin response
- separate eye white / iris / pupil
- layered hair highlights
- refined lips and brows
- richer black leather / cloth / metallic gold
- crystal-blue gem details
- 34,652 vertices / 64,944 triangles
- 13 PBR materials
- no companion

Next: C06 — UV/Texture Architecture + Rig preparation.
