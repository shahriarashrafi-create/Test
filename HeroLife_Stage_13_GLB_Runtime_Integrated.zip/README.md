# HeroLife Stage 13 — GLB Runtime Integrated

This is the cumulative replacement ZIP after Stage 12.

## What changed
- GLB loading is now active at runtime.
- Female and male `.glb` files are bundled in `app/src/main/assets/models/`.
- `CharacterRenderer` now renders those GLB assets, not the procedural mesh path.
- Drag horizontally rotates the actual loaded GLB.
- Tap switches female/male.
- Transparent OpenGL composition, lobby HUD separation and fullscreen remain intact.
- Companion remains removed.

## Included GLB files
- `models/female_realistic_01.glb`
- `models/male_realistic_01.glb`

These bundled models are self-contained verification models created for this project so that
the GLB pipeline works immediately after upload.

They are **not claimed to be photoreal production humans**. A truly photoreal hero still requires
a professionally authored/licensed GLB with high-detail mesh, PBR textures, hair, eyes and materials.

## Production upgrade path
When a production model is available, replace the GLB file while keeping its registry path,
or update `CharacterAssetRegistry`.

The UI does not need to move:
Environment / menu / quote / rank / Start / bottom navigation remain separate.

## Loader support in this stage
The built-in loader supports:
- GLB 2.0
- POSITION
- NORMAL
- indexed triangles
- interleaved vertex buffer views
- material `baseColorFactor`
- transparent OpenGL surface

The next renderer upgrade for a photoreal model should add:
- base color textures
- normal maps
- metallic/roughness textures
- skin/hair material handling
- skeletal animation
