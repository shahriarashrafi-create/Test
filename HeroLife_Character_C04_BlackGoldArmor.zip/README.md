# HeroLife Character C04 — Black/Gold Armor
Cumulative replacement for C03.

- black/gold fantasy outfit
- corset/bodice armor
- gloves and thigh-high boots
- skirt / coat-tail silhouette
- metallic gold ornaments
- independent Leather / Cloth / Gold materials
- 26,930 vertices / 50,232 triangles
- no companion

Next: C05 — PBR material/detail pass.
