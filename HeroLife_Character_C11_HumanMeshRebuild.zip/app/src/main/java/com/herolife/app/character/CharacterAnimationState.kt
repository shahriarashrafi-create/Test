package com.herolife.app.character

enum class CharacterAnimationClip {
    IDLE,
    IDLE_BREATHE
}

data class CharacterAnimationState(
    val clip: CharacterAnimationClip = CharacterAnimationClip.IDLE_BREATHE,
    val playing: Boolean = true,
    val speed: Float = 1f,
    val timeSeconds: Float = 0f
) {
    fun tick(deltaSeconds: Float): CharacterAnimationState =
        if (!playing) this else copy(timeSeconds = timeSeconds + deltaSeconds * speed)

    fun reset(): CharacterAnimationState = copy(timeSeconds = 0f)
}
