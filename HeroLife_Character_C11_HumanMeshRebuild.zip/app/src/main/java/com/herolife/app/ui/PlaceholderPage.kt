package com.herolife.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.herolife.app.model.LobbyDestination
import com.herolife.app.ui.theme.HL

@Composable
fun PlaceholderPage(
    destination: LobbyDestination,
    onBack: () -> Unit
) {
    val title = when (destination) {
        LobbyDestination.TASKS -> "کارها"
        LobbyDestination.STATS -> "آمار"
        LobbyDestination.REWARDS -> "جوایز"
        LobbyDestination.MORE -> "بیشتر"
        LobbyDestination.SHOP -> "فروشگاه"
        LobbyDestination.EVENTS -> "رویدادها"
        LobbyDestination.ACHIEVEMENTS -> "دستاوردها"
        LobbyDestination.START -> "شروع بازی"
        LobbyDestination.HOME -> "خانه"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(HL.Void),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth(),
            color = HL.Panel,
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(title, color = HL.GoldBright, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(12.dp))
                Text(
                    "این صفحه در مرحله بعد روی همین معماری تمیز و لایه‌ای ساخته می‌شود.",
                    color = HL.Muted
                )
                Spacer(Modifier.height(18.dp))
                Button(onClick = onBack) {
                    Text("بازگشت")
                }
            }
        }
    }
}
