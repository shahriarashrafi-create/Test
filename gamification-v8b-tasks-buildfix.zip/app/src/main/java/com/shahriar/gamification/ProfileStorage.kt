package com.shahriar.gamification

import android.content.Context

object ProfileStorage {
    private const val PREFS = "profile_preferences"
    private const val KEY_NAME = "name"
    private const val KEY_TITLE = "title"
    private const val KEY_PHOTO_URI = "photo_uri"

    fun load(context: Context): UserProfile {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return UserProfile(
            name = prefs.getString(KEY_NAME, "شهریار") ?: "شهریار",
            title = prefs.getString(KEY_TITLE, "جنگجوی رشد") ?: "جنگجوی رشد",
            photoUri = prefs.getString(KEY_PHOTO_URI, "") ?: ""
        )
    }

    fun save(context: Context, profile: UserProfile) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_NAME, profile.name)
            .putString(KEY_TITLE, profile.title)
            .putString(KEY_PHOTO_URI, profile.photoUri)
            .apply()
    }
}
