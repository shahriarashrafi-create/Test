# HeroLife Stage 06 — Clean Layered Lobby

This is a total rewrite of the lobby architecture.

## The key rule
No screenshots.
No cropped screenshots.
No full-screen mockup used as a background.
No overlapping photo rectangles.

Every visual block is an independent Compose component:
- EnvironmentLayer
- HeroLayer
- CompanionLayer
- TopHud
- SideMenu
- QuotePanel
- RankPanel
- StartButton
- BottomNavigation

This means every element can be resized, moved, animated, replaced or upgraded independently.

## Current character visuals
Hero and companion are intentionally drawn as independent vector-like Compose Canvas layers.
They are placeholders for later transparent character assets or true 3D models.

## Why this is better
The previous stages looked visually strong only because a complete mockup screenshot was being used.
This architecture gives us professional control over the actual app instead of painting a screenshot over it.

## Next
Once the layout is approved, replace only HeroLayer/CompanionLayer with high-quality transparent assets or a 3D renderer while preserving the entire HUD and environment.
