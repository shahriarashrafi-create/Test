package com.herolife.app.character

import kotlin.math.sin

data class BonePose(
    val name: String,
    val rotationX: Float = 0f,
    val rotationY: Float = 0f,
    val rotationZ: Float = 0f,
    val translationY: Float = 0f
)

object HumanoidIdlePose {
    fun evaluate(timeSeconds: Float): List<BonePose> {
        val breath = sin(timeSeconds * 1.65f)
        val sway = sin(timeSeconds * 0.72f)
        return listOf(
            BonePose("Hips", rotationZ = sway * 0.7f),
            BonePose("Spine", rotationX = breath * 0.45f, translationY = breath * 0.0025f),
            BonePose("Chest", rotationX = breath * 0.75f, rotationZ = sway * 0.55f),
            BonePose("UpperChest", rotationX = breath * 0.55f),
            BonePose("Neck", rotationY = sway * 0.5f),
            BonePose("Head", rotationY = sway * 0.65f, rotationZ = sway * 0.20f),
            BonePose("LeftUpperArm", rotationZ = 3.0f + breath * 0.25f),
            BonePose("RightUpperArm", rotationZ = -3.0f - breath * 0.25f)
        )
    }
}
