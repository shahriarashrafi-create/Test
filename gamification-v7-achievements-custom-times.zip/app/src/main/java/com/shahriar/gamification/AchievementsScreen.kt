package com.shahriar.gamification

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val AchPanel = Color(0xF20A1931)
private val AchPanelDeep = Color(0xF2071428)
private val AchGold = Color(0xFFFFC857)
private val AchCyan = Color(0xFF39D7FF)
private val AchGreen = Color(0xFF5BE79D)
private val AchPurple = Color(0xFFBE78FF)
private val AchWhite = Color(0xFFF8FAFF)
private val AchMuted = Color(0xFFAFC0D8)
private val AchRed = Color(0xFFFF8585)

@Composable
fun AchievementsScreen(
    padding: PaddingValues,
    achievements: List<AchievementItem>,
    onBack: () -> Unit,
    onAdd: (AchievementItem) -> Unit,
    onEdit: (AchievementItem) -> Unit,
    onDelete: (AchievementItem) -> Unit
) {
    var category by remember { mutableStateOf(AchievementCategory.DAILY) }
    var editing by remember { mutableStateOf<AchievementItem?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    val filtered = achievements.filter { it.category == category }
    val completed = filtered.count { it.isCompleted }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(44.dp).clickable(onClick = onBack),
                shape = RoundedCornerShape(14.dp),
                color = AchPanel,
                border = BorderStroke(1.dp, AchGold.copy(alpha = 0.30f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.ArrowBack, "بازگشت", tint = AchGold)
                }
            }
            Text(
                "دستاوردها",
                modifier = Modifier.weight(1f),
                color = AchWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )
            Surface(
                modifier = Modifier.size(44.dp).clickable {
                    editing = null
                    showEditor = true
                },
                shape = RoundedCornerShape(14.dp),
                color = AchCyan.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, AchCyan.copy(alpha = 0.35f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Add, "افزودن", tint = AchCyan)
                }
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = AchPanel,
            border = BorderStroke(1.dp, AchGold.copy(alpha = 0.22f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = CircleShape, color = AchGold.copy(alpha = 0.12f)) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.EmojiEvents, null, tint = AchGold, modifier = Modifier.size(28.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("${category.faTitle} • $completed از ${filtered.size} تکمیل", color = AchWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("هر دستاورد می‌تواند XP، طلا و الماس مستقل داشته باشد.", color = AchMuted, fontSize = 10.sp)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CategoryButton(Modifier.weight(1f), AchievementCategory.DAILY, category == AchievementCategory.DAILY) { category = AchievementCategory.DAILY }
            CategoryButton(Modifier.weight(1f), AchievementCategory.WEEKLY, category == AchievementCategory.WEEKLY) { category = AchievementCategory.WEEKLY }
            CategoryButton(Modifier.weight(1f), AchievementCategory.MONTHLY, category == AchievementCategory.MONTHLY) { category = AchievementCategory.MONTHLY }
            CategoryButton(Modifier.weight(1f), AchievementCategory.LONG_TERM, category == AchievementCategory.LONG_TERM) { category = AchievementCategory.LONG_TERM }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(9.dp),
            contentPadding = PaddingValues(bottom = 18.dp)
        ) {
            items(filtered, key = { it.id }) { item ->
                AchievementCard(
                    item = item,
                    onEdit = {
                        editing = item
                        showEditor = true
                    },
                    onDelete = { onDelete(item) }
                )
            }
        }
    }

    if (showEditor) {
        AchievementEditorDialog(
            initial = editing,
            initialCategory = editing?.category ?: category,
            onDismiss = { showEditor = false },
            onSave = { item ->
                if (editing == null) onAdd(item) else onEdit(item)
                category = item.category
                showEditor = false
            }
        )
    }
}

@Composable
private fun CategoryButton(modifier: Modifier, category: AchievementCategory, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(46.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) AchCyan.copy(alpha = 0.15f) else AchPanelDeep,
        border = BorderStroke(1.dp, if (selected) AchCyan.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.06f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(category.faTitle, color = if (selected) AchGold else AchMuted, fontWeight = FontWeight.Bold, fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun AchievementCard(item: AchievementItem, onEdit: () -> Unit, onDelete: () -> Unit) {
    val ratio = (item.progress.toFloat() / item.target.toFloat()).coerceIn(0f, 1f)
    val accent = if (item.isCompleted) AchGreen else AchCyan

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = AchPanel,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = accent.copy(alpha = 0.12f)) {
                    Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
                        Icon(if (item.isCompleted) Icons.Rounded.LockOpen else Icons.Rounded.EmojiEvents, null, tint = accent)
                    }
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, color = AchWhite, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    if (item.description.isNotBlank()) Text(item.description, color = AchMuted, fontSize = 10.sp, maxLines = 2)
                }
                Icon(Icons.Rounded.Edit, "ویرایش", tint = AchGold, modifier = Modifier.size(22.dp).clickable(onClick = onEdit))
                Spacer(Modifier.width(10.dp))
                Icon(Icons.Rounded.Delete, "حذف", tint = AchRed, modifier = Modifier.size(22.dp).clickable(onClick = onDelete))
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${item.progress} / ${item.target}", color = accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Text("${(ratio * 100).roundToInt()}٪", color = AchMuted, fontSize = 10.sp)
            }
            Box(
                Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(999.dp)).background(Color.White.copy(alpha = 0.08f))
            ) {
                Box(
                    Modifier.fillMaxWidth(ratio).fillMaxSize().background(Brush.horizontalGradient(listOf(AchCyan, AchGreen, AchGold)))
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                RewardChip(Modifier.weight(1f), Icons.Rounded.Star, "XP", item.rewardXp, AchGold)
                RewardChip(Modifier.weight(1f), Icons.Rounded.EmojiEvents, "طلا", item.rewardGold, AchPurple)
                RewardChip(Modifier.weight(1f), Icons.Rounded.AutoAwesome, "الماس", item.rewardDiamonds, AchCyan)
            }
        }
    }
}

@Composable
private fun RewardChip(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, amount: Int, color: Color) {
    Surface(modifier = modifier, shape = RoundedCornerShape(13.dp), color = color.copy(alpha = 0.08f), border = BorderStroke(1.dp, color.copy(alpha = 0.18f))) {
        Row(Modifier.padding(horizontal = 7.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = color, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(4.dp))
            Text("$label $amount", color = AchWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun AchievementEditorDialog(
    initial: AchievementItem?,
    initialCategory: AchievementCategory,
    onDismiss: () -> Unit,
    onSave: (AchievementItem) -> Unit
) {
    var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
    var description by remember(initial) { mutableStateOf(initial?.description ?: "") }
    var category by remember(initial) { mutableStateOf(initial?.category ?: initialCategory) }
    var progress by remember(initial) { mutableStateOf((initial?.progress ?: 0).toString()) }
    var target by remember(initial) { mutableStateOf((initial?.target ?: 1).toString()) }
    var xp by remember(initial) { mutableStateOf((initial?.rewardXp ?: 50).toString()) }
    var gold by remember(initial) { mutableStateOf((initial?.rewardGold ?: 20).toString()) }
    var diamonds by remember(initial) { mutableStateOf((initial?.rewardDiamonds ?: 0).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AchPanel,
        title = { Text(if (initial == null) "دستاورد جدید" else "ویرایش دستاورد", color = AchWhite, fontWeight = FontWeight.Black) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    AchievementField(title, { title = it }, "نام دستاورد")
                }
                item {
                    AchievementField(description, { description = it }, "توضیح")
                }
                item {
                    Text("بازه", color = AchMuted, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        CategoryButton(Modifier.weight(1f), AchievementCategory.DAILY, category == AchievementCategory.DAILY) { category = AchievementCategory.DAILY }
                        CategoryButton(Modifier.weight(1f), AchievementCategory.WEEKLY, category == AchievementCategory.WEEKLY) { category = AchievementCategory.WEEKLY }
                        CategoryButton(Modifier.weight(1f), AchievementCategory.MONTHLY, category == AchievementCategory.MONTHLY) { category = AchievementCategory.MONTHLY }
                        CategoryButton(Modifier.weight(1f), AchievementCategory.LONG_TERM, category == AchievementCategory.LONG_TERM) { category = AchievementCategory.LONG_TERM }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AchievementNumberField(Modifier.weight(1f), progress, { progress = it }, "پیشرفت")
                        AchievementNumberField(Modifier.weight(1f), target, { target = it }, "هدف")
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AchievementNumberField(Modifier.weight(1f), xp, { xp = it }, "XP")
                        AchievementNumberField(Modifier.weight(1f), gold, { gold = it }, "طلا")
                        AchievementNumberField(Modifier.weight(1f), diamonds, { diamonds = it }, "الماس")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val targetValue = target.toIntOrNull()?.coerceAtLeast(1) ?: 1
                    val progressValue = progress.toIntOrNull()?.coerceAtLeast(0) ?: 0
                    onSave(
                        AchievementItem(
                            id = initial?.id ?: System.currentTimeMillis(),
                            title = title.trim().ifBlank { "دستاورد جدید" },
                            description = description.trim(),
                            category = category,
                            progress = progressValue,
                            target = targetValue,
                            rewardXp = xp.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                            rewardGold = gold.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                            rewardDiamonds = diamonds.toIntOrNull()?.coerceAtLeast(0) ?: 0
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = AchGold, contentColor = AchPanelDeep)
            ) { Text("ذخیره", fontWeight = FontWeight.Black) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف", color = AchMuted) } }
    )
}

@Composable
private fun AchievementField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        colors = AchievementFieldColors(),
        singleLine = label != "توضیح",
        minLines = if (label == "توضیح") 2 else 1,
        maxLines = if (label == "توضیح") 3 else 1
    )
}

@Composable
private fun AchievementNumberField(modifier: Modifier, value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.filter { ch -> ch.isDigit() }.take(6)) },
        modifier = modifier,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        colors = AchievementFieldColors(),
        singleLine = true
    )
}

@Composable
private fun AchievementFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = AchWhite,
    unfocusedTextColor = AchWhite,
    cursorColor = AchGold,
    focusedBorderColor = AchCyan,
    unfocusedBorderColor = AchMuted.copy(alpha = 0.50f),
    focusedLabelColor = AchCyan,
    unfocusedLabelColor = AchMuted,
    focusedContainerColor = AchPanelDeep,
    unfocusedContainerColor = AchPanelDeep
)
