# C06 — UV / Texture Architecture + Rig Preparation

C06 changes the project from procedural material blocking toward a production character pipeline.

## UV / texture architecture
The final female hero now has defined texture sets for:
- Skin
- Face
- Eyes
- Hair
- Leather
- Cloth
- Gold

The target mobile budget is 2K for major sets and 1K for eyes. Release builds should later use
KTX2/BasisU compression.

## Rig preparation
A stable humanoid naming contract is defined for Root, Hips, spine, chest, neck, head, arms,
hands, legs and feet. The mobile target is four bone influences per vertex and an `Idle`
animation as the first production animation.

## Important limitation
The current C05 procedural GLB remains the visible model in C06. C06 does not pretend that
generated flat colors are photographic skin textures and does not invent a functional skin-weighted
skeleton inside the existing mesh.

This stage prepares the exact asset/runtime contract needed for the next authored model upgrade.

No companion.
