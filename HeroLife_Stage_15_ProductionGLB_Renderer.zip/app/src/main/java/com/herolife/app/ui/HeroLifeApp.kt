package com.herolife.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.*
import com.herolife.app.model.HeroGender
import com.herolife.app.model.LobbyDestination
import com.herolife.app.model.LobbyState

@Composable
fun HeroLifeApp() {
    var state by remember { mutableStateOf(LobbyState()) }

    LobbyScreen(
        state = state,
        onHeroClick = {
            state = state.copy(
                hero = state.hero.copy(
                    gender = if (state.hero.gender == HeroGender.MALE) {
                        HeroGender.FEMALE
                    } else {
                        HeroGender.MALE
                    }
                )
            )
        },
        onNavigate = {
            state = state.copy(destination = it)
        }
    )

    AnimatedVisibility(
        visible = state.destination != LobbyDestination.HOME,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        PlaceholderPage(
            destination = state.destination,
            onBack = {
                state = state.copy(
                    destination = LobbyDestination.HOME
                )
            }
        )
    }
}
