# Production Hero GLB requirements

The lobby is now isolated from the character asset. A production hero can be swapped without
moving HUD, menus, quote, rank card, start button or bottom navigation.

Use professionally authored/licensed GLB 2.0 files at:
- female_realistic_01.glb
- male_realistic_01.glb

Recommended mobile-ready content:
- realistic adult human mesh
- UV coordinates
- BaseColor/Albedo texture
- Normal map
- Metallic/Roughness maps
- separate Skin material
- separate Eye material
- separate Hair material
- Armor/Cloth materials
- optimized polygon count and texture resolution
- optional skeleton + idle/breathing/turn animations

The bundled Stage 14 models remain verification assets. They prove the GLB runtime path but are
not represented as photoreal production humans.
