package com.shahriar.gamification

data class AppSettings(
    val shortGameMinutes: Int = 10,
    val standardGameMinutes: Int = 30,
    val longGameMinutes: Int = 60,
    val defaultGameSlot: Int = 1,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val motivationalEffectsEnabled: Boolean = true,
    val confirmDeleteEnabled: Boolean = true
) {
    fun minutesForSlot(slot: Int): Int {
        return when (slot) {
            0 -> shortGameMinutes
            2 -> longGameMinutes
            else -> standardGameMinutes
        }
    }
}
