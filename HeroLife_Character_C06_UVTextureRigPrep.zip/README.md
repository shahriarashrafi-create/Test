# HeroLife Character C06 — UV / Texture + Rig Prep

Cumulative replacement for C05.

Added:
- production UV/texture-set architecture
- Skin / Face / Eyes / Hair / Leather / Cloth / Gold texture contracts
- 2K mobile texture budget (1K eyes)
- humanoid skeleton naming contract
- max 4 bone influences per vertex
- Idle animation contract
- stable 360° camera profile
- production texture slots
- tests for the character contract
- no companion

The visible C05 character is intentionally retained while the project moves from procedural
materials to the next authored/rigged asset stage.

Next: C07 — Skeleton / Skinning / Idle animation integration.
