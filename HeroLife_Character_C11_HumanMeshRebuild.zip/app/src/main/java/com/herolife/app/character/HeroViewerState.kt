package com.herolife.app.character

import kotlin.math.max
import kotlin.math.min

data class HeroViewerState(
    val selected: ProductionCharacterSpec = ProductionCharacterCatalog.female,
    val yawDegrees: Float = 0f,
    val zoom: Float = 1f,
    val autoRotate: Boolean = false
) {
    fun select(gender: HeroGender): HeroViewerState {
        val next = when (gender) {
            HeroGender.FEMALE -> ProductionCharacterCatalog.female
            HeroGender.MALE -> ProductionCharacterCatalog.male
        }
        return copy(selected = next, yawDegrees = next.defaultYaw, zoom = 1f)
    }

    fun rotateBy(deltaDegrees: Float): HeroViewerState {
        var y = (yawDegrees + deltaDegrees) % 360f
        if (y < -180f) y += 360f
        if (y > 180f) y -= 360f
        return copy(yawDegrees = y)
    }

    fun zoomBy(factor: Float): HeroViewerState {
        val z = max(selected.minZoom, min(selected.maxZoom, zoom * factor))
        return copy(zoom = z)
    }

    fun resetView(): HeroViewerState =
        copy(yawDegrees = selected.defaultYaw, zoom = 1f, autoRotate = false)
}
