package com.herolife.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.app.model.LobbyDestination
import com.herolife.app.model.LobbyState
import com.herolife.app.ui.components.*
import com.herolife.app.ui.theme.HL

@Composable
fun LobbyScreen(
    state: LobbyState,
    onHeroClick: () -> Unit,
    onCompanionClick: () -> Unit,
    onNavigate: (LobbyDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HL.Void)
    ) {
        EnvironmentLayer(
            modifier = Modifier.fillMaxSize()
        )

        HeroLayer(
            selection = state.hero,
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(.62f)
                .fillMaxHeight(.66f),
            onClick = onHeroClick
        )

        CompanionLayer(
            selection = state.companion,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 22.dp, bottom = 250.dp)
                .fillMaxWidth(.34f)
                .fillMaxHeight(.28f),
            onClick = onCompanionClick
        )

        TopHud(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
        )

        SideMenu(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 12.dp),
            onNavigate = onNavigate
        )

        QuotePanel(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 14.dp)
                .fillMaxWidth(.36f)
        )

        BottomHud(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            onNavigate = onNavigate
        )
    }
}
