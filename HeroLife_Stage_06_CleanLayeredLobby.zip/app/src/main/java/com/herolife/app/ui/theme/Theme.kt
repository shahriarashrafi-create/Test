package com.herolife.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object HL {
    val Void = Color(0xFF050B14)
    val Navy = Color(0xFF08162A)
    val Navy2 = Color(0xFF0E233C)
    val Panel = Color(0xEC0A1A2E)
    val Gold = Color(0xFFFFC64A)
    val GoldBright = Color(0xFFFFE7A2)
    val Crystal = Color(0xFF7BD9FF)
    val Text = Color(0xFFF5F7FB)
    val Muted = Color(0xFFA7B5C8)
    val Success = Color(0xFF6CE3A3)
}

@Composable
fun HeroLifeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = HL.Gold,
            secondary = HL.Crystal,
            background = HL.Void,
            surface = HL.Navy,
            onPrimary = HL.Void,
            onBackground = HL.Text,
            onSurface = HL.Text
        ),
        content = content
    )
}
