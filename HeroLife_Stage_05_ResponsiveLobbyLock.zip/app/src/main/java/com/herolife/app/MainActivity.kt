package com.herolife.app

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

private val Night = Color(0xFF06101E)
private val Glass = Color(0xF00A1729)
private val Gold = Color(0xFFFFC84A)
private val GoldSoft = Color(0xFFFFE6A1)
private val Crystal = Color(0xFF8EDBFF)
private val TextSoft = Color(0xFFC5D0E0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        applyImmersive()
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = Gold,
                        secondary = Crystal,
                        background = Night,
                        surface = Glass,
                        onPrimary = Night,
                        onBackground = Color.White,
                        onSurface = Color.White
                    )
                ) {
                    HeroLifeStage05()
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    private fun applyImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(
            WindowInsetsCompat.Type.statusBars() or
                WindowInsetsCompat.Type.navigationBars()
        )
        c.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
}

private enum class Screen {
    HOME, HERO_PICKER, COMPANION_PICKER, SHOP, EVENTS, REWARDS, ACHIEVEMENTS,
    TASKS, STATS, MORE, START
}

private enum class Gender { MALE, FEMALE }

private data class HeroOption(
    val id: Int,
    val title: String,
    val gender: Gender,
    val preview: Int
)

private data class CompanionOption(
    val id: Int,
    val title: String,
    val preview: Int
)

@Composable
private fun HeroLifeStage05() {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("herolife_stage05", android.content.Context.MODE_PRIVATE)
    }

    val heroes = remember {
        listOf(
            HeroOption(1, "شهریار", Gender.MALE, R.drawable.hero_01),
            HeroOption(2, "آریانا", Gender.FEMALE, R.drawable.hero_female_01)
        )
    }

    val companions = remember {
        listOf(
            CompanionOption(1, "شیر سلطنتی", R.drawable.companion_lion_01),
            CompanionOption(2, "ببر سفید", R.drawable.companion_tiger_01),
            CompanionOption(3, "گرگ سایه", R.drawable.companion_wolf_01),
            CompanionOption(4, "پلنگ شب", R.drawable.companion_panther_01)
        )
    }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var heroId by remember { mutableIntStateOf(prefs.getInt("hero", 2)) }
    var companionId by remember { mutableIntStateOf(prefs.getInt("companion", 2)) }

    val hero = heroes.firstOrNull { it.id == heroId } ?: heroes.last()
    val companion = companions.firstOrNull { it.id == companionId } ?: companions[1]

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Night)
    ) {
        if (screen == Screen.HOME) {
            ResponsiveLobby(
                hero = hero,
                companion = companion,
                onHero = { screen = Screen.HERO_PICKER },
                onCompanion = { screen = Screen.COMPANION_PICKER },
                onNavigate = { screen = it }
            )
        }

        AnimatedVisibility(
            visible = screen != Screen.HOME,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            when (screen) {
                Screen.HERO_PICKER -> HeroPicker(
                    heroes = heroes,
                    selectedId = heroId,
                    onSelect = {
                        heroId = it
                        prefs.edit().putInt("hero", it).apply()
                    },
                    onBack = { screen = Screen.HOME }
                )

                Screen.COMPANION_PICKER -> CompanionPicker(
                    companions = companions,
                    selectedId = companionId,
                    onSelect = {
                        companionId = it
                        prefs.edit().putInt("companion", it).apply()
                    },
                    onBack = { screen = Screen.HOME }
                )

                else -> DestinationPage(
                    screen = screen,
                    onBack = { screen = Screen.HOME }
                )
            }
        }
    }
}

@Composable
private fun ResponsiveLobby(
    hero: HeroOption,
    companion: CompanionOption,
    onHero: () -> Unit,
    onCompanion: () -> Unit,
    onNavigate: (Screen) -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val art = if (hero.gender == Gender.FEMALE) {
            R.drawable.lobby_female
        } else {
            R.drawable.lobby_male
        }

        // ONE Home art plate only. No stacked hero/animal photo rectangles.
        Image(
            painter = painterResource(art),
            contentDescription = "HeroLife Lobby",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // All hit targets are percentage-based, so the composition stays aligned
        // across modern 19.5:9 / 20:9 / 21:9 displays.
        PercentHit(0.20f, 0.10f, 0.60f, 0.48f, onHero)
        PercentHit(0.02f, 0.33f, 0.38f, 0.34f, onCompanion)

        PercentHit(0.01f, 0.10f, 0.17f, 0.095f) { onNavigate(Screen.SHOP) }
        PercentHit(0.01f, 0.205f, 0.17f, 0.095f) { onNavigate(Screen.EVENTS) }
        PercentHit(0.01f, 0.31f, 0.17f, 0.095f) { onNavigate(Screen.REWARDS) }
        PercentHit(0.01f, 0.415f, 0.17f, 0.095f) { onNavigate(Screen.ACHIEVEMENTS) }

        PercentHit(0.19f, 0.77f, 0.63f, 0.12f) { onNavigate(Screen.START) }

        PercentHit(0.00f, 0.90f, 0.20f, 0.10f) { onNavigate(Screen.HOME) }
        PercentHit(0.20f, 0.90f, 0.20f, 0.10f) { onNavigate(Screen.TASKS) }
        PercentHit(0.40f, 0.90f, 0.20f, 0.10f) { onNavigate(Screen.STATS) }
        PercentHit(0.60f, 0.90f, 0.20f, 0.10f) { onNavigate(Screen.REWARDS) }
        PercentHit(0.80f, 0.90f, 0.20f, 0.10f) { onNavigate(Screen.MORE) }

        // Small native status badge for the currently stored companion. It does
        // not cover the art or duplicate the companion image.
        Surface(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 118.dp, end = 10.dp)
                .clickable(onClick = onCompanion),
            color = Color(0xB0081628),
            shape = RoundedCornerShape(100.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                Crystal.copy(alpha = .35f)
            )
        ) {
            Text(
                "همراه: ${companion.title}",
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                color = GoldSoft,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.PercentHit(
    x: Float,
    y: Float,
    width: Float,
    height: Float,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .offset(
                x = maxWidth * x,
                y = maxHeight * y
            )
            .width(maxWidth * width)
            .height(maxHeight * height)
            .clickable(onClick = onClick)
    )
}

@Composable
private fun HeroPicker(
    heroes: List<HeroOption>,
    selectedId: Int,
    onSelect: (Int) -> Unit,
    onBack: () -> Unit
) {
    var previewId by remember { mutableIntStateOf(selectedId) }
    val preview = heroes.firstOrNull { it.id == previewId } ?: heroes.first()
    var angle by remember { mutableFloatStateOf(0f) }

    PickerFrame(
        title = "انتخاب قهرمان",
        onBack = onBack
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            heroes.forEach { hero ->
                FilterChip(
                    selected = preview.gender == hero.gender,
                    onClick = {
                        previewId = hero.id
                        angle = 0f
                    },
                    label = {
                        Text(if (hero.gender == Gender.MALE) "مرد" else "زن")
                    },
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        PreviewCard(
            drawable = preview.preview,
            title = preview.title,
            angle = angle,
            onAngleChanged = { angle = it }
        )

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                onSelect(preview.id)
                onBack()
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Gold,
                contentColor = Night
            )
        ) {
            Text("انتخاب این قهرمان", fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun CompanionPicker(
    companions: List<CompanionOption>,
    selectedId: Int,
    onSelect: (Int) -> Unit,
    onBack: () -> Unit
) {
    var previewId by remember { mutableIntStateOf(selectedId) }
    val preview = companions.firstOrNull { it.id == previewId } ?: companions.first()
    var angle by remember { mutableFloatStateOf(0f) }

    PickerFrame(
        title = "انتخاب همراه",
        onBack = onBack
    ) {
        PreviewCard(
            drawable = preview.preview,
            title = preview.title,
            angle = angle,
            onAngleChanged = { angle = it }
        )

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            companions.forEach { item ->
                Image(
                    painter = painterResource(item.preview),
                    contentDescription = item.title,
                    modifier = Modifier
                        .padding(4.dp)
                        .size(60.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(
                            2.dp,
                            if (preview.id == item.id) Gold else Color.Transparent,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            previewId = item.id
                            angle = 0f
                        },
                    contentScale = ContentScale.Crop
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        Button(
            onClick = {
                onSelect(preview.id)
                onBack()
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Gold,
                contentColor = Night
            )
        ) {
            Text("انتخاب این همراه", fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun PreviewCard(
    drawable: Int,
    title: String,
    angle: Float,
    onAngleChanged: (Float) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(510.dp),
        color = Color(0xFF09182A),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Crystal.copy(alpha = .30f)
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(drawable),
                contentDescription = title,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .graphicsLayer {
                        rotationY = angle
                        cameraDistance = 24f * density
                    }
                    .pointerInput(drawable) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onAngleChanged(
                                (angle + dragAmount.x * .24f)
                                    .coerceIn(-38f, 38f)
                            )
                        }
                    },
                contentScale = ContentScale.Crop
            )

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                color = Glass,
                shape = RoundedCornerShape(100.dp)
            ) {
                Text(
                    "$title • برای دیدن زاویه بکش",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    color = GoldSoft,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun PickerFrame(
    title: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Night)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text("‹ بازگشت", color = GoldSoft)
            }
            Spacer(Modifier.width(10.dp))
            Text(
                title,
                color = Color.White,
                fontSize = 25.sp,
                fontWeight = FontWeight.Black
            )
        }
        content()
    }
}

@Composable
private fun DestinationPage(
    screen: Screen,
    onBack: () -> Unit
) {
    val title = when (screen) {
        Screen.SHOP -> "فروشگاه"
        Screen.EVENTS -> "رویدادها"
        Screen.REWARDS -> "جوایز"
        Screen.ACHIEVEMENTS -> "دستاوردها"
        Screen.TASKS -> "کارها"
        Screen.STATS -> "آمار"
        Screen.MORE -> "بیشتر"
        Screen.START -> "شروع بازی"
        else -> "HeroLife"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Night),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .padding(26.dp)
                .fillMaxWidth(),
            color = Glass,
            shape = RoundedCornerShape(26.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                Gold.copy(alpha = .45f)
            )
        ) {
            Column(
                Modifier.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    title,
                    color = GoldSoft,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    if (screen == Screen.START) {
                        "چیدمان Lobby قفل شد. مرحله بعد می‌تواند موتور واقعی بازی را روی همین پروژه اضافه کند."
                    } else {
                        "این مسیر فعال است و در مرحله‌های بعد کامل می‌شود."
                    },
                    color = TextSoft
                )
                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Gold,
                        contentColor = Night
                    )
                ) {
                    Text("بازگشت")
                }
            }
        }
    }
}
