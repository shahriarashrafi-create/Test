# HeroLife Character C01 — Female Base Mesh
Cumulative project based on Stage 18.

Production female GLB is now a custom HeroLife base mesh:
- 9,060 vertices
- 17,040 triangles
- Human-oriented proportions
- Front-facing default
- No companion

Next: C02 — Face Anatomy & Topology.
