package com.shahriar.gamification

enum class AchievementCategory(val faTitle: String) {
    DAILY("روزانه"),
    WEEKLY("هفتگی"),
    MONTHLY("ماهانه"),
    LONG_TERM("بلندمدت")
}

data class AchievementItem(
    val id: Long,
    val title: String,
    val description: String,
    val category: AchievementCategory,
    val progress: Int,
    val target: Int,
    val rewardXp: Int,
    val rewardGold: Int,
    val rewardDiamonds: Int
) {
    val isCompleted: Boolean get() = target > 0 && progress >= target
}
