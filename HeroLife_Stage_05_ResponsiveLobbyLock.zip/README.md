# HeroLife Stage 05 — Responsive Lobby Lock

This cumulative ZIP replaces Stage 04.

## Primary fix
Stage 04 used several cropped picture rectangles at the same time.
Stage 05 does not.

The Home lobby renders exactly ONE cinematic art plate at a time, so hero,
companion, environment, rank, Start button and HUD cannot visually overlap.

## Responsive layout
All interaction zones use percentages of actual screen width/height rather
than fixed positioning. This keeps the lobby aligned on modern tall phones.

## Character system
- Male hero selection
- Female hero selection
- Lion / white tiger / shadow wolf / night panther choices
- selections persist
- separate Hero Picker and Companion Picker
- drag-based perspective preview

## Technical honesty
The picker drag is a 2D perspective preview, not true 360-degree 3D.
A true front/side/back character requires a real 3D mesh renderer.

## Next
After the lobby is visually approved, add real game flow without touching
the locked Home layout.
