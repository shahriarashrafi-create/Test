package com.herolife.app.character

import com.herolife.app.model.HeroGender

data class HeroSelectionState(
    val selectedGender: HeroGender = HeroGender.FEMALE,
    val confirmedGender: HeroGender = HeroGender.FEMALE,
    val selectorVisible: Boolean = false
)

object HeroSelectionController {
    fun open(state: HeroSelectionState): HeroSelectionState =
        state.copy(selectorVisible = true, selectedGender = state.confirmedGender)

    fun preview(state: HeroSelectionState, gender: HeroGender): HeroSelectionState =
        state.copy(selectedGender = gender)

    fun confirm(state: HeroSelectionState): HeroSelectionState =
        state.copy(
            confirmedGender = state.selectedGender,
            selectorVisible = false
        )

    fun cancel(state: HeroSelectionState): HeroSelectionState =
        state.copy(
            selectedGender = state.confirmedGender,
            selectorVisible = false
        )
}
