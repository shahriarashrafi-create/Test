package com.herolife.app.character

import com.herolife.app.model.HeroGender

enum class CharacterAssetFormat { PROCEDURAL, GLB }

data class CharacterAsset(
    val id: String,
    val displayName: String,
    val gender: HeroGender,
    val format: CharacterAssetFormat,
    val assetPath: String? = null,
    val scale: Float = 1f,
    val verticalOffset: Float = 0f,
    val yawOffset: Float = 0f
)

object CharacterAssetRegistry {
    val femaleDefault = CharacterAsset(
        id = "female_glb_01",
        displayName = "آریانا",
        gender = HeroGender.FEMALE,
        format = CharacterAssetFormat.GLB,
        assetPath = "models/female_realistic_01.glb",
        scale = 1f
    )

    val maleDefault = CharacterAsset(
        id = "male_glb_01",
        displayName = "شهریار",
        gender = HeroGender.MALE,
        format = CharacterAssetFormat.GLB,
        assetPath = "models/male_realistic_01.glb",
        scale = 1f
    )

    fun forGender(gender: HeroGender): CharacterAsset =
        if (gender == HeroGender.FEMALE) femaleDefault else maleDefault
}
