package com.shahriar.gamification

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.ShowChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val StatsPanel = Color(0xF20A1931)
private val StatsDeep = Color(0xF2071428)
private val StatsGold = Color(0xFFFFC857)
private val StatsCyan = Color(0xFF39D7FF)
private val StatsGreen = Color(0xFF5BE79D)
private val StatsPurple = Color(0xFFBE78FF)
private val StatsRed = Color(0xFFFF8585)
private val StatsWhite = Color(0xFFF8FAFF)
private val StatsMuted = Color(0xFFAFC0D8)

private data class MemberRow(
    val member: TeamMember,
    val level: Int
)

@Composable
fun TeamStatsScreen(
    padding: PaddingValues,
    members: List<TeamMember>,
    onAdd: (TeamMember) -> Unit,
    onEdit: (TeamMember) -> Unit,
    onDelete: (TeamMember) -> Unit
) {
    var editing by remember {
        mutableStateOf<TeamMember?>(null)
    }
    var presetParentId by remember {
        mutableStateOf<Long?>(null)
    }
    var showEditor by remember {
        mutableStateOf(false)
    }

    val visibleRows = remember(members) {
        buildTeamRows(members)
    }

    val totalSales = members.sumOf {
        it.sales
    }
    val totalTarget = members.sumOf {
        it.targetSales
    }
    val totalActions = members.sumOf {
        it.totalNetworkingActions
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(
                horizontal = 12.dp,
                vertical = 10.dp
            ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "آمار تیم",
                    color = StatsWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 25.sp
                )
                Text(
                    text = "درختواره، فروش و شبکه‌سازی",
                    color = StatsMuted,
                    fontSize = 10.sp
                )
            }

            Surface(
                modifier = Modifier
                    .size(46.dp)
                    .clickable {
                        editing = null
                        presetParentId = null
                        showEditor = true
                    },
                shape = RoundedCornerShape(15.dp),
                color = StatsCyan.copy(alpha = 0.12f),
                border = BorderStroke(
                    1.dp,
                    StatsCyan.copy(alpha = 0.42f)
                )
            ) {
                Box(
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PersonAdd,
                        contentDescription = "افزودن عضو",
                        tint = StatsCyan
                    )
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            SummaryCard(
                modifier = Modifier.weight(1f),
                title = "اعضا",
                value = members.size.toString(),
                icon = Icons.Rounded.Groups,
                accent = StatsCyan
            )
            SummaryCard(
                modifier = Modifier.weight(1f),
                title = "فروش",
                value = formatCompactNumber(totalSales),
                icon = Icons.Rounded.ShowChart,
                accent = StatsGold
            )
            SummaryCard(
                modifier = Modifier.weight(1f),
                title = "اقدامات",
                value = totalActions.toString(),
                icon = Icons.Rounded.Insights,
                accent = StatsGreen
            )
        }

        if (totalTarget > 0L) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = StatsPanel,
                border = BorderStroke(
                    1.dp,
                    StatsPurple.copy(alpha = 0.18f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(
                        horizontal = 13.dp,
                        vertical = 9.dp
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "هدف فروش تیم",
                            color = StatsMuted,
                            fontSize = 9.sp
                        )
                        Text(
                            text = formatNumber(totalTarget),
                            color = StatsWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Text(
                        text = if (totalTarget > 0L) {
                            "${((totalSales.toDouble() / totalTarget.toDouble()) * 100.0).toInt().coerceAtLeast(0)}٪"
                        } else {
                            "۰٪"
                        },
                        color = StatsPurple,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                }
            }
        }

        if (visibleRows.isEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = StatsPanel,
                border = BorderStroke(
                    1.dp,
                    Color.White.copy(alpha = 0.07f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Groups,
                        contentDescription = null,
                        tint = StatsMuted,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )
                    Text(
                        text = "هنوز عضوی ثبت نشده",
                        color = StatsWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(
                    bottom = 18.dp
                )
            ) {
                items(
                    items = visibleRows,
                    key = { row ->
                        row.member.id
                    }
                ) { row ->
                    TeamMemberCard(
                        member = row.member,
                        level = row.level,
                        parentName = members.firstOrNull {
                            it.id == row.member.parentId
                        }?.name,
                        onAddChild = {
                            editing = null
                            presetParentId = row.member.id
                            showEditor = true
                        },
                        onEdit = {
                            editing = row.member
                            presetParentId = row.member.parentId
                            showEditor = true
                        },
                        onDelete = {
                            onDelete(row.member)
                        }
                    )
                }
            }
        }
    }

    if (showEditor) {
        TeamMemberEditorDialog(
            initial = editing,
            availableParents = members.filter {
                it.id != editing?.id
            },
            presetParentId = presetParentId,
            onDismiss = {
                showEditor = false
            },
            onSave = { member ->
                if (editing == null) {
                    onAdd(member)
                } else {
                    onEdit(member)
                }
                showEditor = false
            }
        )
    }
}

@Composable
private fun SummaryCard(
    modifier: Modifier,
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(17.dp),
        color = StatsPanel,
        border = BorderStroke(
            1.dp,
            accent.copy(alpha = 0.20f)
        )
    ) {
        Column(
            modifier = Modifier.padding(
                horizontal = 8.dp,
                vertical = 9.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = value,
                color = StatsWhite,
                fontWeight = FontWeight.Black,
                fontSize = 13.sp,
                maxLines = 1
            )
            Text(
                text = title,
                color = StatsMuted,
                fontSize = 8.sp
            )
        }
    }
}

@Composable
private fun TeamMemberCard(
    member: TeamMember,
    level: Int,
    parentName: String?,
    onAddChild: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val indent = (level.coerceIn(0, 4) * 13).dp
    val goalRatio = if (member.targetSales > 0L) {
        (
            member.sales.toDouble() /
                member.targetSales.toDouble()
        ).coerceIn(0.0, 1.0)
    } else {
        0.0
    }

    Row(
        modifier = Modifier.fillMaxWidth()
    ) {
        Spacer(
            modifier = Modifier.width(indent)
        )

        Surface(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(20.dp),
            color = StatsPanel,
            border = BorderStroke(
                1.dp,
                if (level == 0) {
                    StatsGold.copy(alpha = 0.34f)
                } else {
                    StatsCyan.copy(alpha = 0.18f)
                }
            )
        ) {
            Column(
                modifier = Modifier.padding(13.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (level == 0) {
                            StatsGold.copy(alpha = 0.12f)
                        } else {
                            StatsCyan.copy(alpha = 0.10f)
                        }
                    ) {
                        Box(
                            modifier = Modifier.size(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = member.name
                                    .trim()
                                    .take(1)
                                    .ifBlank { "؟" },
                                color = if (level == 0) {
                                    StatsGold
                                } else {
                                    StatsCyan
                                },
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(
                        modifier = Modifier.width(9.dp)
                    )

                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = member.name,
                            color = StatsWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )

                        Text(
                            text = if (
                                parentName.isNullOrBlank()
                            ) {
                                "ریشه تیم"
                            } else {
                                "زیرمجموعه $parentName"
                            },
                            color = StatsMuted,
                            fontSize = 9.sp
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (
                            member.growthPercent >= 0
                        ) {
                            StatsGreen.copy(alpha = 0.10f)
                        } else {
                            StatsRed.copy(alpha = 0.10f)
                        }
                    ) {
                        Text(
                            text = "${member.growthPercent}٪ رشد",
                            color = if (
                                member.growthPercent >= 0
                            ) {
                                StatsGreen
                            } else {
                                StatsRed
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(
                                horizontal = 8.dp,
                                vertical = 5.dp
                            )
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    StatMiniCard(
                        modifier = Modifier.weight(1f),
                        title = "فروش",
                        value = formatCompactNumber(
                            member.sales
                        ),
                        accent = StatsGold
                    )
                    StatMiniCard(
                        modifier = Modifier.weight(1f),
                        title = "هدف",
                        value = formatCompactNumber(
                            member.targetSales
                        ),
                        accent = StatsPurple
                    )
                    StatMiniCard(
                        modifier = Modifier.weight(1f),
                        title = "اقدام",
                        value = member
                            .totalNetworkingActions
                            .toString(),
                        accent = StatsCyan
                    )
                }

                if (member.targetSales > 0L) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clickable { }
                    ) {
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            shape = RoundedCornerShape(999.dp),
                            color = Color.White.copy(
                                alpha = 0.07f
                            )
                        ) {}

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth(
                                    goalRatio.toFloat()
                                )
                                .fillMaxSize(),
                            shape = RoundedCornerShape(999.dp),
                            color = StatsPurple
                        ) {}
                    }
                }

                Text(
                    text = "ارتباط ${member.connections}  •  پیش‌مشاوره ${member.preConsults}  •  دعوت ${member.invites}  •  معرفی ${member.presentations}  •  فالوآپ ${member.followUps}",
                    color = StatsMuted,
                    fontSize = 8.sp,
                    maxLines = 2
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onAddChild
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = StatsCyan,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(
                            modifier = Modifier.width(3.dp)
                        )
                        Text(
                            text = "زیرمجموعه",
                            color = StatsCyan,
                            fontSize = 9.sp
                        )
                    }

                    TextButton(
                        onClick = onEdit
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = null,
                            tint = StatsGold,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(
                            modifier = Modifier.width(3.dp)
                        )
                        Text(
                            text = "ویرایش",
                            color = StatsGold,
                            fontSize = 9.sp
                        )
                    }

                    TextButton(
                        onClick = onDelete
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Delete,
                            contentDescription = null,
                            tint = StatsRed,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(
                            modifier = Modifier.width(3.dp)
                        )
                        Text(
                            text = "حذف",
                            color = StatsRed,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMiniCard(
    modifier: Modifier,
    title: String,
    value: String,
    accent: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = accent.copy(alpha = 0.07f),
        border = BorderStroke(
            1.dp,
            accent.copy(alpha = 0.15f)
        )
    ) {
        Column(
            modifier = Modifier.padding(
                horizontal = 6.dp,
                vertical = 6.dp
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = StatsWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                maxLines = 1
            )
            Text(
                text = title,
                color = StatsMuted,
                fontSize = 7.sp
            )
        }
    }
}

@Composable
private fun TeamMemberEditorDialog(
    initial: TeamMember?,
    availableParents: List<TeamMember>,
    presetParentId: Long?,
    onDismiss: () -> Unit,
    onSave: (TeamMember) -> Unit
) {
    var name by remember(initial) {
        mutableStateOf(
            initial?.name ?: ""
        )
    }
    var selectedParentId by remember(
        initial,
        presetParentId
    ) {
        mutableStateOf(
            initial?.parentId ?: presetParentId
        )
    }

    var sales by remember(initial) {
        mutableStateOf(
            (initial?.sales ?: 0L).toString()
        )
    }
    var targetSales by remember(initial) {
        mutableStateOf(
            (initial?.targetSales ?: 0L).toString()
        )
    }
    var growth by remember(initial) {
        mutableStateOf(
            (initial?.growthPercent ?: 20).toString()
        )
    }

    var connections by remember(initial) {
        mutableStateOf(
            (initial?.connections ?: 0).toString()
        )
    }
    var preConsults by remember(initial) {
        mutableStateOf(
            (initial?.preConsults ?: 0).toString()
        )
    }
    var invites by remember(initial) {
        mutableStateOf(
            (initial?.invites ?: 0).toString()
        )
    }
    var presentations by remember(initial) {
        mutableStateOf(
            (initial?.presentations ?: 0).toString()
        )
    }
    var followUps by remember(initial) {
        mutableStateOf(
            (initial?.followUps ?: 0).toString()
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StatsPanel,
        title = {
            Text(
                text = if (initial == null) {
                    "عضو جدید"
                } else {
                    "ویرایش عضو"
                },
                color = StatsWhite,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(
                    9.dp
                )
            ) {
                item {
                    StatsTextField(
                        value = name,
                        onValueChange = {
                            name = it
                        },
                        label = "نام"
                    )
                }

                item {
                    Text(
                        text = "بالاسری",
                        color = StatsMuted,
                        fontSize = 10.sp
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(
                                rememberScrollState()
                            ),
                        horizontalArrangement = Arrangement.spacedBy(
                            6.dp
                        )
                    ) {
                        ParentChip(
                            title = "بدون بالاسری",
                            selected = selectedParentId == null,
                            onClick = {
                                selectedParentId = null
                            }
                        )

                        availableParents.forEach { parent ->
                            ParentChip(
                                title = parent.name,
                                selected = selectedParentId ==
                                    parent.id,
                                onClick = {
                                    selectedParentId = parent.id
                                }
                            )
                        }
                    }
                }

                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(
                            7.dp
                        )
                    ) {
                        StatsNumberField(
                            modifier = Modifier.weight(1f),
                            value = sales,
                            onValueChange = {
                                sales = it
                            },
                            label = "فروش"
                        )
                        StatsNumberField(
                            modifier = Modifier.weight(1f),
                            value = targetSales,
                            onValueChange = {
                                targetSales = it
                            },
                            label = "هدف فروش"
                        )
                    }
                }

                item {
                    StatsSignedNumberField(
                        value = growth,
                        onValueChange = {
                            growth = it
                        },
                        label = "درصد رشد"
                    )
                }

                item {
                    Text(
                        text = "آمار شبکه‌سازی",
                        color = StatsWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(
                            6.dp
                        )
                    ) {
                        StatsNumberField(
                            modifier = Modifier.weight(1f),
                            value = connections,
                            onValueChange = {
                                connections = it
                            },
                            label = "ارتباط"
                        )
                        StatsNumberField(
                            modifier = Modifier.weight(1f),
                            value = preConsults,
                            onValueChange = {
                                preConsults = it
                            },
                            label = "پیش‌مشاوره"
                        )
                    }
                }

                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(
                            6.dp
                        )
                    ) {
                        StatsNumberField(
                            modifier = Modifier.weight(1f),
                            value = invites,
                            onValueChange = {
                                invites = it
                            },
                            label = "دعوت"
                        )
                        StatsNumberField(
                            modifier = Modifier.weight(1f),
                            value = presentations,
                            onValueChange = {
                                presentations = it
                            },
                            label = "معرفی"
                        )
                        StatsNumberField(
                            modifier = Modifier.weight(1f),
                            value = followUps,
                            onValueChange = {
                                followUps = it
                            },
                            label = "فالوآپ"
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        TeamMember(
                            id = initial?.id ?:
                                System.currentTimeMillis(),
                            name = name
                                .trim()
                                .ifBlank { "عضو جدید" },
                            parentId = selectedParentId,
                            sales = sales
                                .toLongOrNull()
                                ?.coerceAtLeast(0L)
                                ?: 0L,
                            targetSales = targetSales
                                .toLongOrNull()
                                ?.coerceAtLeast(0L)
                                ?: 0L,
                            growthPercent = growth
                                .toIntOrNull()
                                ?.coerceIn(-100, 1000)
                                ?: 0,
                            connections = connections
                                .toIntOrNull()
                                ?.coerceAtLeast(0)
                                ?: 0,
                            preConsults = preConsults
                                .toIntOrNull()
                                ?.coerceAtLeast(0)
                                ?: 0,
                            invites = invites
                                .toIntOrNull()
                                ?.coerceAtLeast(0)
                                ?: 0,
                            presentations = presentations
                                .toIntOrNull()
                                ?.coerceAtLeast(0)
                                ?: 0,
                            followUps = followUps
                                .toIntOrNull()
                                ?.coerceAtLeast(0)
                                ?: 0
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = StatsGold,
                    contentColor = StatsDeep
                )
            ) {
                Text(
                    text = "ذخیره",
                    fontWeight = FontWeight.Black
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text(
                    text = "انصراف",
                    color = StatsMuted
                )
            }
        }
    )
}

@Composable
private fun ParentChip(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.clickable(
            onClick = onClick
        ),
        shape = RoundedCornerShape(13.dp),
        color = if (selected) {
            StatsCyan.copy(alpha = 0.16f)
        } else {
            StatsDeep
        },
        border = BorderStroke(
            1.dp,
            if (selected) {
                StatsCyan.copy(alpha = 0.58f)
            } else {
                Color.White.copy(alpha = 0.06f)
            }
        )
    ) {
        Text(
            text = title,
            color = if (selected) {
                StatsGold
            } else {
                StatsMuted
            },
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            modifier = Modifier.padding(
                horizontal = 10.dp,
                vertical = 7.dp
            )
        )
    }
}

@Composable
private fun StatsTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text(label)
        },
        singleLine = true,
        colors = StatsFieldColors()
    )
}

@Composable
private fun StatsNumberField(
    modifier: Modifier,
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = {
            onValueChange(
                it.filter { char ->
                    char.isDigit()
                }.take(14)
            )
        },
        modifier = modifier,
        label = {
            Text(label)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number
        ),
        singleLine = true,
        colors = StatsFieldColors()
    )
}

@Composable
private fun StatsSignedNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            val filtered = buildString {
                var index = 0
                while (index < raw.length) {
                    val char = raw[index]
                    if (
                        char.isDigit() ||
                        (
                            char == '-' &&
                            isEmpty()
                        )
                    ) {
                        append(char)
                    }
                    index++
                }
            }.take(5)

            onValueChange(filtered)
        },
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text(label)
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number
        ),
        singleLine = true,
        colors = StatsFieldColors()
    )
}

@Composable
private fun StatsFieldColors() =
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = StatsWhite,
        unfocusedTextColor = StatsWhite,
        cursorColor = StatsGold,
        focusedBorderColor = StatsCyan,
        unfocusedBorderColor = StatsMuted.copy(
            alpha = 0.50f
        ),
        focusedLabelColor = StatsCyan,
        unfocusedLabelColor = StatsMuted,
        focusedContainerColor = StatsDeep,
        unfocusedContainerColor = StatsDeep
    )

private fun buildTeamRows(
    members: List<TeamMember>
): List<MemberRow> {
    if (members.isEmpty()) {
        return emptyList()
    }

    val result = mutableListOf<MemberRow>()
    val memberIds = members.map {
        it.id
    }.toSet()

    val roots = members.filter {
        it.parentId == null ||
            it.parentId !in memberIds
    }

    val visited = mutableSetOf<Long>()

    fun addBranch(
        member: TeamMember,
        level: Int
    ) {
        if (member.id in visited) {
            return
        }

        visited.add(member.id)
        result.add(
            MemberRow(
                member = member,
                level = level
            )
        )

        val children = members.filter {
            it.parentId == member.id
        }

        var index = 0
        while (index < children.size) {
            addBranch(
                member = children[index],
                level = level + 1
            )
            index++
        }
    }

    var rootIndex = 0
    while (rootIndex < roots.size) {
        addBranch(
            member = roots[rootIndex],
            level = 0
        )
        rootIndex++
    }

    var remainingIndex = 0
    while (remainingIndex < members.size) {
        val member = members[remainingIndex]
        if (member.id !in visited) {
            addBranch(
                member = member,
                level = 0
            )
        }
        remainingIndex++
    }

    return result
}

private fun formatNumber(
    value: Long
): String {
    return "%,d".format(value)
}

private fun formatCompactNumber(
    value: Long
): String {
    return when {
        value >= 1_000_000_000L ->
            "${value / 1_000_000_000L}B"
        value >= 1_000_000L ->
            "${value / 1_000_000L}M"
        value >= 1_000L ->
            "${value / 1_000L}K"
        else ->
            value.toString()
    }
}
