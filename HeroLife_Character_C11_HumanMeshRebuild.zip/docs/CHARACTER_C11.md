# C11 — Human Mesh Rebuild

This is a structural rebuild, not another small C10 tweak.

Major changes:
- torso/pelvis rebuilt as continuous ring surfaces
- arms rebuilt as continuous tapered limb meshes
- legs rebuilt as continuous tapered limb meshes
- smoother shoulders and hip transitions
- longer, slimmer female proportions
- face rebuilt with flatter/smaller features
- hair rebuilt as a coherent shell + side sections
- outfit rebuilt as fitted continuous bodice/hip shells
- gloves/boots rebuilt as fitted continuous shells
- gold trim integrated as thin bands instead of floating ornaments
- TEXCOORD_0 UV coordinates are now authored into the custom GLB
- true JOINTS_0 / WEIGHTS_0 skinning preserved
- 10-bone GPU skinning preserved
- 360° rotation preserved
- runtime memory crash fix preserved
- no companion

Stats:
- 10,386 vertices
- 18,472 triangles
- 48 primitives
- 11 materials
