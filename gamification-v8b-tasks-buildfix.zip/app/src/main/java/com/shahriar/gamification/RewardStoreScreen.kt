package com.shahriar.gamification

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val StorePanel = Color(0xF20A1931)
private val StorePanel2 = Color(0xF511223F)
private val StoreDeep = Color(0xFF071427)
private val StoreGold = Color(0xFFFFC857)
private val StoreCyan = Color(0xFF39D7FF)
private val StoreWhite = Color(0xFFF8FAFF)
private val StoreMuted = Color(0xFFAFC0D8)
private val StoreDanger = Color(0xFFFF6B78)

@Composable
fun RewardStoreScreen(
    padding: PaddingValues,
    goldBalance: Int,
    diamondBalance: Int,
    rewards: List<RewardItem>,
    onBack: () -> Unit,
    onBalancesChanged: (gold: Int, diamonds: Int) -> Unit,
    onAddReward: (RewardItem) -> Unit,
    onEditReward: (RewardItem) -> Unit,
    onDeleteReward: (RewardItem) -> Unit
) {
    var selectedCurrency by remember { mutableStateOf(RewardCurrency.DIAMOND) }
    var editingItem by remember { mutableStateOf<RewardItem?>(null) }
    var editorOpen by remember { mutableStateOf(false) }
    var balanceEditorOpen by remember { mutableStateOf(false) }
    var deletingItem by remember { mutableStateOf<RewardItem?>(null) }

    val visibleRewards = rewards.filter { it.currency == selectedCurrency }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StoreHeader(onBack = onBack)

        WalletPanel(
            goldBalance = goldBalance,
            diamondBalance = diamondBalance,
            onEditBalances = { balanceEditorOpen = true }
        )

        CurrencySelector(
            selected = selectedCurrency,
            onSelect = { selectedCurrency = it }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (selectedCurrency == RewardCurrency.DIAMOND) {
                        "پاداش‌های الماسی"
                    } else {
                        "پاداش‌های طلایی"
                    },
                    color = StoreWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
                Text(
                    text = if (selectedCurrency == RewardCurrency.DIAMOND) {
                        "پاداش‌های مالی زندگی"
                    } else {
                        "تفریح‌ها و استراحت‌های کوچک"
                    },
                    color = StoreMuted,
                    fontSize = 10.sp
                )
            }

            Button(
                onClick = {
                    editingItem = null
                    editorOpen = true
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedCurrency == RewardCurrency.DIAMOND) {
                        StoreCyan
                    } else {
                        StoreGold
                    },
                    contentColor = StoreDeep
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(5.dp))
                Text("افزودن", fontWeight = FontWeight.Black)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            if (visibleRewards.isEmpty()) {
                item {
                    EmptyRewards(currency = selectedCurrency)
                }
            } else {
                items(
                    items = visibleRewards,
                    key = { it.id }
                ) { item ->
                    RewardCard(
                        item = item,
                        onEdit = {
                            editingItem = item
                            editorOpen = true
                        },
                        onDelete = {
                            deletingItem = item
                        }
                    )
                }
            }
        }
    }

    if (editorOpen) {
        RewardEditorDialog(
            initialItem = editingItem,
            defaultCurrency = selectedCurrency,
            onDismiss = { editorOpen = false },
            onSave = { item ->
                if (editingItem == null) {
                    onAddReward(item)
                } else {
                    onEditReward(item)
                }
                selectedCurrency = item.currency
                editorOpen = false
            }
        )
    }

    if (balanceEditorOpen) {
        BalanceEditorDialog(
            goldBalance = goldBalance,
            diamondBalance = diamondBalance,
            onDismiss = { balanceEditorOpen = false },
            onSave = { gold, diamonds ->
                onBalancesChanged(gold, diamonds)
                balanceEditorOpen = false
            }
        )
    }

    deletingItem?.let { item ->
        AlertDialog(
            onDismissRequest = { deletingItem = null },
            containerColor = StorePanel,
            title = {
                Text("حذف پاداش", color = StoreWhite, fontWeight = FontWeight.Black)
            },
            text = {
                Text(
                    "«${item.title}» حذف شود؟",
                    color = StoreMuted
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteReward(item)
                        deletingItem = null
                    }
                ) {
                    Text("حذف", color = StoreDanger, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingItem = null }) {
                    Text("انصراف", color = StoreMuted)
                }
            }
        )
    }
}

@Composable
private fun StoreHeader(onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier
                .size(42.dp)
                .clickable(onClick = onBack),
            shape = RoundedCornerShape(14.dp),
            color = StorePanel,
            border = BorderStroke(1.dp, StoreCyan.copy(alpha = 0.22f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Rounded.ArrowBack,
                    contentDescription = "بازگشت",
                    tint = StoreWhite
                )
            }
        }

        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "فروشگاه",
                color = StoreWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp
            )
            Text(
                "پاداش‌های خودت را بساز و مدیریت کن",
                color = StoreMuted,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.width(42.dp))
    }
}

@Composable
private fun WalletPanel(
    goldBalance: Int,
    diamondBalance: Int,
    onEditBalances: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = StorePanel,
        border = BorderStroke(1.dp, StoreGold.copy(alpha = 0.26f))
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            StoreCyan.copy(alpha = 0.055f),
                            Color.Transparent,
                            StoreGold.copy(alpha = 0.055f)
                        )
                    )
                )
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BalanceCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.AutoAwesome,
                    label = "الماس",
                    value = diamondBalance,
                    accent = StoreCyan
                )
                BalanceCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.ShoppingBag,
                    label = "طلا",
                    value = goldBalance,
                    accent = StoreGold
                )
            }

            OutlinedButton(
                onClick = onEditBalances,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, StoreWhite.copy(alpha = 0.14f))
            ) {
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = null,
                    tint = StoreMuted,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("ویرایش موجودی", color = StoreMuted)
            }
        }
    }
}

@Composable
private fun BalanceCard(
    modifier: Modifier,
    icon: ImageVector,
    label: String,
    value: Int,
    accent: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = StoreDeep,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.30f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(accent.copy(alpha = 0.10f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(label, color = StoreMuted, fontSize = 10.sp)
                Text(
                    value.toString(),
                    color = StoreWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
            }
        }
    }
}

@Composable
private fun CurrencySelector(
    selected: RewardCurrency,
    onSelect: (RewardCurrency) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = StorePanel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CurrencyTab(
                modifier = Modifier.weight(1f),
                label = "الماس",
                subtitle = "پاداش مالی",
                icon = Icons.Rounded.AutoAwesome,
                accent = StoreCyan,
                selected = selected == RewardCurrency.DIAMOND,
                onClick = { onSelect(RewardCurrency.DIAMOND) }
            )
            CurrencyTab(
                modifier = Modifier.weight(1f),
                label = "طلا",
                subtitle = "تفریح و استراحت",
                icon = Icons.Rounded.ShoppingBag,
                accent = StoreGold,
                selected = selected == RewardCurrency.GOLD,
                onClick = { onSelect(RewardCurrency.GOLD) }
            )
        }
    }
}

@Composable
private fun CurrencyTab(
    modifier: Modifier,
    label: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) accent.copy(alpha = 0.11f) else Color.Transparent,
        border = BorderStroke(
            if (selected) 1.3.dp else 1.dp,
            if (selected) accent.copy(alpha = 0.65f) else Color.Transparent
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accent)
            Spacer(modifier = Modifier.width(7.dp))
            Column {
                Text(
                    label,
                    color = StoreWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
                Text(subtitle, color = StoreMuted, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun RewardCard(
    item: RewardItem,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val accent = if (item.currency == RewardCurrency.DIAMOND) StoreCyan else StoreGold
    val icon = if (item.currency == RewardCurrency.DIAMOND) {
        Icons.Rounded.AutoAwesome
    } else {
        Icons.Rounded.ShoppingBag
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = StorePanel2,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.24f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = accent.copy(alpha = 0.10f),
                border = BorderStroke(1.dp, accent.copy(alpha = 0.18f))
            ) {
                Box(
                    modifier = Modifier.size(46.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accent)
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    color = StoreWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
                if (item.note.isNotBlank()) {
                    Text(
                        text = item.note,
                        color = StoreMuted,
                        fontSize = 9.sp,
                        maxLines = 2
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${item.cost} ${if (item.currency == RewardCurrency.DIAMOND) "الماس" else "طلا"}",
                    color = accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SmallActionButton(
                    icon = Icons.Rounded.Edit,
                    tint = StoreCyan,
                    description = "ویرایش",
                    onClick = onEdit
                )
                SmallActionButton(
                    icon = Icons.Rounded.Delete,
                    tint = StoreDanger,
                    description = "حذف",
                    onClick = onDelete
                )
            }
        }
    }
}

@Composable
private fun SmallActionButton(
    icon: ImageVector,
    tint: Color,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(36.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = tint.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.18f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = description,
                tint = tint,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun EmptyRewards(currency: RewardCurrency) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = StorePanel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (currency == RewardCurrency.DIAMOND) "💎" else "🪙",
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "هنوز پاداشی تعریف نشده",
                color = StoreWhite,
                fontWeight = FontWeight.Bold
            )
            Text(
                "با دکمه افزودن اولین پاداشت را بساز.",
                color = StoreMuted,
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun RewardEditorDialog(
    initialItem: RewardItem?,
    defaultCurrency: RewardCurrency,
    onDismiss: () -> Unit,
    onSave: (RewardItem) -> Unit
) {
    var title by remember(initialItem) { mutableStateOf(initialItem?.title.orEmpty()) }
    var costText by remember(initialItem) { mutableStateOf(initialItem?.cost?.toString().orEmpty()) }
    var note by remember(initialItem) { mutableStateOf(initialItem?.note.orEmpty()) }
    var currency by remember(initialItem, defaultCurrency) {
        mutableStateOf(initialItem?.currency ?: defaultCurrency)
    }

    val parsedCost = normalizeNumber(costText)
    val canSave = title.isNotBlank() && parsedCost > 0

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StorePanel,
        title = {
            Text(
                if (initialItem == null) "پاداش جدید" else "ویرایش پاداش",
                color = StoreWhite,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CurrencyDialogChoice(
                        modifier = Modifier.weight(1f),
                        text = "الماس",
                        accent = StoreCyan,
                        selected = currency == RewardCurrency.DIAMOND,
                        onClick = { currency = RewardCurrency.DIAMOND }
                    )
                    CurrencyDialogChoice(
                        modifier = Modifier.weight(1f),
                        text = "طلا",
                        accent = StoreGold,
                        selected = currency == RewardCurrency.GOLD,
                        onClick = { currency = RewardCurrency.GOLD }
                    )
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نام پاداش") },
                    singleLine = true,
                    colors = StoreTextFieldColors()
                )

                OutlinedTextField(
                    value = costText,
                    onValueChange = { costText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = {
                        Text(if (currency == RewardCurrency.DIAMOND) "هزینه الماس" else "هزینه طلا")
                    },
                    singleLine = true,
                    colors = StoreTextFieldColors()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("توضیح اختیاری") },
                    minLines = 2,
                    maxLines = 3,
                    colors = StoreTextFieldColors()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = canSave,
                onClick = {
                    onSave(
                        RewardItem(
                            id = initialItem?.id ?: System.currentTimeMillis(),
                            title = title.trim(),
                            cost = parsedCost,
                            note = note.trim(),
                            currency = currency
                        )
                    )
                }
            ) {
                Text("ذخیره", color = if (canSave) StoreCyan else StoreMuted)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف", color = StoreMuted)
            }
        }
    )
}

@Composable
private fun CurrencyDialogChoice(
    modifier: Modifier,
    text: String,
    accent: Color,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) accent.copy(alpha = 0.10f) else StoreDeep,
        border = BorderStroke(
            1.dp,
            if (selected) accent.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.08f)
        )
    ) {
        Text(
            text,
            color = if (selected) accent else StoreMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 9.dp),
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun BalanceEditorDialog(
    goldBalance: Int,
    diamondBalance: Int,
    onDismiss: () -> Unit,
    onSave: (gold: Int, diamonds: Int) -> Unit
) {
    var goldText by remember { mutableStateOf(goldBalance.toString()) }
    var diamondText by remember { mutableStateOf(diamondBalance.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StorePanel,
        title = {
            Text("ویرایش موجودی", color = StoreWhite, fontWeight = FontWeight.Black)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(
                    value = diamondText,
                    onValueChange = { diamondText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("الماس") },
                    singleLine = true,
                    colors = StoreTextFieldColors()
                )
                OutlinedTextField(
                    value = goldText,
                    onValueChange = { goldText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("طلا") },
                    singleLine = true,
                    colors = StoreTextFieldColors()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        normalizeNumber(goldText).coerceAtLeast(0),
                        normalizeNumber(diamondText).coerceAtLeast(0)
                    )
                }
            ) {
                Text("ذخیره", color = StoreCyan, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف", color = StoreMuted)
            }
        }
    )
}

private fun normalizeNumber(value: String): Int {
    val normalized = buildString {
        for (char in value.trim()) {
            append(
                when (char) {
                    '۰', '٠' -> '0'
                    '۱', '١' -> '1'
                    '۲', '٢' -> '2'
                    '۳', '٣' -> '3'
                    '۴', '٤' -> '4'
                    '۵', '٥' -> '5'
                    '۶', '٦' -> '6'
                    '۷', '٧' -> '7'
                    '۸', '٨' -> '8'
                    '۹', '٩' -> '9'
                    else -> char
                }
            )
        }
    }

    return normalized.filter { it.isDigit() }.toIntOrNull() ?: 0
}


@Composable
private fun StoreTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = StoreWhite,
    unfocusedTextColor = StoreWhite,
    cursorColor = StoreGold,
    focusedBorderColor = StoreCyan,
    unfocusedBorderColor = StoreMuted.copy(alpha = 0.55f),
    focusedLabelColor = StoreCyan,
    unfocusedLabelColor = StoreMuted,
    focusedContainerColor = Color(0xFF071428),
    unfocusedContainerColor = Color(0xFF071428)
)
