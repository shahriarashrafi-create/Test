package com.herolife.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.*
import com.herolife.app.model.HeroGender
import com.herolife.app.model.HeroSelection
import com.herolife.app.model.LobbyDestination
import com.herolife.app.model.LobbyState

@Composable
fun HeroLifeApp() {
    var state by remember { mutableStateOf(LobbyState()) }
    var selectorVisible by remember { mutableStateOf(false) }
    var previewGender by remember { mutableStateOf(state.hero.gender) }

    LobbyScreen(
        state = state,
        onHeroClick = {
            previewGender = state.hero.gender
            selectorVisible = true
        },
        onNavigate = {
            state = state.copy(destination = it)
        }
    )

    AnimatedVisibility(
        visible = state.destination != LobbyDestination.HOME,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        PlaceholderPage(
            destination = state.destination,
            onBack = {
                state = state.copy(destination = LobbyDestination.HOME)
            }
        )
    }

    AnimatedVisibility(
        visible = selectorVisible,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        HeroSelectionScreen(
            selectedGender = previewGender,
            onPreview = { previewGender = it },
            onConfirm = {
                state = state.copy(
                    hero = HeroSelection(gender = previewGender)
                )
                selectorVisible = false
            },
            onCancel = {
                previewGender = state.hero.gender
                selectorVisible = false
            }
        )
    }
}
