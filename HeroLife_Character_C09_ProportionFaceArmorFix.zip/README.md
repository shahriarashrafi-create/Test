# HeroLife Character C09 — Proportion / Face / Armor Fix

Cumulative replacement for C08.

Main fixes from the device screenshot:
- female body proportions rebuilt
- narrower shoulders
- longer legs
- smaller hands
- smaller, cleaner facial features
- hair silhouette cleaned up
- black outfit fitted closer to body
- floating gold discs removed/replaced with slim integrated trim
- subtle idle animation
- improved camera framing
- true GPU skinning retained
- no companion

Model stats: 27,150 vertices / 50,656 triangles.

Use this ZIP as the only cumulative ZIP in GitHub.
