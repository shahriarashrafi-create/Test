package com.herolife.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herolife.app.model.HeroGender
import com.herolife.app.model.HeroSelection
import com.herolife.app.ui.components.CharacterRenderer
import com.herolife.app.ui.theme.HL

@Composable
fun HeroSelectionScreen(
    selectedGender: HeroGender,
    onPreview: (HeroGender) -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(HL.Navy, HL.Void)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "‹",
                    color = HL.Text,
                    fontSize = 34.sp,
                    modifier = Modifier.clickable(onClick = onCancel)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "انتخاب قهرمان",
                    color = HL.Text,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HeroGenderTab(
                    label = "زن",
                    selected = selectedGender == HeroGender.FEMALE,
                    modifier = Modifier.weight(1f)
                ) { onPreview(HeroGender.FEMALE) }

                HeroGenderTab(
                    label = "مرد",
                    selected = selectedGender == HeroGender.MALE,
                    modifier = Modifier.weight(1f)
                ) { onPreview(HeroGender.MALE) }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                color = HL.Panel,
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    HL.Gold.copy(alpha = .35f)
                )
            ) {
                Box(Modifier.fillMaxSize()) {
                    CharacterRenderer(
                        selection = HeroSelection(gender = selectedGender),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp, vertical = 20.dp),
                        onClick = {}
                    )

                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 18.dp),
                        color = HL.Void.copy(alpha = .70f),
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Text(
                            text = "برای چرخاندن، روی مدل بکشید  •  360°",
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            color = HL.Muted,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Button(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                onClick = onConfirm,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = HL.Gold,
                    contentColor = HL.Void
                )
            ) {
                Text(
                    text = "تأیید انتخاب",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun HeroGenderTab(
    label: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(48.dp)
            .clickable(onClick = onClick),
        color = if (selected) HL.Gold else HL.Navy2,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (selected) HL.GoldBright else HL.Crystal.copy(alpha = .24f)
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                color = if (selected) HL.Void else HL.Text,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
