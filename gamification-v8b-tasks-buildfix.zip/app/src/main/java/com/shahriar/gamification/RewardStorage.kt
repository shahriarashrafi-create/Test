package com.shahriar.gamification

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object RewardStorage {
    private const val PREFS = "gamification_rewards_v1"
    private const val KEY_GOLD = "gold_balance"
    private const val KEY_DIAMONDS = "diamond_balance"
    private const val KEY_REWARDS = "reward_items"

    fun loadGoldBalance(context: Context): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_GOLD, 2437)
    }

    fun loadDiamondBalance(context: Context): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_DIAMONDS, 12)
    }

    fun saveBalances(context: Context, gold: Int, diamonds: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_GOLD, gold.coerceAtLeast(0))
            .putInt(KEY_DIAMONDS, diamonds.coerceAtLeast(0))
            .apply()
    }

    fun loadRewards(context: Context): List<RewardItem> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_REWARDS, null)
        if (raw.isNullOrBlank()) {
            return defaultRewards()
        }

        return try {
            val array = JSONArray(raw)
            val result = mutableListOf<RewardItem>()
            for (index in 0 until array.length()) {
                val obj = array.getJSONObject(index)
                val currencyName = obj.optString("currency", RewardCurrency.GOLD.name)
                val currency = runCatching { RewardCurrency.valueOf(currencyName) }
                    .getOrDefault(RewardCurrency.GOLD)

                result.add(
                    RewardItem(
                        id = obj.optLong("id", System.currentTimeMillis() + index),
                        title = obj.optString("title", "پاداش"),
                        cost = obj.optInt("cost", 1).coerceAtLeast(1),
                        note = obj.optString("note", ""),
                        currency = currency
                    )
                )
            }
            result
        } catch (_: Exception) {
            defaultRewards()
        }
    }

    fun saveRewards(context: Context, rewards: List<RewardItem>) {
        val array = JSONArray()
        for (item in rewards) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("title", item.title)
            obj.put("cost", item.cost)
            obj.put("note", item.note)
            obj.put("currency", item.currency.name)
            array.put(obj)
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_REWARDS, array.toString())
            .apply()
    }

    private fun defaultRewards(): List<RewardItem> {
        return listOf(
            RewardItem(
                id = 1001L,
                title = "خرید شخصی",
                cost = 120,
                note = "یک پاداش مالی قابل تنظیم",
                currency = RewardCurrency.DIAMOND
            ),
            RewardItem(
                id = 1002L,
                title = "بودجه ویژه",
                cost = 300,
                note = "برای یک هدف مالی بزرگ‌تر",
                currency = RewardCurrency.DIAMOND
            ),
            RewardItem(
                id = 2001L,
                title = "استراحت کوتاه",
                cost = 20,
                note = "۱۵ دقیقه استراحت بدون عذاب وجدان",
                currency = RewardCurrency.GOLD
            ),
            RewardItem(
                id = 2002L,
                title = "تفریح کوتاه",
                cost = 60,
                note = "یک قسمت سریال یا تفریح انتخابی",
                currency = RewardCurrency.GOLD
            )
        )
    }
}
