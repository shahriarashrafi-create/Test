package com.shahriar.gamification

data class TeamMember(
    val id: Long,
    val name: String,
    val parentId: Long?,
    val sales: Long,
    val targetSales: Long,
    val growthPercent: Int,
    val connections: Int,
    val preConsults: Int,
    val invites: Int,
    val presentations: Int,
    val followUps: Int
) {
    val totalNetworkingActions: Int
        get() = connections + preConsults + invites + presentations + followUps
}
