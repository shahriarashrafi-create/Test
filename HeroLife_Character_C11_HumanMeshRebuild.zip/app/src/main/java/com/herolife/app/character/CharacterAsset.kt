package com.herolife.app.character

import com.herolife.app.model.HeroGender

enum class CharacterAssetFormat { GLB }

data class CharacterAsset(
    val id: String,
    val displayName: String,
    val gender: HeroGender,
    val format: CharacterAssetFormat = CharacterAssetFormat.GLB,
    val assetPath: String,
    val scale: Float = 1f,
    val verticalOffset: Float = 0f,
    val yawOffset: Float = 0f
)

object CharacterAssetRegistry {
    val femaleDefault = CharacterAsset(
        id = "female_glb_01",
        displayName = "آریانا",
        gender = HeroGender.FEMALE,
        assetPath = ProductionHeroContract.FEMALE_GLB,
        scale = 1.18f,
        verticalOffset = -0.02f,
        yawOffset = 0f
    )

    val maleDefault = CharacterAsset(
        id = "male_glb_01",
        displayName = "شهریار",
        gender = HeroGender.MALE,
        assetPath = ProductionHeroContract.MALE_GLB,
        scale = 1.16f,
        verticalOffset = -0.02f,
        yawOffset = 0f
    )

    fun forGender(gender: HeroGender): CharacterAsset =
        if (gender == HeroGender.FEMALE) femaleDefault else maleDefault
}
