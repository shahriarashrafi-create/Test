package com.herolife.app.character

data class CharacterCameraProfile(
    val fullBodyTargetHeight: Float = 0.90f,
    val portraitTargetHeight: Float = 1.52f,
    val defaultYawDegrees: Float = 0f,
    val minZoom: Float = 0.82f,
    val maxZoom: Float = 1.32f,
    val orbitSensitivity: Float = 0.32f
)

object FemaleC06Camera {
    val profile = CharacterCameraProfile()
}
