package com.shahriar.gamification

/**
 * Economy defaults. Reward prices and wallet balances are editable in the Store UI.
 * XP remains progression-only.
 */
object EconomyRules {
    const val XP_10_MIN_SESSION = 20
    const val XP_30_MIN_SESSION = 60
    const val XP_60_MIN_SESSION = 130

    // Gold is the common reward currency for small leisure/rest rewards.
    const val GOLD_10_MIN_SESSION = 5
    const val GOLD_30_MIN_SESSION = 15
    const val GOLD_60_MIN_SESSION = 35

    // Diamonds are scarce and are intended for financial real-life rewards.
    const val DIAMOND_DAILY_MILESTONE = 1
    const val DIAMOND_WEEKLY_STREAK = 3
    const val DIAMOND_MAJOR_ACHIEVEMENT = 5
}
