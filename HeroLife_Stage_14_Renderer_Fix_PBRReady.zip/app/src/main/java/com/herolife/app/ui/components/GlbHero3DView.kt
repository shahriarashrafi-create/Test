package com.herolife.app.ui.components

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import com.herolife.app.character.CharacterAssetRegistry
import com.herolife.app.character.GlbLoader
import com.herolife.app.character.GlbModel
import com.herolife.app.model.HeroGender
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer

class GlbHero3DView(
    context: Context,
    gender: HeroGender,
    private val onTap: () -> Unit
) : GLSurfaceView(context) {

    private val renderer3d = GlbHeroRenderer(context, gender)
    private var lastX = 0f
    private var downX = 0f
    private var downY = 0f
    private var dragged = false

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8,8,8,8,16,0)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        setZOrderOnTop(true)
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        setRenderer(renderer3d)
        renderMode = RENDERMODE_CONTINUOUSLY
        preserveEGLContextOnPause = true
    }

    fun setGender(gender: HeroGender) {
        renderer3d.setGender(gender)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX=e.x; downX=e.x; downY=e.y; dragged=false; return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (kotlin.math.abs(e.x-downX)>8 || kotlin.math.abs(e.y-downY)>8) dragged=true
                renderer3d.targetYaw += (e.x-lastX)*.33f
                lastX=e.x
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragged) onTap()
                return true
            }
        }
        return true
    }
}

private class GlbHeroRenderer(
    private val context: Context,
    gender: HeroGender
) : GLSurfaceView.Renderer {

    @Volatile var targetYaw = -7f
    private var yaw = -7f
    private var gender: HeroGender = gender
    private var pendingGender: HeroGender? = gender
    private var program=0
    private val projection=FloatArray(16)
    private val view=FloatArray(16)
    private val model=FloatArray(16)
    private val mv=FloatArray(16)
    private val mvp=FloatArray(16)
    private var meshes: List<GpuPrimitive> = emptyList()

    fun setGender(g: HeroGender) {
        if (g != gender) pendingGender = g
    }

    override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, config: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        program=createProgram(VS,FS)
        loadModel(gender)
    }

    override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, w:Int,h:Int) {
        GLES20.glViewport(0,0,w,h)
        Matrix.perspectiveM(projection,0,31f,w.toFloat()/h.coerceAtLeast(1),.1f,100f)
    }

    override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
        pendingGender?.let {
            gender=it
            loadModel(it)
            pendingGender=null
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        yaw += (targetYaw-yaw)*.11f

        Matrix.setLookAtM(view,0,0f,1.55f,8.2f,0f,1.50f,0f,0f,1f,0f)
        Matrix.setIdentityM(model,0)
        Matrix.rotateM(model,0,yaw,0f,1f,0f)
        Matrix.scaleM(model,0,1.16f,1.16f,1.16f)
        Matrix.multiplyMM(mv,0,view,0,model,0)
        Matrix.multiplyMM(mvp,0,projection,0,mv,0)

        val mvpLoc=GLES20.glGetUniformLocation(program,"uMvp")
        val modelLoc=GLES20.glGetUniformLocation(program,"uModel")
        GLES20.glUniformMatrix4fv(mvpLoc,1,false,mvp,0)
        GLES20.glUniformMatrix4fv(modelLoc,1,false,model,0)

        for (m in meshes) m.draw(program)
    }

    private fun loadModel(g: HeroGender) {
        val asset=CharacterAssetRegistry.forGender(g)
        val path=asset.assetPath ?: return
        val model=GlbLoader(context).load(path)
        meshes=model.primitives.map { GpuPrimitive(it) }
    }

    private fun createProgram(v:String,f:String):Int {
        fun shader(type:Int,src:String):Int {
            val id=GLES20.glCreateShader(type)
            GLES20.glShaderSource(id,src)
            GLES20.glCompileShader(id)
            return id
        }
        val p=GLES20.glCreateProgram()
        GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,v))
        GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,f))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        const val VS = """
            uniform mat4 uMvp;
            uniform mat4 uModel;
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            varying vec3 vNormal;
            void main(){
                vNormal=normalize(mat3(uModel)*aNormal);
                gl_Position=uMvp*vec4(aPosition,1.0);
            }
        """
        const val FS = """
            precision mediump float;
            uniform vec4 uColor;
            varying vec3 vNormal;
            void main(){
                vec3 n=normalize(vNormal);
                vec3 key=normalize(vec3(-0.45,0.85,-0.65));
                vec3 fill=normalize(vec3(0.65,0.25,-0.35));
                float kd=max(dot(n,key),0.0);
                float fd=max(dot(n,fill),0.0);
                float facing=max(dot(n,vec3(0.0,0.0,-1.0)),0.0);
                float rim=pow(1.0-facing,2.5);
                vec3 col=uColor.rgb*(0.58+kd*0.66+fd*0.22);
                col+=vec3(1.0,.72,.34)*kd*.12;
                col+=vec3(.20,.68,1.0)*rim*.20;
                gl_FragColor=vec4(col,uColor.a);
            }
        """
    }
}

private class GpuPrimitive(p: com.herolife.app.character.GlbPrimitive) {
    private val vb: FloatBuffer = ByteBuffer.allocateDirect(p.vertices.size*4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(p.vertices); position(0) }
    private val ib: IntBuffer = ByteBuffer.allocateDirect(p.indices.size*4)
        .order(ByteOrder.nativeOrder()).asIntBuffer().apply { put(p.indices); position(0) }
    private val count=p.indices.size
    private val color=p.color

    fun draw(program:Int) {
        val pos=GLES20.glGetAttribLocation(program,"aPosition")
        val norm=GLES20.glGetAttribLocation(program,"aNormal")
        val colorLoc=GLES20.glGetUniformLocation(program,"uColor")
        GLES20.glUniform4f(colorLoc,color[0],color[1],color[2],color[3])
        vb.position(0)
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,24,vb)
        vb.position(3)
        GLES20.glEnableVertexAttribArray(norm)
        GLES20.glVertexAttribPointer(norm,3,GLES20.GL_FLOAT,false,24,vb)
        ib.position(0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,count,GLES20.GL_UNSIGNED_INT,ib)
        GLES20.glDisableVertexAttribArray(pos)
        GLES20.glDisableVertexAttribArray(norm)
    }
}
