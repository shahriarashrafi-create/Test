# آپلود نسخه ۳ روی GitHub

1. فایل ZIP را Extract کن.
2. تمام محتویات داخل پوشه را در ریشه Repository قرار بده؛ یعنی `app`، `.github`، `build.gradle`، `settings.gradle` و بقیه فایل‌ها مستقیماً در Repository باشند.
3. Commit و Push کن.
4. وارد `Actions` شو و `Build Android APK` را اجرا کن.
5. بعد از سبز شدن Build، از `Artifacts` فایل `shahriar-million-path-v3-apk` را دریافت کن.

اگر Repository از قبل نسخه ۲ را دارد، فایل‌های نسخه ۳ را جایگزین فایل‌های قبلی کن. اطلاعات نسخه ۲ در خود گوشی هنگام ارتقا به نسخه ۳ تا حد ممکن مهاجرت می‌کند.
