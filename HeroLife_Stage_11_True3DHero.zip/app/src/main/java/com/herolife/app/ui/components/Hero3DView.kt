package com.herolife.app.ui.components

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import com.herolife.app.model.HeroGender
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class Hero3DView(
    context: Context,
    gender: HeroGender,
    private val onTap: () -> Unit
) : GLSurfaceView(context) {

    private val heroRenderer = Hero3DRenderer(gender)
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragged = false

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(heroRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
        setZOrderOnTop(false)
    }

    fun setGender(gender: HeroGender) {
        queueEvent { heroRenderer.gender = gender }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastX = event.x
                dragged = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX
                if (kotlin.math.abs(event.x - downX) > 8f ||
                    kotlin.math.abs(event.y - downY) > 8f) {
                    dragged = true
                }
                heroRenderer.targetYaw += dx * 0.35f
                lastX = event.x
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragged) onTap()
                return true
            }
        }
        return true
    }
}

private class Hero3DRenderer(
    @Volatile var gender: HeroGender
) : GLSurfaceView.Renderer {

    @Volatile var targetYaw = -8f
    private var yaw = -8f
    private var program = 0
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val mv = FloatArray(16)
    private val normalMatrix = FloatArray(16)

    private var sphere: Mesh? = null
    private var cylinder: Mesh? = null
    private var cube: Mesh? = null

    override fun onSurfaceCreated(gl: javax.microedition.khronos.opengles.GL10?, config: javax.microedition.khronos.egl.EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        program = createProgram(VERTEX, FRAGMENT)
        sphere = MeshFactory.sphere(24, 16)
        cylinder = MeshFactory.cylinder(20)
        cube = MeshFactory.cube()
    }

    override fun onSurfaceChanged(gl: javax.microedition.khronos.opengles.GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.coerceAtLeast(1).toFloat()
        Matrix.perspectiveM(projection, 0, 35f, ratio, 0.1f, 100f)
    }

    override fun onDrawFrame(gl: javax.microedition.khronos.opengles.GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)

        yaw += (targetYaw - yaw) * 0.12f

        Matrix.setLookAtM(
            view, 0,
            0f, 1.55f, 7.4f,
            0f, 1.45f, 0f,
            0f, 1f, 0f
        )

        // subtle grounded shadow
        drawPart(cylinder!!, 0f, .05f, 0f, 1.15f, .035f, .62f, 0f, yaw, 0f,
            .02f, .03f, .05f, .32f)

        if (gender == HeroGender.FEMALE) drawFemale() else drawMale()
    }

    private fun drawFemale() {
        val skin = floatArrayOf(.78f, .48f, .38f, 1f)
        val dark = floatArrayOf(.035f, .045f, .065f, 1f)
        val armor = floatArrayOf(.075f, .085f, .105f, 1f)
        val gold = floatArrayOf(.92f, .63f, .18f, 1f)
        val hair = floatArrayOf(.12f, .045f, .03f, 1f)
        val crystal = floatArrayOf(.18f, .72f, .92f, 1f)

        // boots / legs
        drawPart(cylinder!!, -.24f, .56f, 0f, .18f, .74f, .18f, 0f, yaw, -2f, dark)
        drawPart(cylinder!!, .24f, .56f, 0f, .18f, .74f, .18f, 0f, yaw, 2f, dark)
        drawPart(cylinder!!, -.24f, 1.13f, 0f, .20f, .48f, .20f, 0f, yaw, 1f, armor)
        drawPart(cylinder!!, .24f, 1.13f, 0f, .20f, .48f, .20f, 0f, yaw, -1f, armor)

        // hips and fitted torso
        drawPart(sphere!!, 0f, 1.48f, 0f, .55f, .34f, .31f, 0f, yaw, 0f, dark)
        drawPart(sphere!!, 0f, 1.87f, 0f, .50f, .58f, .30f, 0f, yaw, 0f, armor)
        drawPart(sphere!!, 0f, 2.15f, .02f, .57f, .34f, .33f, 0f, yaw, 0f, armor)

        // gold corset line / belt
        drawPart(cylinder!!, 0f, 1.58f, 0f, .46f, .035f, .30f, 0f, yaw, 0f, gold)
        drawPart(cylinder!!, 0f, 1.91f, -.30f, .025f, .43f, .025f, 90f, yaw, 0f, gold)
        drawPart(sphere!!, 0f, 1.58f, -.33f, .075f, .075f, .04f, 0f, yaw, 0f, crystal)

        // neck and head
        drawPart(cylinder!!, 0f, 2.43f, 0f, .12f, .15f, .12f, 0f, yaw, 0f, skin)
        drawPart(sphere!!, 0f, 2.68f, 0f, .31f, .38f, .29f, 0f, yaw, 0f, skin)

        // hair volume behind and crown sweep
        drawPart(sphere!!, 0f, 2.72f, .10f, .39f, .44f, .31f, 0f, yaw, 0f, hair)
        drawPart(sphere!!, -.22f, 2.48f, .12f, .20f, .55f, .18f, 7f, yaw, 7f, hair)
        drawPart(sphere!!, .22f, 2.48f, .12f, .20f, .55f, .18f, -7f, yaw, -7f, hair)

        // face brought slightly forward so it remains visible
        drawPart(sphere!!, 0f, 2.66f, -.12f, .27f, .34f, .18f, 0f, yaw, 0f, skin)

        // shoulders
        drawPart(sphere!!, -.50f, 2.16f, 0f, .22f, .18f, .28f, 0f, yaw, -12f, gold)
        drawPart(sphere!!, .50f, 2.16f, 0f, .22f, .18f, .28f, 0f, yaw, 12f, gold)

        // arms
        drawPart(cylinder!!, -.54f, 1.83f, 0f, .13f, .40f, .13f, 0f, yaw, -7f, skin)
        drawPart(cylinder!!, .54f, 1.83f, 0f, .13f, .40f, .13f, 0f, yaw, 7f, skin)
        drawPart(cylinder!!, -.57f, 1.45f, 0f, .14f, .35f, .14f, 0f, yaw, -2f, armor)
        drawPart(cylinder!!, .57f, 1.45f, 0f, .14f, .35f, .14f, 0f, yaw, 2f, armor)

        // cape behind
        drawPart(cube!!, .0f, 1.55f, .27f, .86f, 1.22f, .055f, 0f, yaw, 0f,
            .035f, .025f, .035f, .88f)
    }

    private fun drawMale() {
        val skin = floatArrayOf(.68f, .39f, .29f, 1f)
        val dark = floatArrayOf(.025f, .035f, .052f, 1f)
        val armor = floatArrayOf(.065f, .075f, .095f, 1f)
        val gold = floatArrayOf(.92f, .63f, .18f, 1f)
        val hair = floatArrayOf(.025f, .02f, .018f, 1f)

        drawPart(cylinder!!, -.24f, .58f, 0f, .20f, .78f, .20f, 0f, yaw, -1f, dark)
        drawPart(cylinder!!, .24f, .58f, 0f, .20f, .78f, .20f, 0f, yaw, 1f, dark)
        drawPart(sphere!!, 0f, 1.50f, 0f, .56f, .34f, .33f, 0f, yaw, 0f, dark)
        drawPart(sphere!!, 0f, 1.98f, 0f, .61f, .67f, .34f, 0f, yaw, 0f, armor)
        drawPart(cylinder!!, 0f, 1.58f, 0f, .48f, .04f, .32f, 0f, yaw, 0f, gold)
        drawPart(cylinder!!, 0f, 2.46f, 0f, .13f, .16f, .13f, 0f, yaw, 0f, skin)
        drawPart(sphere!!, 0f, 2.70f, 0f, .32f, .38f, .30f, 0f, yaw, 0f, skin)
        drawPart(sphere!!, 0f, 2.80f, .05f, .35f, .20f, .31f, 0f, yaw, 0f, hair)
        drawPart(sphere!!, -.57f, 2.15f, 0f, .24f, .20f, .30f, 0f, yaw, -10f, gold)
        drawPart(sphere!!, .57f, 2.15f, 0f, .24f, .20f, .30f, 0f, yaw, 10f, gold)
        drawPart(cylinder!!, -.60f, 1.72f, 0f, .15f, .50f, .15f, 0f, yaw, -5f, armor)
        drawPart(cylinder!!, .60f, 1.72f, 0f, .15f, .50f, .15f, 0f, yaw, 5f, armor)
        drawPart(cube!!, 0f, 1.55f, .28f, .92f, 1.25f, .06f, 0f, yaw, 0f,
            .025f, .025f, .035f, .9f)
    }

    private fun drawPart(
        mesh: Mesh,
        tx: Float, ty: Float, tz: Float,
        sx: Float, sy: Float, sz: Float,
        rx: Float, ry: Float, rz: Float,
        color: FloatArray
    ) {
        drawPart(mesh, tx, ty, tz, sx, sy, sz, rx, ry, rz,
            color[0], color[1], color[2], color[3])
    }

    private fun drawPart(
        mesh: Mesh,
        tx: Float, ty: Float, tz: Float,
        sx: Float, sy: Float, sz: Float,
        rx: Float, ry: Float, rz: Float,
        r: Float, g: Float, b: Float, a: Float
    ) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, tx, ty, tz)
        Matrix.rotateM(model, 0, ry, 0f, 1f, 0f)
        Matrix.rotateM(model, 0, rx, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, rz, 0f, 0f, 1f)
        Matrix.scaleM(model, 0, sx, sy, sz)

        Matrix.multiplyMM(mv, 0, view, 0, model, 0)
        Matrix.multiplyMM(mvp, 0, projection, 0, mv, 0)
        System.arraycopy(mv, 0, normalMatrix, 0, 16)

        val mvpLoc = GLES20.glGetUniformLocation(program, "uMvp")
        val modelLoc = GLES20.glGetUniformLocation(program, "uModel")
        val colorLoc = GLES20.glGetUniformLocation(program, "uColor")
        GLES20.glUniformMatrix4fv(mvpLoc, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(modelLoc, 1, false, model, 0)
        GLES20.glUniform4f(colorLoc, r, g, b, a)
        mesh.draw(program)
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        fun shader(type: Int, source: String): Int {
            val id = GLES20.glCreateShader(type)
            GLES20.glShaderSource(id, source)
            GLES20.glCompileShader(id)
            return id
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vertex))
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fragment))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        private const val VERTEX = """
            uniform mat4 uMvp;
            uniform mat4 uModel;
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            varying vec3 vNormal;
            varying vec3 vWorld;
            void main() {
                vec4 world = uModel * vec4(aPosition, 1.0);
                vWorld = world.xyz;
                vNormal = normalize(mat3(uModel) * aNormal);
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """

        private const val FRAGMENT = """
            precision mediump float;
            uniform vec4 uColor;
            varying vec3 vNormal;
            varying vec3 vWorld;
            void main() {
                vec3 n = normalize(vNormal);
                vec3 key = normalize(vec3(-0.35, 0.8, -0.55));
                vec3 rimDir = normalize(vec3(0.7, 0.35, 0.6));
                float diffuse = max(dot(n, key), 0.0);
                float rim = pow(1.0 - max(dot(n, vec3(0.0,0.0,-1.0)), 0.0), 2.2);
                float warm = max(dot(n, rimDir), 0.0) * 0.18;
                vec3 base = uColor.rgb * (0.28 + diffuse * 0.72);
                base += vec3(1.0, 0.67, 0.25) * warm;
                base += vec3(0.18, 0.65, 0.95) * rim * 0.16;
                gl_FragColor = vec4(base, uColor.a);
            }
        """
    }
}

private class Mesh(
    private val vertices: FloatBuffer,
    private val count: Int
) {
    fun draw(program: Int) {
        val stride = 6 * 4
        val pos = GLES20.glGetAttribLocation(program, "aPosition")
        val normal = GLES20.glGetAttribLocation(program, "aNormal")

        vertices.position(0)
        GLES20.glEnableVertexAttribArray(pos)
        GLES20.glVertexAttribPointer(pos, 3, GLES20.GL_FLOAT, false, stride, vertices)

        vertices.position(3)
        GLES20.glEnableVertexAttribArray(normal)
        GLES20.glVertexAttribPointer(normal, 3, GLES20.GL_FLOAT, false, stride, vertices)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count)
        GLES20.glDisableVertexAttribArray(pos)
        GLES20.glDisableVertexAttribArray(normal)
    }
}

private object MeshFactory {
    fun sphere(segments: Int, rings: Int): Mesh {
        val data = ArrayList<Float>()
        fun point(theta: Float, phi: Float): FloatArray {
            val x = sin(phi) * cos(theta)
            val y = cos(phi)
            val z = sin(phi) * sin(theta)
            return floatArrayOf(x, y, z)
        }
        fun add(p: FloatArray) {
            data.add(p[0]); data.add(p[1]); data.add(p[2])
            data.add(p[0]); data.add(p[1]); data.add(p[2])
        }
        for (r in 0 until rings) {
            val p0 = PI.toFloat() * r / rings
            val p1 = PI.toFloat() * (r + 1) / rings
            for (s in 0 until segments) {
                val t0 = (2f * PI.toFloat()) * s / segments
                val t1 = (2f * PI.toFloat()) * (s + 1) / segments
                val a = point(t0, p0); val b = point(t0, p1)
                val c = point(t1, p1); val d = point(t1, p0)
                add(a); add(b); add(c)
                add(a); add(c); add(d)
            }
        }
        return mesh(data)
    }

    fun cylinder(segments: Int): Mesh {
        val data = ArrayList<Float>()
        fun add(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float) {
            data.add(x); data.add(y); data.add(z)
            data.add(nx); data.add(ny); data.add(nz)
        }
        for (i in 0 until segments) {
            val a = 2f * PI.toFloat() * i / segments
            val b = 2f * PI.toFloat() * (i + 1) / segments
            val ax = cos(a); val az = sin(a)
            val bx = cos(b); val bz = sin(b)
            add(ax,-1f,az, ax,0f,az); add(ax,1f,az, ax,0f,az); add(bx,1f,bz, bx,0f,bz)
            add(ax,-1f,az, ax,0f,az); add(bx,1f,bz, bx,0f,bz); add(bx,-1f,bz, bx,0f,bz)
            add(0f,1f,0f, 0f,1f,0f); add(ax,1f,az,0f,1f,0f); add(bx,1f,bz,0f,1f,0f)
            add(0f,-1f,0f,0f,-1f,0f); add(bx,-1f,bz,0f,-1f,0f); add(ax,-1f,az,0f,-1f,0f)
        }
        return mesh(data)
    }

    fun cube(): Mesh {
        val d = arrayListOf<Float>()
        fun face(a: FloatArray,b: FloatArray,c: FloatArray,e: FloatArray,n: FloatArray) {
            fun add(p: FloatArray) {
                d.add(p[0]);d.add(p[1]);d.add(p[2]);d.add(n[0]);d.add(n[1]);d.add(n[2])
            }
            add(a);add(b);add(c);add(a);add(c);add(e)
        }
        val p = { x:Float,y:Float,z:Float -> floatArrayOf(x,y,z) }
        face(p(-1f,-1f,-1f),p(1f,-1f,-1f),p(1f,1f,-1f),p(-1f,1f,-1f),p(0f,0f,-1f))
        face(p(1f,-1f,1f),p(-1f,-1f,1f),p(-1f,1f,1f),p(1f,1f,1f),p(0f,0f,1f))
        face(p(-1f,-1f,1f),p(-1f,-1f,-1f),p(-1f,1f,-1f),p(-1f,1f,1f),p(-1f,0f,0f))
        face(p(1f,-1f,-1f),p(1f,-1f,1f),p(1f,1f,1f),p(1f,1f,-1f),p(1f,0f,0f))
        face(p(-1f,1f,-1f),p(1f,1f,-1f),p(1f,1f,1f),p(-1f,1f,1f),p(0f,1f,0f))
        face(p(-1f,-1f,1f),p(1f,-1f,1f),p(1f,-1f,-1f),p(-1f,-1f,-1f),p(0f,-1f,0f))
        return mesh(d)
    }

    private fun mesh(data: List<Float>): Mesh {
        val buffer = ByteBuffer
            .allocateDirect(data.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        for (v in data) buffer.put(v)
        buffer.position(0)
        return Mesh(buffer, data.size / 6)
    }
}
