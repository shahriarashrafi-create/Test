# HeroLife Character C06.1 — Runtime Crash Fix

Use this ZIP instead of C04/C05/C06.

Important fix:
C04+ introduced many GLB material primitives. The old renderer duplicated the entire character
vertex buffer for every primitive, causing a large native-memory spike on Android shortly after launch.

C06.1 compacts each primitive to only its used vertices and switches to GLES2-safe 16-bit local indices.
It also falls back safely if a production character asset fails to load.

This is cumulative and keeps all C06 work. No companion.
