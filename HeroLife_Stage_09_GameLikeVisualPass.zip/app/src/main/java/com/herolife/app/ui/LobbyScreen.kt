package com.herolife.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.Layout
import com.herolife.app.model.LobbyDestination
import com.herolife.app.model.LobbyState
import com.herolife.app.ui.components.BottomHud
import com.herolife.app.ui.components.EnvironmentLayer
import com.herolife.app.ui.components.HeroLayer
import com.herolife.app.ui.components.QuotePanel
import com.herolife.app.ui.components.SideMenu
import com.herolife.app.ui.components.TopHud
import com.herolife.app.ui.theme.HL

@Composable
fun LobbyScreen(
    state: LobbyState,
    onHeroClick: () -> Unit,
    onNavigate: (LobbyDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HL.Void)
    ) {
        EnvironmentLayer(
            modifier = Modifier.fillMaxSize()
        )

        PhysicalLayer(
            xFraction = .18f,
            yFraction = .10f,
            widthFraction = .64f,
            heightFraction = .64f
        ) {
            HeroLayer(
                selection = state.hero,
                modifier = Modifier.fillMaxSize(),
                onClick = onHeroClick
            )
        }

        PhysicalLayer(
            xFraction = 0f,
            yFraction = 0f,
            widthFraction = 1f,
            heightFraction = .095f
        ) {
            TopHud(
                modifier = Modifier.fillMaxSize()
            )
        }

        PhysicalLayer(
            xFraction = .018f,
            yFraction = .19f,
            widthFraction = .14f,
            heightFraction = .42f
        ) {
            SideMenu(
                modifier = Modifier.fillMaxSize(),
                onNavigate = onNavigate
            )
        }

        PhysicalLayer(
            xFraction = .72f,
            yFraction = .34f,
            widthFraction = .25f,
            heightFraction = .12f
        ) {
            QuotePanel(
                modifier = Modifier.fillMaxSize()
            )
        }

        PhysicalLayer(
            xFraction = 0f,
            yFraction = .68f,
            widthFraction = 1f,
            heightFraction = .32f
        ) {
            BottomHud(
                modifier = Modifier.fillMaxSize(),
                onNavigate = onNavigate
            )
        }
    }
}

@Composable
private fun PhysicalLayer(
    xFraction: Float,
    yFraction: Float,
    widthFraction: Float,
    heightFraction: Float,
    content: @Composable () -> Unit
) {
    Layout(
        content = content,
        modifier = Modifier.fillMaxSize()
    ) { measurables, constraints ->
        val width = (constraints.maxWidth * widthFraction).toInt().coerceAtLeast(1)
        val height = (constraints.maxHeight * heightFraction).toInt().coerceAtLeast(1)
        val placeable = measurables.first().measure(
            constraints.copy(
                minWidth = width,
                maxWidth = width,
                minHeight = height,
                maxHeight = height
            )
        )

        layout(
            width = constraints.maxWidth,
            height = constraints.maxHeight
        ) {
            placeable.place(
                x = (constraints.maxWidth * xFraction).toInt(),
                y = (constraints.maxHeight * yFraction).toInt()
            )
        }
    }
}
