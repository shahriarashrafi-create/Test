# Real Human Production Assets

C12 starts the real-asset pipeline.

Primary production files:
- female/female_real.glb
- male/male_real.glb

The app should prefer these files when present.

The previous procedural character is no longer the primary production asset.
It is retained only as:
- ../female_procedural_fallback.glb

Target authoring pipeline:
1. Sculpt
2. Retopology
3. UV
4. Face/Skin Texturing
5. Hair Cards or Strands
6. Outfit Mesh
7. Rig/Skinning
8. Idle Animation
9. Export GLB
10. Mobile Optimization
