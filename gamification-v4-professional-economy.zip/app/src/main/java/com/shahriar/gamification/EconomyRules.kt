package com.shahriar.gamification

/**
 * Default economy scaffold for future game screens.
 * All values will later be editable from in-app management settings.
 */
object EconomyRules {
    // XP is progression only; it affects Level / Rank and is never spendable.
    const val XP_10_MIN_SESSION = 20
    const val XP_30_MIN_SESSION = 60
    const val XP_60_MIN_SESSION = 130

    // Gold is intentionally common. It is used for small leisure/rest rewards.
    const val GOLD_10_MIN_SESSION = 5
    const val GOLD_30_MIN_SESSION = 15
    const val GOLD_60_MIN_SESSION = 35

    // Diamonds are intentionally scarce because they represent financial real-life rewards.
    const val DIAMOND_DAILY_MILESTONE = 1
    const val DIAMOND_WEEKLY_STREAK = 3
    const val DIAMOND_MAJOR_ACHIEVEMENT = 5

    // Example default prices. These are seeds only and will be editable in the app.
    val leisureGoldPrices = mapOf(
        "استراحت ۱۵ دقیقه‌ای" to 20,
        "چای یا قهوه" to 35,
        "یک قسمت سریال" to 60,
        "بازی یا تفریح کوتاه" to 80,
        "تفریح ویژه" to 180
    )

    val financialDiamondPrices = mapOf(
        "خوراکی موردعلاقه" to 10,
        "خرید کوچک" to 30,
        "رستوران یا کافه" to 60,
        "خرید شخصی" to 120,
        "پاداش مالی بزرگ" to 300
    )
}
