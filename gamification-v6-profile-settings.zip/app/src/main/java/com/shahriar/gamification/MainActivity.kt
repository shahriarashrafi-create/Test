package com.shahriar.gamification

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChecklistRtl
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    GamificationApp()
                }
            }
        }
    }
}

private val Night0 = Color(0xFF030916)
private val Night1 = Color(0xFF07172F)
private val Night2 = Color(0xFF020B16)
private val Panel = Color(0xF20A1931)
private val Panel2 = Color(0xF511223F)
private val Panel3 = Color(0xF2071428)
private val Gold = Color(0xFFFFC857)
private val GoldLight = Color(0xFFFFE5A0)
private val Cyan = Color(0xFF39D7FF)
private val Blue = Color(0xFF1777FF)
private val Green = Color(0xFF5BE79D)
private val Purple = Color(0xFFBE78FF)
private val Pink = Color(0xFFFF71B0)
private val White = Color(0xFFF8FAFF)
private val Muted = Color(0xFFAFC0D8)

private enum class MainTab(val title: String) {
    HOME("خانه"),
    TASKS("کارها"),
    STATS("آمار"),
    TIMESHEET("تایم شیت"),
    NETWORK("شبکه سازی")
}

private enum class GameMode(val title: String, val subtitle: String) {
    TEN("۱۰ دقیقه", "یک کار"),
    THIRTY("۳۰ دقیقه", "استاندارد"),
    SIXTY("۶۰ دقیقه", "تمرکز عمیق")
}

private enum class AppScreen {
    MAIN, STORE, SETTINGS, PROFILE
}

@Composable
private fun GamificationApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(MainTab.HOME) }
    var screen by remember { mutableStateOf(AppScreen.MAIN) }

    var profile by remember {
        mutableStateOf(ProfileStorage.load(context))
    }
    var appSettings by remember {
        mutableStateOf(SettingsStorage.load(context))
    }

    var goldBalance by remember {
        mutableIntStateOf(RewardStorage.loadGoldBalance(context))
    }
    var diamondBalance by remember {
        mutableIntStateOf(RewardStorage.loadDiamondBalance(context))
    }
    val rewards = remember {
        mutableStateListOf<RewardItem>().apply {
            addAll(RewardStorage.loadRewards(context))
        }
    }

    BackHandler(enabled = screen != AppScreen.MAIN) {
        screen = AppScreen.MAIN
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            if (screen == AppScreen.MAIN) {
                ProfessionalBottomBar(
                    selectedTab = selectedTab,
                    onSelect = { selectedTab = it }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize()) {
            PremiumBackground()

            when (screen) {
                AppScreen.STORE -> {
                    RewardStoreScreen(
                        padding = padding,
                        goldBalance = goldBalance,
                        diamondBalance = diamondBalance,
                        rewards = rewards,
                        onBack = { screen = AppScreen.MAIN },
                        onBalancesChanged = { newGold, newDiamonds ->
                            goldBalance = newGold
                            diamondBalance = newDiamonds
                            RewardStorage.saveBalances(
                                context = context,
                                gold = newGold,
                                diamonds = newDiamonds
                            )
                        },
                        onAddReward = { item ->
                            rewards.add(item)
                            RewardStorage.saveRewards(context, rewards)
                        },
                        onEditReward = { item ->
                            val index = rewards.indexOfFirst { it.id == item.id }
                            if (index >= 0) {
                                rewards[index] = item
                                RewardStorage.saveRewards(context, rewards)
                            }
                        },
                        onDeleteReward = { item ->
                            val index = rewards.indexOfFirst { it.id == item.id }
                            if (index >= 0) {
                                rewards.removeAt(index)
                                RewardStorage.saveRewards(context, rewards)
                            }
                        }
                    )
                }

                AppScreen.SETTINGS -> {
                    SettingsScreen(
                        padding = padding,
                        settings = appSettings,
                        onBack = { screen = AppScreen.MAIN },
                        onSettingsChanged = { updated ->
                            appSettings = updated
                            SettingsStorage.save(context, updated)
                        }
                    )
                }

                AppScreen.PROFILE -> {
                    ProfileEditScreen(
                        padding = padding,
                        profile = profile,
                        onBack = { screen = AppScreen.MAIN },
                        onSave = { updated ->
                            profile = updated
                            ProfileStorage.save(context, updated)
                            screen = AppScreen.MAIN
                        }
                    )
                }

                AppScreen.MAIN -> {
                    when (selectedTab) {
                        MainTab.HOME -> PremiumHome(
                            padding = padding,
                            goldBalance = goldBalance,
                            diamondBalance = diamondBalance,
                            profile = profile,
                            defaultGameMinutes = appSettings.defaultGameMinutes,
                            onOpenStore = { screen = AppScreen.STORE },
                            onOpenSettings = { screen = AppScreen.SETTINGS },
                            onEditProfile = { screen = AppScreen.PROFILE }
                        )
                        MainTab.TASKS -> Placeholder(padding, "کارها", "بانک کارهای بازی و ترتیب زمانی در قدم بعدی")
                        MainTab.STATS -> Placeholder(padding, "آمار", "درختواره تیم، فروش و رشد در قدم بعدی")
                        MainTab.TIMESHEET -> Placeholder(padding, "تایم شیت", "برنامه زمانی هفتگی در قدم بعدی")
                        MainTab.NETWORK -> Placeholder(padding, "شبکه سازی", "پراسپکت و اقدامات بعدی در قدم بعدی")
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Night0, Night1, Night2)
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Cyan.copy(alpha = 0.11f),
                radius = size.minDimension * 0.42f,
                center = Offset(size.width * 0.80f, size.height * 0.14f)
            )
            drawCircle(
                color = Purple.copy(alpha = 0.065f),
                radius = size.minDimension * 0.29f,
                center = Offset(size.width * 0.10f, size.height * 0.56f)
            )
            drawCircle(
                color = Gold.copy(alpha = 0.05f),
                radius = size.minDimension * 0.24f,
                center = Offset(size.width * 0.92f, size.height * 0.74f)
            )

            repeat(34) { index ->
                val x = size.width * (((index * 43) % 100) / 100f)
                val y = size.height * (((index * 67) % 82) / 100f)
                drawCircle(
                    color = if (index % 6 == 0) Gold.copy(alpha = 0.38f) else Color.White.copy(alpha = 0.10f),
                    radius = if (index % 6 == 0) 2.1f else 1.25f,
                    center = Offset(x, y)
                )
            }
        }
    }
}

@Composable
private fun PremiumHome(
    padding: PaddingValues,
    goldBalance: Int,
    diamondBalance: Int,
    profile: UserProfile,
    defaultGameMinutes: Int,
    onOpenStore: () -> Unit,
    onOpenSettings: () -> Unit,
    onEditProfile: () -> Unit
) {
    var mode by remember(defaultGameMinutes) {
        mutableStateOf(
            when (defaultGameMinutes) {
                10 -> GameMode.TEN
                60 -> GameMode.SIXTY
                else -> GameMode.THIRTY
            }
        )
    }
    val compact = LocalConfiguration.current.screenHeightDp < 770

    val page = if (compact) 8.dp else 10.dp
    val gap = if (compact) 6.dp else 7.dp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = page, vertical = gap),
        verticalArrangement = Arrangement.spacedBy(gap)
    ) {
        ProfileHeroLessCard(
            compact = compact,
            goldBalance = goldBalance,
            diamondBalance = diamondBalance,
            profile = profile,
            onOpenSettings = onOpenSettings,
            onEditProfile = onEditProfile,
            modifier = Modifier.weight(1.78f)
        )

        FeatureGrid(
            compact = compact,
            onOpenStore = onOpenStore,
            modifier = Modifier.weight(1.60f)
        )

        RankStrip(
            compact = compact,
            modifier = Modifier.weight(0.61f)
        )

        ModeSelector(
            compact = compact,
            selected = mode,
            onSelect = { mode = it },
            modifier = Modifier.weight(0.66f)
        )

        StartMatch(
            compact = compact,
            mode = mode,
            modifier = Modifier.weight(0.95f)
        )

        TodayStrip(
            compact = compact,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@Composable
private fun ProfileHeroLessCard(
    compact: Boolean,
    goldBalance: Int,
    diamondBalance: Int,
    profile: UserProfile,
    onOpenSettings: () -> Unit,
    onEditProfile: () -> Unit,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(if (compact) 21.dp else 24.dp),
        color = Panel,
        border = BorderStroke(1.2.dp, Gold.copy(alpha = 0.40f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF0A1932),
                            Color(0xFF0D2343),
                            Color(0xFF09172E)
                        )
                    )
                )
                .padding(if (compact) 10.dp else 13.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(if (compact) 52.dp else 60.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(GoldLight, Cyan)
                                )
                            )
                            .clickable(onClick = onEditProfile),
                        contentAlignment = Alignment.Center
                    ) {
                        if (profile.photoUri.isNotBlank()) {
                            AsyncImage(
                                model = profile.photoUri,
                                contentDescription = "عکس پروفایل",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Text(
                                text = profile.name.trim().take(1).ifBlank { "ش" },
                                color = Night0,
                                fontWeight = FontWeight.Black,
                                fontSize = if (compact) 25.sp else 29.sp
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(if (compact) 19.dp else 22.dp),
                            shape = CircleShape,
                            color = Gold
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Rounded.Edit,
                                    contentDescription = "ویرایش پروفایل",
                                    tint = Night0,
                                    modifier = Modifier.size(if (compact) 11.dp else 13.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onEditProfile)
                    ) {
                        Text(
                            text = profile.name,
                            color = White,
                            fontWeight = FontWeight.Black,
                            fontSize = if (compact) 21.sp else 25.sp
                        )
                        Text(
                            text = "${profile.title}  |  LV.28",
                            color = Muted,
                            fontSize = if (compact) 9.sp else 11.sp
                        )
                    }

                    Surface(
                        modifier = Modifier.clickable(onClick = onOpenSettings),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF07162A),
                        border = BorderStroke(1.dp, Gold.copy(alpha = 0.30f))
                    ) {
                        Box(
                            modifier = Modifier.size(if (compact) 38.dp else 44.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = "تنظیمات",
                                tint = GoldLight,
                                modifier = Modifier.size(if (compact) 21.dp else 24.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "۶۲۴۰ / ۸۰۰۰ XP",
                        color = Gold,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 9.sp else 11.sp
                    )
                    Text(
                        text = "پیشرفت سطح",
                        color = Muted,
                        fontSize = if (compact) 8.sp else 10.sp
                    )
                }

                PremiumProgress(0.78f, compact)

                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ResourceBox(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.EmojiEvents,
                        label = "رنک",
                        value = "حماسی III",
                        accent = Purple,
                        compact = compact
                    )
                    ResourceBox(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.AutoAwesome,
                        label = "الماس",
                        value = diamondBalance.toString(),
                        accent = Cyan,
                        compact = compact
                    )
                    ResourceBox(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.ShoppingBag,
                        label = "طلا",
                        value = goldBalance.toString(),
                        accent = Gold,
                        compact = compact
                    )
                }


            }
        }
    }
}

@Composable
private fun ResourceBox(
    modifier: Modifier,
    icon: ImageVector,
    label: String,
    value: String,
    accent: Color,
    compact: Boolean
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(if (compact) 14.dp else 17.dp),
        color = Panel3,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.34f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 7.dp else 9.dp,
                vertical = if (compact) 5.dp else 7.dp
            ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(if (compact) 18.dp else 21.dp)
            )
            Column {
                Text(
                    text = label,
                    color = Muted,
                    fontSize = if (compact) 7.sp else 8.sp
                )
                Text(
                    text = value,
                    color = White,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (compact) 10.sp else 12.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun FeatureGrid(
    compact: Boolean,
    onOpenStore: () -> Unit,
    modifier: Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FeatureTile(
                modifier = Modifier.weight(1f),
                title = "فروشگاه",
                subtitle = "مدیریت پاداش‌ها",
                icon = Icons.Rounded.ShoppingBag,
                accent = Gold,
                compact = compact,
                onClick = onOpenStore
            )
            FeatureTile(
                modifier = Modifier.weight(1f),
                title = "رویدادها",
                subtitle = "ایونت‌ها و اعضا",
                icon = Icons.Rounded.Event,
                accent = Cyan,
                compact = compact,
                onClick = { }
            )
        }

        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FeatureTile(
                modifier = Modifier.weight(1f),
                title = "آینده بینی",
                subtitle = "سال‌ها، دارایی‌ها و نتایج",
                icon = Icons.Rounded.Timeline,
                accent = Purple,
                compact = compact,
                onClick = { }
            )
            FeatureTile(
                modifier = Modifier.weight(1f),
                title = "دستاوردها",
                subtitle = "روزانه تا بلندمدت",
                icon = Icons.Rounded.EmojiEvents,
                accent = Green,
                compact = compact,
                onClick = { }
            )
        }
    }
}

@Composable
private fun FeatureTile(
    modifier: Modifier,
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    compact: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(if (compact) 17.dp else 20.dp),
        color = Panel2,
        border = BorderStroke(1.1.dp, accent.copy(alpha = 0.30f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(
                            accent.copy(alpha = 0.055f),
                            Color.Transparent,
                            Color.Transparent
                        )
                    )
                )
                .padding(
                    horizontal = if (compact) 9.dp else 11.dp,
                    vertical = if (compact) 6.dp else 8.dp
                )
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(13.dp),
                    color = accent.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.20f))
                ) {
                    Box(
                        modifier = Modifier.size(if (compact) 36.dp else 42.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(if (compact) 22.dp else 26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = White,
                        fontWeight = FontWeight.Black,
                        fontSize = if (compact) 13.sp else 15.sp
                    )
                    Text(
                        text = subtitle,
                        color = Muted,
                        fontSize = if (compact) 7.sp else 8.sp,
                        maxLines = 1
                    )
                }

                Text(
                    text = "‹",
                    color = GoldLight,
                    fontSize = if (compact) 21.sp else 24.sp
                )
            }
        }
    }
}

@Composable
private fun RankStrip(
    compact: Boolean,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(if (compact) 17.dp else 20.dp),
        color = Panel,
        border = BorderStroke(1.dp, Gold.copy(alpha = 0.36f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = Cyan.copy(alpha = 0.10f),
                border = BorderStroke(1.dp, Cyan.copy(alpha = 0.20f))
            ) {
                Box(
                    modifier = Modifier.size(if (compact) 34.dp else 39.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.EmojiEvents,
                        contentDescription = null,
                        tint = Cyan,
                        modifier = Modifier.size(if (compact) 20.dp else 23.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "حماسی III",
                        color = White,
                        fontWeight = FontWeight.Black,
                        fontSize = if (compact) 12.sp else 14.sp
                    )
                    Text(
                        text = "۵۴ / ۱۰۰",
                        color = Gold,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 9.sp else 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                PremiumProgress(0.54f, compact)
            }
        }
    }
}

@Composable
private fun ModeSelector(
    compact: Boolean,
    selected: GameMode,
    onSelect: (GameMode) -> Unit,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(if (compact) 17.dp else 20.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            ModeButton(
                modifier = Modifier.weight(1f),
                mode = GameMode.SIXTY,
                active = selected == GameMode.SIXTY,
                accent = Gold,
                compact = compact,
                onClick = { onSelect(GameMode.SIXTY) }
            )
            ModeButton(
                modifier = Modifier.weight(1f),
                mode = GameMode.THIRTY,
                active = selected == GameMode.THIRTY,
                accent = Cyan,
                compact = compact,
                onClick = { onSelect(GameMode.THIRTY) }
            )
            ModeButton(
                modifier = Modifier.weight(1f),
                mode = GameMode.TEN,
                active = selected == GameMode.TEN,
                accent = Purple,
                compact = compact,
                onClick = { onSelect(GameMode.TEN) }
            )
        }
    }
}

@Composable
private fun ModeButton(
    modifier: Modifier,
    mode: GameMode,
    active: Boolean,
    accent: Color,
    compact: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(13.dp),
        color = if (active) accent.copy(alpha = 0.12f) else Panel3,
        border = BorderStroke(
            if (active) 1.5.dp else 1.dp,
            if (active) accent.copy(alpha = 0.72f) else Color.White.copy(alpha = 0.06f)
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = mode.title,
                color = if (active) GoldLight else White,
                fontWeight = FontWeight.Black,
                fontSize = if (compact) 10.sp else 12.sp
            )
            Text(
                text = mode.subtitle,
                color = Muted,
                fontSize = if (compact) 6.sp else 7.sp
            )
        }
    }
}

@Composable
private fun StartMatch(
    compact: Boolean,
    mode: GameMode,
    modifier: Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { },
        shape = RoundedCornerShape(if (compact) 20.dp else 24.dp),
        color = Color.Transparent,
        border = BorderStroke(1.8.dp, Cyan.copy(alpha = 0.86f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color(0xFF051A3B),
                            Color(0xFF075AB4),
                            Color(0xFF0B397C),
                            Color(0xFF051A3B)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "⚔",
                    color = White,
                    fontSize = if (compact) 29.sp else 34.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.width(13.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "شروع بازی",
                        color = White,
                        fontWeight = FontWeight.Black,
                        fontSize = if (compact) 24.sp else 29.sp
                    )
                    Text(
                        text = mode.title,
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 10.sp else 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun TodayStrip(
    compact: Boolean,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(if (compact) 16.dp else 19.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text(
                text = "امروز",
                color = White,
                fontWeight = FontWeight.Black,
                fontSize = if (compact) 11.sp else 13.sp
            )
            TodayItem(
                modifier = Modifier.weight(1f),
                value = "۲",
                label = "بازی",
                accent = Cyan,
                compact = compact
            )
            TodayItem(
                modifier = Modifier.weight(1f),
                value = "۸",
                label = "کار",
                accent = Gold,
                compact = compact
            )
            TodayItem(
                modifier = Modifier.weight(1f),
                value = "۵",
                label = "شبکه سازی",
                accent = Green,
                compact = compact
            )
        }
    }
}

@Composable
private fun TodayItem(
    modifier: Modifier,
    value: String,
    label: String,
    accent: Color,
    compact: Boolean
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = value,
            color = accent,
            fontWeight = FontWeight.Black,
            fontSize = if (compact) 11.sp else 13.sp
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = label,
            color = Muted,
            fontSize = if (compact) 7.sp else 8.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun PremiumProgress(
    value: Float,
    compact: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (compact) 6.dp else 8.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(Color.White.copy(alpha = 0.08f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(value)
                .fillMaxHeight()
                .background(
                    Brush.horizontalGradient(
                        listOf(Cyan, Color(0xFF78F0EF), Gold)
                    )
                )
        )
    }
}

@Composable
private fun ProfessionalBottomBar(
    selectedTab: MainTab,
    onSelect: (MainTab) -> Unit
) {
    Surface(
        color = Color(0xFF040A14),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Reverse declaration so HOME appears on the physical right side in RTL layout.
            BottomTab(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.NETWORK,
                label = "شبکه سازی",
                icon = Icons.Rounded.Groups,
                onClick = { onSelect(MainTab.NETWORK) }
            )
            BottomTab(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.TIMESHEET,
                label = "تایم شیت",
                icon = Icons.Rounded.Schedule,
                onClick = { onSelect(MainTab.TIMESHEET) }
            )
            BottomTab(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.STATS,
                label = "آمار",
                icon = Icons.Rounded.Insights,
                onClick = { onSelect(MainTab.STATS) }
            )
            BottomTab(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.TASKS,
                label = "کارها",
                icon = Icons.Rounded.ChecklistRtl,
                onClick = { onSelect(MainTab.TASKS) }
            )
            BottomTab(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.HOME,
                label = "خانه",
                icon = Icons.Rounded.Home,
                onClick = { onSelect(MainTab.HOME) }
            )
        }
    }
}

@Composable
private fun BottomTab(
    modifier: Modifier,
    selected: Boolean,
    label: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val color = if (selected) Gold else Muted

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        color = if (selected) Gold.copy(alpha = 0.11f) else Color.Transparent,
        border = if (selected) BorderStroke(1.dp, Gold.copy(alpha = 0.24f)) else null
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = label,
                color = color,
                fontSize = 8.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Placeholder(
    padding: PaddingValues,
    title: String,
    subtitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Panel,
            border = BorderStroke(1.dp, Gold.copy(alpha = 0.22f))
        ) {
            Column(
                modifier = Modifier.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = title,
                    color = White,
                    fontWeight = FontWeight.Black,
                    fontSize = 27.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = subtitle,
                    color = Muted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
