# C08 — True Skinning Integration

This is the first HeroLife character stage with genuine vertex skinning data in the production GLB.

Implemented:
- `JOINTS_0`
- `WEIGHTS_0`
- 10-bone skin
- maximum 4 influences per vertex
- compact per-primitive skinned vertex buffers
- OpenGL ES 2 GPU vertex-shader skinning
- breathing / torso / head / arm idle motion now deforms weighted vertices instead of moving the entire model as one rigid object
- C06.1 memory fix retained
- 360-degree drag retained
- no companion

Female production GLB:
- vertices carrying skin weights: 34,652
- skeleton joints: 10
- GLB size: 2270.5 KB

The current custom character is still a procedural art asset, so this stage improves animation technology,
not photographic skin quality. Future character stages can refine texture/geometry without replacing the
skinning runtime.
