package com.shahriar.gamification

import android.content.Context

object SettingsStorage {
    private const val PREFS = "app_settings"
    private const val KEY_SHORT = "short_game_minutes"
    private const val KEY_STANDARD = "standard_game_minutes"
    private const val KEY_LONG = "long_game_minutes"
    private const val KEY_DEFAULT_SLOT = "default_game_slot"
    private const val KEY_OLD_DEFAULT = "default_game_minutes"
    private const val KEY_SOUND = "sound_enabled"
    private const val KEY_VIBRATION = "vibration_enabled"
    private const val KEY_EFFECTS = "motivational_effects_enabled"
    private const val KEY_CONFIRM_DELETE = "confirm_delete_enabled"

    fun load(context: Context): AppSettings {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val shortMinutes = prefs.getInt(KEY_SHORT, 10).coerceIn(1, 240)
        val standardMinutes = prefs.getInt(KEY_STANDARD, 30).coerceIn(1, 240)
        val longMinutes = prefs.getInt(KEY_LONG, 60).coerceIn(1, 240)

        val defaultSlot = if (prefs.contains(KEY_DEFAULT_SLOT)) {
            prefs.getInt(KEY_DEFAULT_SLOT, 1).coerceIn(0, 2)
        } else {
            val oldDefault = prefs.getInt(KEY_OLD_DEFAULT, 30)
            when (oldDefault) {
                shortMinutes -> 0
                longMinutes -> 2
                else -> 1
            }
        }

        return AppSettings(
            shortGameMinutes = shortMinutes,
            standardGameMinutes = standardMinutes,
            longGameMinutes = longMinutes,
            defaultGameSlot = defaultSlot,
            soundEnabled = prefs.getBoolean(KEY_SOUND, true),
            vibrationEnabled = prefs.getBoolean(KEY_VIBRATION, true),
            motivationalEffectsEnabled = prefs.getBoolean(KEY_EFFECTS, true),
            confirmDeleteEnabled = prefs.getBoolean(KEY_CONFIRM_DELETE, true)
        )
    }

    fun save(context: Context, settings: AppSettings) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_SHORT, settings.shortGameMinutes.coerceIn(1, 240))
            .putInt(KEY_STANDARD, settings.standardGameMinutes.coerceIn(1, 240))
            .putInt(KEY_LONG, settings.longGameMinutes.coerceIn(1, 240))
            .putInt(KEY_DEFAULT_SLOT, settings.defaultGameSlot.coerceIn(0, 2))
            .putBoolean(KEY_SOUND, settings.soundEnabled)
            .putBoolean(KEY_VIBRATION, settings.vibrationEnabled)
            .putBoolean(KEY_EFFECTS, settings.motivationalEffectsEnabled)
            .putBoolean(KEY_CONFIRM_DELETE, settings.confirmDeleteEnabled)
            .apply()
    }
}
