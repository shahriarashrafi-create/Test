package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.herolife.app.ui.theme.HL

@Composable
fun EnvironmentLayer(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color(0xFF233A56),
                    Color(0xFF101D31),
                    HL.Void
                )
            )
        )

        drawCircle(
            color = Color(0xFFFFD890).copy(alpha = .16f),
            radius = size.width * .38f,
            center = Offset(size.width * .70f, size.height * .19f)
        )

        val mountains = Path().apply {
            moveTo(0f, size.height * .48f)
            lineTo(size.width * .14f, size.height * .30f)
            lineTo(size.width * .26f, size.height * .48f)
            lineTo(size.width * .39f, size.height * .26f)
            lineTo(size.width * .53f, size.height * .49f)
            lineTo(size.width * .68f, size.height * .23f)
            lineTo(size.width * .82f, size.height * .47f)
            lineTo(size.width, size.height * .32f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(mountains, Color(0xFF1A3048))

        repeat(7) { i ->
            val x = size.width * (.55f + i * .065f)
            val towerH = size.height * (.13f + (i % 3) * .035f)
            drawRect(
                color = Color(0xFF2A435C),
                topLeft = Offset(x, size.height * .44f - towerH),
                size = Size(size.width * .035f, towerH)
            )
        }

        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Transparent, HL.Void.copy(alpha = .80f))
            ),
            topLeft = Offset(0f, size.height * .55f),
            size = Size(size.width, size.height * .45f)
        )
    }
}
