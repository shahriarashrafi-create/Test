package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.herolife.app.model.CompanionSelection
import com.herolife.app.model.CompanionType
import com.herolife.app.ui.theme.HL

@Composable
fun CompanionLayer(
    selection: CompanionSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Canvas(
        modifier = modifier.clickable(onClick = onClick)
    ) {
        val cx = size.width * .50f
        val cy = size.height * .52f

        val body = when (selection.type) {
            CompanionType.LION -> Color(0xFF8A6848)
            CompanionType.TIGER -> Color(0xFFE8E2D6)
            CompanionType.WOLF -> Color(0xFF7A8793)
            CompanionType.PANTHER -> Color(0xFF14181E)
        }

        drawCircle(
            color = body.copy(alpha = .35f),
            radius = size.width * .36f,
            center = Offset(cx, cy)
        )

        drawCircle(
            color = body,
            radius = size.width * .23f,
            center = Offset(cx, cy)
        )

        drawCircle(
            color = HL.Crystal,
            radius = size.width * .022f,
            center = Offset(cx - size.width * .07f, cy - size.height * .025f)
        )
        drawCircle(
            color = HL.Crystal,
            radius = size.width * .022f,
            center = Offset(cx + size.width * .07f, cy - size.height * .025f)
        )

        drawCircle(
            color = HL.Gold,
            radius = size.width * .035f,
            center = Offset(cx, cy + size.height * .12f)
        )
    }
}
