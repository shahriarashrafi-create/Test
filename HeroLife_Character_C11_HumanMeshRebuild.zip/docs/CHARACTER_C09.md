# C09 — Proportion / Face / Armor Fix

This stage was rebuilt from the C08 device screenshot.

Visible issues fixed:
- body was too boxy and mannequin-like
- shoulders were too wide
- hands were oversized
- legs were too short/thick
- facial parts looked detached/bulbous
- nose, cheeks and lips were too large
- hair side sections looked like separate tubes
- gold armor ornaments looked like floating discs
- belt/arm/boot trims protruded too far
- outfit did not follow the body closely
- idle sway was too strong for a lobby pose
- camera framing made the hero look shorter/heavier than intended

C09 rebuild:
- narrower shoulders and waist
- longer leg proportions
- smaller hands
- smaller facial features
- cleaner jaw/chin
- more coherent long-hair silhouette
- fitted black armor and cloth
- slim integrated gold trims instead of floating ornaments
- subtler idle animation
- safer camera framing
- true C08 skinning preserved
- no companion

Stats:
- 27,150 vertices
- 50,656 triangles
- 82 material primitives
- 10-bone skin
