# HeroLife — Stage 02: Cinematic Home

This is a full cumulative replacement for Stage 01.

## Goal
Lock the visual direction before adding the deeper game systems.

## Stage 02 changes
- full-screen cinematic home art based on the approved visual direction
- exact high-density game-lobby composition instead of primitive Canvas character art
- edge-to-edge Android presentation
- clickable native hit-zones for Store, Events, Rewards, Achievements, Start Game and bottom navigation
- dark glass destination overlays so every visible navigation target responds now
- no multi-ZIP module loader: this remains one complete Android project ZIP

## Important architecture rule
Every next stage will be a complete replacement ZIP containing all previous work.
