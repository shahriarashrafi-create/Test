# HeroLife Stage 15 — Production GLB Renderer

Cumulative replacement ZIP.

Fixes included:
- transparent 3D viewport retained
- automatic model bounds/framing so different professional GLBs fit the same hero slot
- larger hero composition without breaking HUD
- safer rotation framing
- brighter key/fill/rim lighting
- material metallic/roughness support
- UV-ready GLB geometry path
- separate GLB asset registry for male/female
- quote/rank/start spacing refined
- companion remains removed

Production realism:
The renderer is ready for professionally authored GLB 2.0 humans with BaseColor, Normal,
Metallic/Roughness, Skin, Eye, Hair and Armor/Cloth materials plus optional Skeleton/Animation.

The bundled GLBs remain pipeline verification assets; they are not falsely represented as
photoreal final characters. To reach the visual reference, swap only
`female_realistic_01.glb` and `male_realistic_01.glb` with licensed/professional assets.
No lobby redesign is required.
