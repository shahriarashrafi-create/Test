package com.shahriar.gamification

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChecklistRtl
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    GamificationApp()
                }
            }
        }
    }
}

private val BgTop = Color(0xFF07111F)
private val BgMid = Color(0xFF0A1830)
private val BgBottom = Color(0xFF08101D)
private val Panel = Color(0xEB152641)
private val PanelDark = Color(0xF20A1527)
private val Gold = Color(0xFFFFC857)
private val Cyan = Color(0xFF56D9FF)
private val Green = Color(0xFF63E8A4)
private val Pink = Color(0xFFFF73B2)
private val White = Color(0xFFF7FAFF)
private val Muted = Color(0xFFB6C4D9)

private enum class MainTab(val title: String) {
    HOME("خانه"),
    TASKS("کارها"),
    STATS("آمار"),
    TIMESHEET("تایم شیت"),
    NETWORK("شبکه سازی")
}

private enum class GameMode(val title: String, val subtitle: String) {
    TEN("۱۰ دقیقه", "یک کار"),
    THIRTY("۳۰ دقیقه", "استاندارد"),
    SIXTY("۶۰ دقیقه", "تمرکز عمیق")
}

@Composable
private fun GamificationApp() {
    var selectedTab by remember { mutableStateOf(MainTab.HOME) }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            BottomNavigation(
                selectedTab = selectedTab,
                onSelect = { selectedTab = it }
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            GameBackground()

            when (selectedTab) {
                MainTab.HOME -> HomeScreen(innerPadding)
                MainTab.TASKS -> PlaceholderScreen(
                    innerPadding,
                    "کارها",
                    "بانک کارهای بازی، ترتیب زمانی، افزودن، ویرایش و حذف در قدم بعدی."
                )
                MainTab.STATS -> PlaceholderScreen(
                    innerPadding,
                    "آمار",
                    "درختواره تیم، فروش، GPV، رشد و هدف‌ها در قدم بعدی."
                )
                MainTab.TIMESHEET -> PlaceholderScreen(
                    innerPadding,
                    "تایم شیت",
                    "برنامه زمانی هفتگی و وضعیت برنامه‌ها در قدم بعدی."
                )
                MainTab.NETWORK -> PlaceholderScreen(
                    innerPadding,
                    "شبکه سازی",
                    "پراسپکت، معرف، مشاور معرف و اقدامات بعدی در قدم بعدی."
                )
            }
        }
    }
}

@Composable
private fun GameBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(BgTop, BgMid, BgBottom)
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Cyan.copy(alpha = 0.09f),
                radius = size.minDimension * 0.34f,
                center = Offset(size.width * 0.82f, size.height * 0.16f)
            )

            drawCircle(
                color = Gold.copy(alpha = 0.055f),
                radius = size.minDimension * 0.27f,
                center = Offset(size.width * 0.14f, size.height * 0.70f)
            )

            repeat(18) { index ->
                val x = size.width * (((index * 37) % 100) / 100f)
                val y = size.height * (((index * 59) % 60) / 100f)
                drawCircle(
                    color = Color.White.copy(alpha = 0.075f),
                    radius = 2f,
                    center = Offset(x, y)
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(innerPadding: PaddingValues) {
    var selectedMode by remember { mutableStateOf(GameMode.THIRTY) }

    val configuration = LocalConfiguration.current
    val compact = configuration.screenHeightDp < 760

    val horizontalPadding = if (compact) 8.dp else 11.dp
    val verticalPadding = if (compact) 6.dp else 8.dp
    val gap = if (compact) 6.dp else 8.dp

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(
                horizontal = horizontalPadding,
                vertical = verticalPadding
            ),
        verticalArrangement = Arrangement.spacedBy(gap)
    ) {
        HeaderTitle(
            compact = compact,
            modifier = Modifier.weight(0.34f)
        )

        ProfilePanel(
            compact = compact,
            modifier = Modifier.weight(1.55f)
        )

        QuickActions(
            compact = compact,
            modifier = Modifier.weight(1.35f)
        )

        RankPanel(
            compact = compact,
            modifier = Modifier.weight(0.52f)
        )

        ModePanel(
            compact = compact,
            selectedMode = selectedMode,
            onSelect = { selectedMode = it },
            modifier = Modifier.weight(0.62f)
        )

        StartGamePanel(
            compact = compact,
            mode = selectedMode,
            modifier = Modifier.weight(0.82f)
        )

        TodayPanel(
            compact = compact,
            modifier = Modifier.weight(0.56f)
        )
    }
}

@Composable
private fun HeaderTitle(
    compact: Boolean,
    modifier: Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(if (compact) 34.dp else 38.dp),
            shape = RoundedCornerShape(11.dp),
            color = Panel,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
        ) {
            Box(
                modifier = Modifier.clickable { },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "تنظیمات",
                    tint = White,
                    modifier = Modifier.size(if (compact) 19.dp else 22.dp)
                )
            }
        }

        Text(
            text = "گیمیفیکیشن",
            modifier = Modifier.weight(1f),
            color = White,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            fontSize = if (compact) 18.sp else 21.sp
        )

        Spacer(modifier = Modifier.width(if (compact) 34.dp else 38.dp))
    }
}

@Composable
private fun ProfilePanel(
    compact: Boolean,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(if (compact) 17.dp else 21.dp),
        color = Panel,
        border = BorderStroke(1.dp, Cyan.copy(alpha = 0.18f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (compact) 9.dp else 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(if (compact) 42.dp else 49.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Gold, Cyan)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ش",
                        color = BgTop,
                        fontWeight = FontWeight.Black,
                        fontSize = if (compact) 21.sp else 25.sp
                    )
                }

                Spacer(modifier = Modifier.width(9.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "شهریار",
                        color = White,
                        fontWeight = FontWeight.Black,
                        fontSize = if (compact) 18.sp else 21.sp
                    )
                    Text(
                        text = "جنگجوی رشد | LV.28",
                        color = Muted,
                        fontSize = if (compact) 9.sp else 11.sp
                    )
                }

                Text(
                    text = "♛",
                    color = Gold,
                    fontSize = if (compact) 22.sp else 27.sp
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "۶۲۴۰ / ۸۰۰۰ XP",
                    color = Gold,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = if (compact) 8.sp else 10.sp
                )
                Text(
                    text = "پیشرفت سطح",
                    color = Muted,
                    fontSize = if (compact) 8.sp else 10.sp
                )
            }

            ProgressBar(
                value = 0.78f,
                compact = compact
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MiniStat(
                    modifier = Modifier.weight(1f),
                    label = "رنک",
                    value = "حماسی III",
                    icon = Icons.Rounded.EmojiEvents,
                    accent = Pink,
                    compact = compact
                )

                MiniStat(
                    modifier = Modifier.weight(1f),
                    label = "الماس",
                    value = "۱۲",
                    icon = Icons.Rounded.AutoAwesome,
                    accent = Cyan,
                    compact = compact
                )

                MiniStat(
                    modifier = Modifier.weight(1f),
                    label = "طلا",
                    value = "۲۴۳۷",
                    icon = Icons.Rounded.ShoppingBag,
                    accent = Gold,
                    compact = compact
                )
            }
        }
    }
}

@Composable
private fun MiniStat(
    modifier: Modifier,
    label: String,
    value: String,
    icon: ImageVector,
    accent: Color,
    compact: Boolean
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(13.dp),
        color = Color.White.copy(alpha = 0.035f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.20f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = if (compact) 6.dp else 8.dp,
                vertical = if (compact) 4.dp else 6.dp
            ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(if (compact) 16.dp else 19.dp)
            )

            Column {
                Text(
                    text = label,
                    color = Muted,
                    fontSize = if (compact) 7.sp else 8.sp
                )
                Text(
                    text = value,
                    color = White,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (compact) 9.sp else 11.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun QuickActions(
    compact: Boolean,
    modifier: Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            QuickTile(
                modifier = Modifier.weight(1f),
                title = "فروشگاه",
                subtitle = "پاداش واقعی",
                icon = Icons.Rounded.ShoppingBag,
                accent = Gold,
                compact = compact
            )

            QuickTile(
                modifier = Modifier.weight(1f),
                title = "رویدادها",
                subtitle = "ایونت‌ها و اعضا",
                icon = Icons.Rounded.Event,
                accent = Cyan,
                compact = compact
            )
        }

        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            QuickTile(
                modifier = Modifier.weight(1f),
                title = "آینده بینی",
                subtitle = "سال‌ها و نتایج",
                icon = Icons.Rounded.Timeline,
                accent = Pink,
                compact = compact
            )

            QuickTile(
                modifier = Modifier.weight(1f),
                title = "دستاوردها",
                subtitle = "روزانه تا بلندمدت",
                icon = Icons.Rounded.EmojiEvents,
                accent = Green,
                compact = compact
            )
        }
    }
}

@Composable
private fun QuickTile(
    modifier: Modifier,
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    compact: Boolean
) {
    Surface(
        modifier = modifier.fillMaxSize(),
        shape = RoundedCornerShape(if (compact) 16.dp else 19.dp),
        color = Panel,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.22f))
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = 9.dp,
                vertical = 6.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(if (compact) 23.dp else 27.dp)
            )

            Spacer(modifier = Modifier.width(7.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = White,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (compact) 12.sp else 14.sp
                )
                Text(
                    text = subtitle,
                    color = Muted,
                    fontSize = if (compact) 7.sp else 8.sp,
                    maxLines = 1
                )
            }

            Text(
                text = "‹",
                color = Muted,
                fontSize = 21.sp
            )
        }
    }
}

@Composable
private fun RankPanel(
    compact: Boolean,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = Panel,
        border = BorderStroke(1.dp, Gold.copy(alpha = 0.20f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.EmojiEvents,
                contentDescription = null,
                tint = Gold,
                modifier = Modifier.size(if (compact) 23.dp else 27.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "حماسی III",
                        color = White,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 11.sp else 13.sp
                    )

                    Text(
                        text = "۵۴ / ۱۰۰",
                        color = Muted,
                        fontSize = if (compact) 8.sp else 9.sp
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                ProgressBar(
                    value = 0.54f,
                    compact = compact
                )
            }
        }
    }
}

@Composable
private fun ModePanel(
    compact: Boolean,
    selectedMode: GameMode,
    onSelect: (GameMode) -> Unit,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = PanelDark,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            ModeButton(
                modifier = Modifier.weight(1f),
                mode = GameMode.SIXTY,
                selected = selectedMode == GameMode.SIXTY,
                compact = compact,
                onClick = { onSelect(GameMode.SIXTY) }
            )

            ModeButton(
                modifier = Modifier.weight(1f),
                mode = GameMode.THIRTY,
                selected = selectedMode == GameMode.THIRTY,
                compact = compact,
                onClick = { onSelect(GameMode.THIRTY) }
            )

            ModeButton(
                modifier = Modifier.weight(1f),
                mode = GameMode.TEN,
                selected = selectedMode == GameMode.TEN,
                compact = compact,
                onClick = { onSelect(GameMode.TEN) }
            )
        }
    }
}

@Composable
private fun ModeButton(
    modifier: Modifier,
    mode: GameMode,
    selected: Boolean,
    compact: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .fillMaxSize()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFF173A64) else Color.White.copy(alpha = 0.02f),
        border = BorderStroke(
            1.dp,
            if (selected) Cyan.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.05f)
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = mode.title,
                color = if (selected) Gold else White,
                fontWeight = FontWeight.Bold,
                fontSize = if (compact) 9.sp else 11.sp
            )
            Text(
                text = mode.subtitle,
                color = Muted,
                fontSize = if (compact) 6.sp else 7.sp
            )
        }
    }
}

@Composable
private fun StartGamePanel(
    compact: Boolean,
    mode: GameMode,
    modifier: Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { },
        shape = RoundedCornerShape(18.dp),
        color = Color.Transparent,
        border = BorderStroke(1.5.dp, Cyan.copy(alpha = 0.75f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF092049),
                            Color(0xFF145FA8),
                            Color(0xFF092049)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "⚔️",
                    fontSize = if (compact) 23.sp else 28.sp
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "شروع بازی",
                        color = White,
                        fontWeight = FontWeight.Black,
                        fontSize = if (compact) 20.sp else 24.sp
                    )

                    Text(
                        text = mode.title,
                        color = Gold,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 9.sp else 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun TodayPanel(
    compact: Boolean,
    modifier: Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "امروز",
                color = White,
                fontWeight = FontWeight.Bold,
                fontSize = if (compact) 11.sp else 13.sp
            )

            TodayItem(
                modifier = Modifier.weight(1f),
                value = "۲",
                label = "بازی",
                accent = Cyan,
                compact = compact
            )

            TodayItem(
                modifier = Modifier.weight(1f),
                value = "۸",
                label = "کار",
                accent = Gold,
                compact = compact
            )

            TodayItem(
                modifier = Modifier.weight(1f),
                value = "۵",
                label = "شبکه سازی",
                accent = Green,
                compact = compact
            )
        }
    }
}

@Composable
private fun TodayItem(
    modifier: Modifier,
    value: String,
    label: String,
    accent: Color,
    compact: Boolean
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = value,
            color = accent,
            fontWeight = FontWeight.Black,
            fontSize = if (compact) 11.sp else 13.sp
        )

        Spacer(modifier = Modifier.width(3.dp))

        Text(
            text = label,
            color = Muted,
            fontSize = if (compact) 7.sp else 8.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun ProgressBar(
    value: Float,
    compact: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (compact) 5.dp else 7.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(Color.White.copy(alpha = 0.08f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(value)
                .fillMaxHeight()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Cyan, Gold)
                    )
                )
        )
    }
}

@Composable
private fun BottomNavigation(
    selectedTab: MainTab,
    onSelect: (MainTab) -> Unit
) {
    Surface(
        color = Color(0xFF08121F),
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomTabButton(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.HOME,
                label = "خانه",
                icon = Icons.Rounded.Home,
                onClick = { onSelect(MainTab.HOME) }
            )

            BottomTabButton(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.TASKS,
                label = "کارها",
                icon = Icons.Rounded.ChecklistRtl,
                onClick = { onSelect(MainTab.TASKS) }
            )

            BottomTabButton(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.STATS,
                label = "آمار",
                icon = Icons.Rounded.Insights,
                onClick = { onSelect(MainTab.STATS) }
            )

            BottomTabButton(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.TIMESHEET,
                label = "تایم شیت",
                icon = Icons.Rounded.Schedule,
                onClick = { onSelect(MainTab.TIMESHEET) }
            )

            BottomTabButton(
                modifier = Modifier.weight(1f),
                selected = selectedTab == MainTab.NETWORK,
                label = "شبکه سازی",
                icon = Icons.Rounded.Groups,
                onClick = { onSelect(MainTab.NETWORK) }
            )
        }
    }
}

@Composable
private fun BottomTabButton(
    modifier: Modifier,
    selected: Boolean,
    label: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val contentColor = if (selected) Gold else Muted
    val backgroundColor = if (selected) Gold.copy(alpha = 0.12f) else Color.Transparent

    Surface(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = backgroundColor,
        border = if (selected) {
            BorderStroke(1.dp, Gold.copy(alpha = 0.18f))
        } else {
            null
        }
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(22.dp)
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = label,
                color = contentColor,
                fontSize = 8.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PlaceholderScreen(
    padding: PaddingValues,
    title: String,
    subtitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Panel,
            border = BorderStroke(1.dp, Cyan.copy(alpha = 0.15f))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = title,
                    color = White,
                    fontWeight = FontWeight.Black,
                    fontSize = 26.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = subtitle,
                    color = Muted,
                    textAlign = TextAlign.Center,
                    fontSize = 12.sp
                )
            }
        }
    }
}
