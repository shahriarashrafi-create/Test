package com.herolife.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.herolife.app.model.LobbyDestination
import com.herolife.app.ui.theme.HL

@Composable
fun TopHud(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = HL.Navy.copy(alpha = .90f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(50.dp)
                    .background(HL.Navy2, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("ش", color = HL.GoldBright, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }

            Spacer(Modifier.width(8.dp))

            Column(Modifier.width(118.dp)) {
                Text("شهریار", color = HL.Text, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text("Lv. 28", color = HL.Gold, fontSize = 11.sp)
                LinearProgressIndicator(
                    progress = { .78f },
                    modifier = Modifier.fillMaxWidth().height(5.dp),
                    color = HL.Crystal,
                    trackColor = HL.Navy2
                )
            }

            Spacer(Modifier.width(8.dp))
            Resource("🪙", "2,437")
            Spacer(Modifier.width(8.dp))
            Resource("💎", "12")
            Spacer(Modifier.width(8.dp))
            Resource("⚡", "8/10")
        }
    }
}

@Composable
private fun Resource(icon: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 15.sp)
        Text(value, color = HL.Text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun SideMenu(
    modifier: Modifier = Modifier,
    onNavigate: (LobbyDestination) -> Unit
) {
    Column(
        modifier = modifier.width(90.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MenuButton("♛", "فروشگاه") { onNavigate(LobbyDestination.SHOP) }
        MenuButton("🎁", "رویدادها") { onNavigate(LobbyDestination.EVENTS) }
        MenuButton("▣", "جوایز") { onNavigate(LobbyDestination.REWARDS) }
        MenuButton("🏆", "دستاوردها") { onNavigate(LobbyDestination.ACHIEVEMENTS) }
    }
}

@Composable
private fun MenuButton(icon: String, label: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(82.dp)
            .clickable(onClick = onClick),
        color = HL.Panel,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, HL.Gold.copy(alpha = .35f))
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 22.sp)
            Text(label, color = HL.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun QuotePanel(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = HL.Panel,
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, HL.Gold.copy(alpha = .25f))
    ) {
        Text(
            "«نسخه بهتر خودت، در انتظار اقدام امروز توست.»",
            modifier = Modifier.padding(14.dp),
            color = HL.Text,
            fontSize = 12.sp
        )
    }
}

@Composable
fun BottomHud(
    modifier: Modifier = Modifier,
    onNavigate: (LobbyDestination) -> Unit
) {
    Column(modifier) {
        RankPanel(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 58.dp)
        )

        Spacer(Modifier.height(10.dp))

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 48.dp)
                .height(82.dp)
                .clickable { onNavigate(LobbyDestination.START) },
            shape = RoundedCornerShape(24.dp),
            color = HL.Gold,
            border = androidx.compose.foundation.BorderStroke(2.dp, HL.GoldBright)
        ) {
            Box(
                Modifier.background(
                    Brush.horizontalGradient(
                        listOf(HL.Gold.copy(alpha=.72f), HL.GoldBright.copy(alpha=.95f), HL.Gold.copy(alpha=.72f))
                    )
                ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⚔ شروع بازی", fontSize = 28.sp, fontWeight = FontWeight.Black, color = HL.Void)
                    Text("۳۰ دقیقه", fontSize = 12.sp, color = HL.Void)
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        NavigationBar(containerColor = HL.Navy.copy(alpha = .96f)) {
            Nav("⌂", "خانه", true) { onNavigate(LobbyDestination.HOME) }
            Nav("✓", "کارها", false) { onNavigate(LobbyDestination.TASKS) }
            Nav("▥", "آمار", false) { onNavigate(LobbyDestination.STATS) }
            Nav("🎁", "جوایز", false) { onNavigate(LobbyDestination.REWARDS) }
            Nav("☰", "بیشتر", false) { onNavigate(LobbyDestination.MORE) }
        }
    }
}

@Composable
private fun RankPanel(modifier: Modifier) {
    Surface(
        modifier = modifier.height(92.dp),
        color = HL.Panel,
        shape = RoundedCornerShape(22.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, HL.Crystal.copy(alpha = .25f))
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("♜", color = HL.GoldBright, fontSize = 36.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("رنک فعلی", color = HL.Muted, fontSize = 11.sp)
                Text("حماسی III", color = HL.GoldBright, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("✦ 54 / 100", color = HL.Text, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun RowScope.Nav(
    icon: String,
    label: String,
    selected: Boolean,
    action: () -> Unit
) {
    NavigationBarItem(
        selected = selected,
        onClick = action,
        icon = {
            Text(icon, color = if (selected) HL.GoldBright else HL.Crystal, fontSize = 20.sp)
        },
        label = {
            Text(label, color = if (selected) HL.Text else HL.Muted, fontSize = 10.sp)
        }
    )
}
