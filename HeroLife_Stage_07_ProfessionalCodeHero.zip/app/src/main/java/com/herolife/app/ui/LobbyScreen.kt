package com.herolife.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.herolife.app.model.LobbyDestination
import com.herolife.app.model.LobbyState
import com.herolife.app.ui.components.EnvironmentLayer
import com.herolife.app.ui.components.HeroLayer
import com.herolife.app.ui.components.BottomHud
import com.herolife.app.ui.components.QuotePanel
import com.herolife.app.ui.components.SideMenu
import com.herolife.app.ui.components.TopHud
import com.herolife.app.ui.theme.HL

@Composable
fun LobbyScreen(
    state: LobbyState,
    onHeroClick: () -> Unit,
    onNavigate: (LobbyDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HL.Void)
    ) {
        EnvironmentLayer(
            modifier = Modifier.fillMaxSize()
        )

        HeroLayer(
            selection = state.hero,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(
                    top = 84.dp,
                    start = 52.dp,
                    end = 28.dp,
                    bottom = 250.dp
                )
                .fillMaxWidth(.72f)
                .fillMaxHeight(.70f),
            onClick = onHeroClick
        )

        TopHud(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
        )

        SideMenu(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(
                    start = 12.dp,
                    top = 46.dp
                ),
            onNavigate = onNavigate
        )

        QuotePanel(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(
                    end = 14.dp,
                    top = 110.dp
                )
                .fillMaxWidth(.34f)
        )

        BottomHud(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            onNavigate = onNavigate
        )
    }
}
