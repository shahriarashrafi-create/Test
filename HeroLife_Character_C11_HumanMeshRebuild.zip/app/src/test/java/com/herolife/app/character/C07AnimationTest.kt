package com.herolife.app.character

import org.junit.Assert.assertTrue
import org.junit.Test

class C07AnimationTest {
    @Test fun idlePoseProducesCoreBones() {
        val names = HumanoidIdlePose.evaluate(0.5f).map { it.name }
        assertTrue("Hips" in names)
        assertTrue("Chest" in names)
        assertTrue("Head" in names)
    }

    @Test fun animationTimeAdvances() {
        val next = CharacterAnimationState().tick(0.25f)
        assertTrue(next.timeSeconds > 0f)
    }
}
