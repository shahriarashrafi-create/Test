package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.herolife.app.model.HeroGender
import com.herolife.app.model.HeroSelection
import com.herolife.app.ui.theme.HL

@Composable
fun HeroLayer(
    selection: HeroSelection,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Canvas(
        modifier = modifier.clickable(onClick = onClick)
    ) {
        val cx = size.width * .52f
        val faceY = size.height * .16f
        val shoulderY = size.height * .29f
        val waistY = size.height * .53f
        val kneeY = size.height * .76f
        val bottom = size.height * .97f

        drawCircle(
            brush = Brush.radialGradient(
                listOf(
                    HL.Gold.copy(alpha = .14f),
                    HL.Crystal.copy(alpha = .035f),
                    Color.Transparent
                )
            ),
            radius = size.width * .44f,
            center = Offset(cx, size.height * .39f)
        )

        if (selection.gender == HeroGender.FEMALE) {
            // hair back
            val hairBack = Path().apply {
                moveTo(cx - size.width * .10f, faceY - size.height * .08f)
                cubicTo(
                    cx - size.width * .25f,
                    faceY + size.height * .06f,
                    cx - size.width * .24f,
                    shoulderY + size.height * .23f,
                    cx - size.width * .14f,
                    size.height * .62f
                )
                lineTo(cx + size.width * .16f, size.height * .60f)
                cubicTo(
                    cx + size.width * .25f,
                    shoulderY + size.height * .18f,
                    cx + size.width * .19f,
                    faceY,
                    cx + size.width * .09f,
                    faceY - size.height * .07f
                )
                close()
            }
            drawPath(
                hairBack,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF4A2B22),
                        Color(0xFF2A1717),
                        Color(0xFF110C0E)
                    )
                )
            )

            // cloak behind
            val cloak = Path().apply {
                moveTo(cx + size.width * .11f, shoulderY)
                cubicTo(
                    cx + size.width * .28f,
                    size.height * .44f,
                    cx + size.width * .32f,
                    size.height * .76f,
                    cx + size.width * .22f,
                    bottom
                )
                lineTo(cx - size.width * .03f, bottom)
                lineTo(cx + size.width * .01f, shoulderY)
                close()
            }
            drawPath(
                cloak,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF171A22),
                        Color(0xFF090C12)
                    )
                )
            )

            // face
            drawOval(
                color = Color(0xFFE6B8A2),
                topLeft = Offset(
                    cx - size.width * .065f,
                    faceY - size.height * .045f
                ),
                size = Size(
                    size.width * .13f,
                    size.height * .11f
                )
            )

            // cheek shadow
            drawOval(
                color = Color(0xFFC98D79).copy(alpha = .22f),
                topLeft = Offset(
                    cx - size.width * .008f,
                    faceY + size.height * .006f
                ),
                size = Size(
                    size.width * .046f,
                    size.height * .036f
                )
            )

            // eyebrows / eyes
            drawLine(
                color = Color(0xFF4A2727),
                start = Offset(cx - size.width * .043f, faceY - size.height * .005f),
                end = Offset(cx - size.width * .012f, faceY - size.height * .009f),
                strokeWidth = 2.4f
            )
            drawLine(
                color = Color(0xFF4A2727),
                start = Offset(cx + size.width * .012f, faceY - size.height * .009f),
                end = Offset(cx + size.width * .043f, faceY - size.height * .004f),
                strokeWidth = 2.4f
            )
            drawCircle(
                color = Color(0xFF241D21),
                radius = size.width * .0055f,
                center = Offset(cx - size.width * .025f, faceY + size.height * .004f)
            )
            drawCircle(
                color = Color(0xFF241D21),
                radius = size.width * .0055f,
                center = Offset(cx + size.width * .025f, faceY + size.height * .004f)
            )

            // nose + lips
            drawLine(
                color = Color(0xFFB97D6A).copy(alpha = .75f),
                start = Offset(cx, faceY + size.height * .010f),
                end = Offset(cx - size.width * .006f, faceY + size.height * .032f),
                strokeWidth = 1.8f
            )
            drawLine(
                color = Color(0xFF9E4D58),
                start = Offset(cx - size.width * .018f, faceY + size.height * .045f),
                end = Offset(cx + size.width * .020f, faceY + size.height * .045f),
                strokeWidth = 2.5f
            )

            // front hair framing
            drawArc(
                color = Color(0xFF35201B),
                startAngle = 185f,
                sweepAngle = 150f,
                useCenter = false,
                topLeft = Offset(
                    cx - size.width * .085f,
                    faceY - size.height * .068f
                ),
                size = Size(
                    size.width * .17f,
                    size.height * .12f
                ),
                style = Stroke(width = size.width * .022f)
            )

            // torso armor shape
            val torso = Path().apply {
                moveTo(cx, shoulderY)
                lineTo(cx - size.width * .18f, shoulderY + size.height * .05f)
                lineTo(cx - size.width * .13f, waistY)
                lineTo(cx - size.width * .09f, waistY + size.height * .08f)
                lineTo(cx + size.width * .10f, waistY + size.height * .08f)
                lineTo(cx + size.width * .13f, waistY)
                lineTo(cx + size.width * .18f, shoulderY + size.height * .05f)
                close()
            }
            drawPath(
                torso,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF242832),
                        Color(0xFF131821),
                        Color(0xFF090D13)
                    )
                )
            )

            // chest armor side panels
            drawArc(
                color = HL.Gold.copy(alpha = .68f),
                startAngle = 195f,
                sweepAngle = 135f,
                useCenter = false,
                topLeft = Offset(
                    cx - size.width * .13f,
                    shoulderY + size.height * .045f
                ),
                size = Size(
                    size.width * .14f,
                    size.height * .12f
                ),
                style = Stroke(width = size.width * .009f)
            )
            drawArc(
                color = HL.Gold.copy(alpha = .68f),
                startAngle = 210f,
                sweepAngle = 135f,
                useCenter = false,
                topLeft = Offset(
                    cx - size.width * .005f,
                    shoulderY + size.height * .045f
                ),
                size = Size(
                    size.width * .14f,
                    size.height * .12f
                ),
                style = Stroke(width = size.width * .009f)
            )

            // central gold filigree
            drawLine(
                color = HL.Gold,
                start = Offset(cx, shoulderY + size.height * .02f),
                end = Offset(cx, waistY + size.height * .03f),
                strokeWidth = size.width * .006f
            )
            repeat(4) { i ->
                val y = shoulderY + size.height * (.08f + i * .055f)
                drawLine(
                    color = HL.Gold.copy(alpha = .62f),
                    start = Offset(cx - size.width * .035f, y),
                    end = Offset(cx + size.width * .035f, y),
                    strokeWidth = size.width * .004f
                )
            }

            // waist belt
            drawLine(
                color = HL.Gold,
                start = Offset(cx - size.width * .11f, waistY + size.height * .025f),
                end = Offset(cx + size.width * .11f, waistY + size.height * .025f),
                strokeWidth = size.width * .010f
            )
            drawCircle(
                color = HL.Crystal,
                radius = size.width * .012f,
                center = Offset(cx, waistY + size.height * .025f)
            )

            // arms
            drawLine(
                color = Color(0xFFDDAA91),
                start = Offset(cx - size.width * .16f, shoulderY + size.height * .055f),
                end = Offset(cx - size.width * .20f, size.height * .61f),
                strokeWidth = size.width * .045f
            )
            drawLine(
                color = Color(0xFFDDAA91),
                start = Offset(cx + size.width * .16f, shoulderY + size.height * .055f),
                end = Offset(cx + size.width * .18f, size.height * .59f),
                strokeWidth = size.width * .045f
            )

            // gauntlets
            drawLine(
                color = Color(0xFF202630),
                start = Offset(cx - size.width * .195f, size.height * .52f),
                end = Offset(cx - size.width * .205f, size.height * .62f),
                strokeWidth = size.width * .052f
            )
            drawLine(
                color = Color(0xFF202630),
                start = Offset(cx + size.width * .18f, size.height * .50f),
                end = Offset(cx + size.width * .18f, size.height * .60f),
                strokeWidth = size.width * .052f
            )

            // skirt/legs
            val lower = Path().apply {
                moveTo(cx - size.width * .10f, waistY + size.height * .07f)
                lineTo(cx - size.width * .13f, bottom)
                lineTo(cx - size.width * .01f, bottom)
                lineTo(cx, kneeY)
                lineTo(cx + size.width * .035f, bottom)
                lineTo(cx + size.width * .15f, bottom)
                lineTo(cx + size.width * .10f, waistY + size.height * .07f)
                close()
            }
            drawPath(
                lower,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF121720),
                        Color(0xFF070A10)
                    )
                )
            )

            // gold trim
            drawLine(
                color = HL.Gold.copy(alpha = .78f),
                start = Offset(cx + size.width * .095f, waistY + size.height * .08f),
                end = Offset(cx + size.width * .13f, bottom),
                strokeWidth = size.width * .006f
            )

        } else {
            // male hero
            val cloak = Path().apply {
                moveTo(cx + size.width * .09f, shoulderY)
                lineTo(cx + size.width * .24f, bottom)
                lineTo(cx - size.width * .02f, bottom)
                lineTo(cx, shoulderY)
                close()
            }
            drawPath(
                cloak,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF181C23),
                        Color(0xFF090B10)
                    )
                )
            )

            drawOval(
                color = Color(0xFFD7A88F),
                topLeft = Offset(
                    cx - size.width * .062f,
                    faceY - size.height * .042f
                ),
                size = Size(
                    size.width * .124f,
                    size.height * .105f
                )
            )

            val hair = Path().apply {
                moveTo(cx - size.width * .07f, faceY - size.height * .045f)
                lineTo(cx - size.width * .035f, faceY - size.height * .085f)
                lineTo(cx + size.width * .075f, faceY - size.height * .060f)
                lineTo(cx + size.width * .082f, faceY - size.height * .010f)
                close()
            }
            drawPath(hair, Color(0xFF16171A))

            drawLine(
                color = Color(0xFF332622),
                start = Offset(cx - size.width * .036f, faceY - size.height * .002f),
                end = Offset(cx - size.width * .010f, faceY - size.height * .006f),
                strokeWidth = 2.5f
            )
            drawLine(
                color = Color(0xFF332622),
                start = Offset(cx + size.width * .010f, faceY - size.height * .006f),
                end = Offset(cx + size.width * .036f, faceY - size.height * .002f),
                strokeWidth = 2.5f
            )

            val coat = Path().apply {
                moveTo(cx, shoulderY)
                lineTo(cx - size.width * .20f, shoulderY + size.height * .05f)
                lineTo(cx - size.width * .22f, bottom)
                lineTo(cx + size.width * .20f, bottom)
                lineTo(cx + size.width * .18f, shoulderY + size.height * .05f)
                close()
            }
            drawPath(
                coat,
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF222730),
                        Color(0xFF10151D),
                        Color(0xFF080B10)
                    )
                )
            )

            // lapels
            drawLine(
                color = HL.Gold.copy(alpha = .80f),
                start = Offset(cx - size.width * .05f, shoulderY + size.height * .02f),
                end = Offset(cx + size.width * .02f, waistY),
                strokeWidth = size.width * .008f
            )
            drawLine(
                color = HL.Gold.copy(alpha = .80f),
                start = Offset(cx + size.width * .06f, shoulderY + size.height * .02f),
                end = Offset(cx + size.width * .02f, waistY),
                strokeWidth = size.width * .008f
            )

            // belt
            drawLine(
                color = HL.Gold,
                start = Offset(cx - size.width * .11f, waistY + size.height * .02f),
                end = Offset(cx + size.width * .12f, waistY + size.height * .02f),
                strokeWidth = size.width * .009f
            )

            // arms
            drawLine(
                color = Color(0xFFD1A088),
                start = Offset(cx - size.width * .17f, shoulderY + size.height * .06f),
                end = Offset(cx - size.width * .20f, size.height * .62f),
                strokeWidth = size.width * .045f
            )
            drawLine(
                color = Color(0xFFD1A088),
                start = Offset(cx + size.width * .16f, shoulderY + size.height * .06f),
                end = Offset(cx + size.width * .18f, size.height * .60f),
                strokeWidth = size.width * .045f
            )

            // pants split
            drawLine(
                color = Color(0xFF1B2028),
                start = Offset(cx, waistY + size.height * .08f),
                end = Offset(cx, bottom),
                strokeWidth = size.width * .010f
            )

            drawLine(
                color = HL.Gold.copy(alpha = .75f),
                start = Offset(cx + size.width * .10f, waistY + size.height * .05f),
                end = Offset(cx + size.width * .14f, bottom),
                strokeWidth = size.width * .006f
            )
        }
    }
}
