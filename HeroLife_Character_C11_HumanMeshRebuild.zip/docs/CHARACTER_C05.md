# C05 — PBR Detail Pass
Cumulative character stage.

Added/refined:
- softer skin PBR response plus subtle facial highlight zones
- separate sclera, iris and pupil materials
- glossy colored iris / dark pupil for readable eyes
- layered dark hair with warmer highlight strands
- refined lip and brow materials
- more metallic gold and tighter leather roughness
- crystal-blue gem accents with subtle emissive response
- retained black/gold fantasy outfit
- no companion

Stats: 34,652 vertices / 64,944 triangles / 92 primitives / 13 materials.

Important: this is a procedural PBR-material/detail pass. True photographic skin still requires UV texture maps,
which is the next realism milestone.
Next: C06 — UV/Texture Architecture + Rig preparation.
