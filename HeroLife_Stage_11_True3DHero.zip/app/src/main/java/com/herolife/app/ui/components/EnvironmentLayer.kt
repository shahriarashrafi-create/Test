package com.herolife.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.herolife.app.ui.theme.HL
import kotlin.math.sin

@Composable
fun EnvironmentLayer(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        // Sky
        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color(0xFF2A3D57),
                    Color(0xFF182A43),
                    Color(0xFF0D1B2E),
                    HL.Void
                )
            )
        )

        // Warm cinematic sun glow
        drawCircle(
            brush = Brush.radialGradient(
                listOf(
                    Color(0xFFFFDCA0).copy(alpha = .26f),
                    Color(0xFFF7B84F).copy(alpha = .08f),
                    Color.Transparent
                )
            ),
            radius = size.width * .48f,
            center = Offset(
                size.width * .70f,
                size.height * .17f
            )
        )

        // Far mountain layer
        val far = Path().apply {
            moveTo(0f, size.height * .45f)
            lineTo(size.width * .08f, size.height * .33f)
            lineTo(size.width * .16f, size.height * .43f)
            lineTo(size.width * .26f, size.height * .28f)
            lineTo(size.width * .39f, size.height * .46f)
            lineTo(size.width * .54f, size.height * .24f)
            lineTo(size.width * .66f, size.height * .42f)
            lineTo(size.width * .82f, size.height * .27f)
            lineTo(size.width, size.height * .38f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(far, Color(0xFF263E5A))

        // Mid cliffs
        val mid = Path().apply {
            moveTo(0f, size.height * .57f)
            lineTo(size.width * .13f, size.height * .41f)
            lineTo(size.width * .25f, size.height * .58f)
            lineTo(size.width * .38f, size.height * .39f)
            lineTo(size.width * .52f, size.height * .59f)
            lineTo(size.width * .70f, size.height * .40f)
            lineTo(size.width * .83f, size.height * .57f)
            lineTo(size.width, size.height * .46f)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(mid, Color(0xFF173149))

        // Castle silhouette
        val castleBase = size.height * .49f
        repeat(13) { index ->
            val x = size.width * (.54f + index * .035f)
            val towerW = size.width * (.018f + (index % 3) * .004f)
            val towerH = size.height * (.075f + (index % 5) * .018f)

            drawRect(
                color = Color(0xFF314A66),
                topLeft = Offset(x, castleBase - towerH),
                size = Size(towerW, towerH)
            )

            drawLine(
                color = Color(0xFF5D7289),
                start = Offset(x + towerW * .5f, castleBase - towerH),
                end = Offset(x + towerW * .5f, castleBase - towerH - size.height * .022f),
                strokeWidth = 1.3f
            )

            repeat(3) { floor ->
                drawCircle(
                    color = HL.Gold.copy(alpha = .32f),
                    radius = 1.6f,
                    center = Offset(
                        x + towerW * .5f,
                        castleBase - towerH * (.22f + floor * .22f)
                    )
                )
            }
        }

        // Waterfall streaks
        repeat(5) { index ->
            val x = size.width * (.11f + index * .12f)
            val y1 = size.height * (.36f + (index % 2) * .04f)
            val y2 = size.height * (.59f + (index % 3) * .025f)
            drawLine(
                color = HL.Crystal.copy(alpha = .12f),
                start = Offset(x, y1),
                end = Offset(x + size.width * .008f, y2),
                strokeWidth = size.width * .008f
            )
        }

        // Birds
        repeat(6) { index ->
            val x = size.width * (.14f + index * .11f)
            val y = size.height * (.16f + .016f * sin(index.toFloat()))
            val span = size.width * .010f
            drawLine(
                color = Color(0xFFC8D5E3).copy(alpha = .40f),
                start = Offset(x - span, y),
                end = Offset(x, y - span * .45f),
                strokeWidth = 1.2f
            )
            drawLine(
                color = Color(0xFFC8D5E3).copy(alpha = .40f),
                start = Offset(x, y - span * .45f),
                end = Offset(x + span, y),
                strokeWidth = 1.2f
            )
        }

        // Foreground terrace
        val terraceY = size.height * .70f
        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color(0xFF1B3146),
                    Color(0xFF101C2B),
                    Color(0xFF070E18)
                )
            ),
            topLeft = Offset(0f, terraceY),
            size = Size(size.width, size.height - terraceY)
        )

        // Foreground light is intentionally kept subtle so it never reads as UI dots.
        drawCircle(
            color = HL.Gold.copy(alpha = .10f),
            radius = size.width * .09f,
            center = Offset(size.width * .84f, terraceY + size.height * .07f)
        )

        // Fog layers
        repeat(3) { index ->
            drawRect(
                color = Color.White.copy(alpha = .022f + index * .010f),
                topLeft = Offset(0f, size.height * (.54f + index * .055f)),
                size = Size(size.width, size.height * .028f)
            )
        }

        // Cinematic vignette
        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color.Transparent,
                    HL.Void.copy(alpha = .08f),
                    HL.Void.copy(alpha = .88f)
                )
            ),
            topLeft = Offset(0f, size.height * .46f),
            size = Size(size.width, size.height * .54f)
        )
    }
}
