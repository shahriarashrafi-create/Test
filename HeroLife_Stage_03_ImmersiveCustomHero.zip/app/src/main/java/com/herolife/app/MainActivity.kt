package com.herolife.app

import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay

private val Night = Color(0xFF06101E)
private val Glass = Color(0xE60A1729)
private val Gold = Color(0xFFFFC84A)
private val GoldSoft = Color(0xFFFFE6A1)
private val Crystal = Color(0xFF8EDBFF)
private val TextSoft = Color(0xFFC5D0E0)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        enterImmersiveMode()

        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = Gold,
                        secondary = Crystal,
                        background = Night,
                        surface = Glass,
                        onPrimary = Night,
                        onBackground = Color.White,
                        onSurface = Color.White
                    )
                ) {
                    Stage03App()
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    private fun enterImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val controller = WindowInsetsControllerCompat(
            window,
            window.decorView
        )

        controller.hide(
            WindowInsetsCompat.Type.statusBars() or
                WindowInsetsCompat.Type.navigationBars()
        )

        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            window.decorView.systemUiVisibility or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
}

private enum class Destination {
    HOME, SHOP, EVENTS, REWARDS, ACHIEVEMENTS, TASKS, STATS, MORE, START, HERO_PICKER, COMPANION_PICKER
}

private data class VisualChoice(
    val id: Int,
    val title: String,
    val drawableRes: Int
)

@Composable
private fun Stage03App() {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("herolife_stage03", android.content.Context.MODE_PRIVATE)
    }

    var destination by remember { mutableStateOf(Destination.HOME) }
    var heroId by remember { mutableIntStateOf(prefs.getInt("hero_id", 1)) }
    var companionId by remember { mutableIntStateOf(prefs.getInt("companion_id", 1)) }

    val heroes = remember {
        listOf(
            VisualChoice(1, "شهریار — کلاسیک", R.drawable.hero_01),
            VisualChoice(2, "شهریار — شب", R.drawable.hero_02)
        )
    }

    val companions = remember {
        listOf(
            VisualChoice(1, "شیر طلایی", R.drawable.companion_lion_01),
            VisualChoice(2, "شیر سایه", R.drawable.companion_lion_02)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Night)
    ) {
        Image(
            painter = painterResource(R.drawable.stage03_environment),
            contentDescription = "HeroLife environment",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Independent hero layer.
        Image(
            painter = painterResource(
                heroes.firstOrNull { it.id == heroId }?.drawableRes ?: R.drawable.hero_01
            ),
            contentDescription = "Selected hero",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 110.dp)
                .fillMaxWidth(.62f)
                .height(610.dp)
                .clickable { destination = Destination.HERO_PICKER },
            contentScale = ContentScale.Fit
        )

        // Independent companion layer.
        Image(
            painter = painterResource(
                companions.firstOrNull { it.id == companionId }?.drawableRes
                    ?: R.drawable.companion_lion_01
            ),
            contentDescription = "Selected companion",
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 18.dp, top = 250.dp)
                .width(235.dp)
                .height(260.dp)
                .clickable { destination = Destination.COMPANION_PICKER },
            contentScale = ContentScale.Fit
        )

        if (destination == Destination.HOME) {
            HomeHud(
                onDestination = { destination = it }
            )
        }

        AnimatedVisibility(
            visible = destination != Destination.HOME,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            when (destination) {
                Destination.HERO_PICKER -> ChoicePanel(
                    title = "انتخاب هیرو",
                    choices = heroes,
                    selectedId = heroId,
                    onSelect = {
                        heroId = it
                        prefs.edit().putInt("hero_id", it).apply()
                    },
                    onBack = { destination = Destination.HOME }
                )

                Destination.COMPANION_PICKER -> ChoicePanel(
                    title = "انتخاب همراه",
                    choices = companions,
                    selectedId = companionId,
                    onSelect = {
                        companionId = it
                        prefs.edit().putInt("companion_id", it).apply()
                    },
                    onBack = { destination = Destination.HOME }
                )

                else -> DestinationOverlay(
                    destination = destination,
                    onBack = { destination = Destination.HOME }
                )
            }
        }

        StageBadge(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 6.dp)
        )
    }
}

@Composable
private fun HomeHud(
    onDestination: (Destination) -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        // Top profile/currency hit zones.
        Hotspot(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 10.dp, top = 8.dp)
                .width(300.dp)
                .height(90.dp),
            onClick = { onDestination(Destination.HERO_PICKER) }
        )

        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 12.dp, top = 10.dp)
                .width(112.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            HudButton("♛", "فروشگاه") { onDestination(Destination.SHOP) }
            HudButton("🎁", "رویدادها") { onDestination(Destination.EVENTS) }
            HudButton("▣", "جوایز") { onDestination(Destination.REWARDS) }
            HudButton("🏆", "دستاوردها") { onDestination(Destination.ACHIEVEMENTS) }
        }

        // Companion label.
        Surface(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 18.dp, top = 490.dp)
                .clickable { onDestination(Destination.COMPANION_PICKER) },
            color = Glass,
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                "تغییر همراه",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                color = GoldSoft,
                fontSize = 12.sp
            )
        }

        // Hero label.
        Surface(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(top = 560.dp)
                .clickable { onDestination(Destination.HERO_PICKER) },
            color = Glass,
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                "تغییر هیرو",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                color = GoldSoft,
                fontSize = 12.sp
            )
        }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 122.dp, start = 65.dp, end = 65.dp)
                .fillMaxWidth()
                .height(90.dp)
                .clickable { onDestination(Destination.START) },
            color = Color(0xE6C38718),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(2.dp, GoldSoft)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "⚔ شروع بازی",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        "۳۰ دقیقه",
                        color = Color.White.copy(alpha = .9f),
                        fontSize = 13.sp
                    )
                }
            }
        }

        NavigationBar(
            modifier = Modifier.align(Alignment.BottomCenter),
            containerColor = Color(0xF2071324)
        ) {
            BottomItem("⌂", "خانه") { onDestination(Destination.HOME) }
            BottomItem("✓", "کارها") { onDestination(Destination.TASKS) }
            BottomItem("▥", "آمار") { onDestination(Destination.STATS) }
            BottomItem("🎁", "جوایز") { onDestination(Destination.REWARDS) }
            BottomItem("☰", "بیشتر") { onDestination(Destination.MORE) }
        }
    }
}

@Composable
private fun HudButton(
    icon: String,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(92.dp)
            .clickable(onClick = onClick),
        color = Color(0xE60A1729),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .35f))
    ) {
        Column(
            Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 25.sp)
            Spacer(Modifier.height(3.dp))
            Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun RowScope.BottomItem(
    icon: String,
    label: String,
    onClick: () -> Unit
) {
    NavigationBarItem(
        selected = label == "خانه",
        onClick = onClick,
        icon = {
            Text(
                icon,
                color = if (label == "خانه") GoldSoft else Crystal,
                fontSize = 21.sp
            )
        },
        label = {
            Text(
                label,
                color = if (label == "خانه") Color.White else TextSoft,
                fontSize = 10.sp
            )
        }
    )
}

@Composable
private fun Hotspot(
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(modifier.clickable(onClick = onClick))
}

@Composable
private fun ChoicePanel(
    title: String,
    choices: List<VisualChoice>,
    selectedId: Int,
    onSelect: (Int) -> Unit,
    onBack: () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xE606101E)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .padding(22.dp)
                .fillMaxWidth(),
            color = Glass,
            shape = RoundedCornerShape(26.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .55f))
        ) {
            Column(
                Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    title,
                    color = GoldSoft,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black
                )

                Spacer(Modifier.height(16.dp))

                choices.forEach { choice ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable { onSelect(choice.id) },
                        color = if (choice.id == selectedId) {
                            Color(0xFF19344E)
                        } else {
                            Color(0xFF0C1A2D)
                        },
                        shape = RoundedCornerShape(18.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (choice.id == selectedId) Gold else Crystal.copy(alpha = .25f)
                        )
                    ) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(choice.drawableRes),
                                contentDescription = choice.title,
                                modifier = Modifier
                                    .size(82.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop
                            )

                            Spacer(Modifier.width(14.dp))

                            Column {
                                Text(
                                    choice.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    if (choice.id == selectedId) "انتخاب شده" else "برای انتخاب لمس کن",
                                    color = if (choice.id == selectedId) GoldSoft else TextSoft,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Gold,
                        contentColor = Night
                    )
                ) {
                    Text("بازگشت", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DestinationOverlay(
    destination: Destination,
    onBack: () -> Unit
) {
    val title = when (destination) {
        Destination.SHOP -> "فروشگاه"
        Destination.EVENTS -> "رویدادها"
        Destination.REWARDS -> "جوایز"
        Destination.ACHIEVEMENTS -> "دستاوردها"
        Destination.TASKS -> "کارها"
        Destination.STATS -> "آمار"
        Destination.MORE -> "بیشتر"
        Destination.START -> "شروع بازی"
        Destination.HOME -> "خانه"
        Destination.HERO_PICKER -> "انتخاب هیرو"
        Destination.COMPANION_PICKER -> "انتخاب همراه"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xDC06101E)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .padding(horizontal = 28.dp)
                .fillMaxWidth(),
            color = Glass,
            shape = RoundedCornerShape(26.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .55f))
        ) {
            Column(
                Modifier.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    title,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Black,
                    color = GoldSoft
                )

                Spacer(Modifier.height(12.dp))

                Text(
                    if (destination == Destination.START) {
                        "Fullscreen Immersive آماده است. موتور واقعی بازی در مرحله بعد وارد همین صفحه می‌شود."
                    } else {
                        "این مسیر فعال است و محتوای کامل آن در مراحل بعد اضافه می‌شود."
                    },
                    color = TextSoft,
                    fontSize = 15.sp
                )

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Gold,
                        contentColor = Night
                    )
                ) {
                    Text("بازگشت به خانه")
                }
            }
        }
    }
}

@Composable
private fun StageBadge(
    modifier: Modifier = Modifier
) {
    var visible by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(2200)
        visible = false
    }

    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Surface(
            color = Color(0xB006101E),
            shape = RoundedCornerShape(100.dp)
        ) {
            Text(
                "STAGE 03 • IMMERSIVE + CUSTOM HERO",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                color = Crystal,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
